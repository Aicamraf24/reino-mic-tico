import os, json, shutil, math
from util import *
from content import *
import assets as A
import species as SP
import tex as TX

ALL, SPD = SP.build_species()
A.ALL = ALL
RES_ROOT = 'src/main/resources'
DATA = f'{RES_ROOT}/data/{MOD}'
ASSET = f'{RES_ROOT}/assets/{MOD}'
LANG = A.LANG

def U(i): return i.upper()
def jid(i): return f'{MOD}:{i}'

# ------------------------------------------------------------------ entidades: modelos, texturas, huevos
def topo(parts):
    done, out, names = set(), [], {p['name']: p for p in parts}
    def visit(p):
        if p['name'] in done: return
        if p['parent']: visit(names[p['parent']])
        done.add(p['name']); out.append(p)
    for p in parts: visit(p)
    return out

def extents(parts):
    names = {p['name']: p for p in parts}
    top, maxx = 24.0, 0.0
    def absp(p):
        x, y, z = p['pivot']
        if p['parent']:
            ax, ay, az = absp(names[p['parent']]); return (ax + x, ay + y, az + z)
        return (x, y, z)
    for p in parts:
        ax, ay, az = absp(p); bx, by, bz, w, h, d = p['box']
        top = min(top, ay + by); maxx = max(maxx, abs(ax + bx), abs(ax + bx + w))
    return 24 - top, maxx*2

def gen_entities():
    out = []
    for i, s in enumerate(ALL):
        parts = SP.PLANS[s['plan']](s['p']) if not s.get('hybrid') else SP.hybrid_parts(s, SPD)
        parts = topo(parts)
        size = TX.pack(parts)
        byname = {p['name']: p for p in parts}
        def path(p): return (path(byname[p['parent']]) if p['parent'] else []) + [p['name']]
        h, wspan = extents(parts)
        sc = s['hb'][1]*16.0/max(h, 4); sw = s['hb'][0]*16.0*1.6/max(wspan, 4)
        scale = round(max(0.55, min(4.0, min(sc, max(sw, sc*0.6)))), 2)
        s['scale'] = scale
        model = {'tex': [size, size], 'parts': [{'name': p['name'], 'role': p['role'], 'parent': p['parent'], 'path': path(p), 'u': p['u'], 'v': p['v'],
                 'box': [float(v) for v in p['box']], 'pivot': [float(v) for v in p['pivot']], 'rot': [float(v) for v in p['rot']], 'tags': sorted(p['tags'])} for p in parts]}
        wjson(f'{ASSET}/mico_models/{s["id"]}.json', model)
        hostile = s['cat'] in ('hostile', 'boss')
        save_png(TX.species_texture(parts, size, s['pal'], hostile, False, i * 7 + 1), f'{ASSET}/textures/entity/{s["id"]}.png')
        save_png(TX.species_texture(parts, size, s['pal'], hostile, True, i * 7 + 2, 1), f'{ASSET}/textures/entity/{s["id"]}_baby.png')
        # huevo
        save_png(TX.egg_texture(s['pal'], i + 3), f'{ASSET}/textures/block/egg_{s["id"]}.png')
        def el(f, t): return {'from': f, 'to': t, 'faces': {d: {'uv': [0, 0, 16, 16], 'texture': '#e'} for d in ('north', 'south', 'east', 'west', 'up', 'down')}}
        wjson(f'{ASSET}/models/block/egg_{s["id"]}.json', {'textures': {'e': f'{MOD}:block/egg_{s["id"]}', 'particle': f'{MOD}:block/egg_{s["id"]}'},
              'elements': [el([5, 0, 5], [11, 6, 11]), el([6, 6, 6], [10, 9, 10]), el([7, 9, 7], [9, 10, 9])]})
        LANG[f'entity.{MOD}.{s["id"]}'] = s['name']
    return

# ------------------------------------------------------------------ datos de especies / reproduccion
NOBREED = {'golem_hongos', 'guardian_micelio', 'planta_carnivora', 'coloso_fungico', 'reina_esporas', 'rey_micotico'}
PARTNERS = {
 'ciervo_micotico': ['zorro_micelio', 'jabali_micotico'], 'zorro_micelio': ['ciervo_micotico', 'conejo_esporas', 'oso_fungoso'],
 'conejo_esporas': ['zorro_micelio', 'luciernaga_gigante'], 'oso_fungoso': ['jabali_micotico', 'zorro_micelio'],
 'jabali_micotico': ['ciervo_micotico', 'oso_fungoso'], 'rana_bioluminiscente': ['tortuga_fungosa'],
 'tortuga_fungosa': ['rana_bioluminiscente', 'caracol_cristal'], 'caracol_cristal': ['tortuga_fungosa'],
 'luciernaga_gigante': ['mariposa_esporifera', 'conejo_esporas'], 'mariposa_esporifera': ['luciernaga_gigante', 'murcielago_esporas'],
 'murcielago_esporas': ['mariposa_esporifera'], 'escarabajo_colosal': ['ciempies_fungoso'], 'ciempies_fungoso': ['escarabajo_colosal', 'gusano_esporas'],
 'gusano_esporas': ['ciempies_fungoso'], 'arana_esporifera': ['reptador_micotico'], 'reptador_micotico': ['arana_esporifera'],
 'devorador_micelio': ['bestia_podrida'], 'bestia_podrida': ['devorador_micelio'], 'cazador_hongos': [],
}
CHANCE = 0.8

def gen_species_json():
    arr = []
    for s in ALL:
        sid = s['id']
        d = dict(id=sid, cat=s['cat'], hp=s['hp'], speed=s['spd'], damage=s['dmg'], hbw=s['hb'][0], hbh=s['hb'][1], scale=s['scale'],
                 knockbackResist=s.get('kb', 0.0), fly=bool(s.get('fly')), climb=bool(s.get('climb')), egg=bool(s.get('egg')), tame=bool(s.get('tame')),
                 flee=bool(s.get('flee')), ambush=bool(s.get('ambush')), stationary=bool(s.get('stationary')),
                 breedable=(sid not in NOBREED), boss=(s['cat'] == 'boss'), hybrid=bool(s.get('hybrid')), ability=s.get('ability') or '',
                 maxPop=(24 if s['hb'][1] < 0.7 else 12 if s['hb'][1] < 1.6 else 6), food=s.get('food', []), parents=list(s.get('parents', [])))
        if not d['food'] and d['breedable']: d['food'] = ['minecraft:brown_mushroom', 'minecraft:red_mushroom']
        arr.append(d)
    wjson(f'{DATA}/species.json', {'species': arr})
    sp = {}
    for s in ALL:
        sid = s['id']
        if s['cat'] == 'boss' or sid in NOBREED: continue
        if s.get('hybrid'):
            a, b = s['parents']
            partners = {a, b, sid}
            for h in ALL:
                if h.get('hybrid') and h['id'] != sid and set(h['parents']) & {a, b}: partners.add(h['id'])
            sp[sid] = {'partners': sorted(partners), 'cooldown': 6000}
        else:
            sp[sid] = {'partners': PARTNERS.get(sid, []), 'cooldown': 6000}
    hyb = [{'parents': [a, b], 'result': h, 'chance': CHANCE} for (h, _n, a, b, _p) in SP.HYB]
    wjson(f'{DATA}/breeding.json', {'_comentario': 'Edita en config/reino_micotico/breeding.json. partners: parejas compatibles; hybrids: cruces -> criatura hibrida. Los jefes nunca se reproducen.',
                                   'species': sp, 'hybrids': hyb})
    wjson(f'{DATA}/tags/entity_type/micotic_creatures.json', {'values': [jid(s['id']) for s in ALL]})
    wjson(f'{DATA}/tags/entity_type/micotic_bosses.json', {'values': [jid('rey_micotico')]})
    wjson(f'{DATA}/tags/entity_type/micotic_hybrids.json', {'values': [jid(s['id']) for s in ALL if s.get('hybrid')]})

# ------------------------------------------------------------------ loot / recetas / tags
def loot_item(name, lo=1, hi=1, cond=None):
    e = {'type': 'minecraft:item', 'name': name}
    if hi != lo or lo != 1: e['functions'] = [{'function': 'minecraft:set_count', 'count': ({'type': 'minecraft:uniform', 'min': lo, 'max': hi} if hi != lo else float(lo))}]
    return e

def gen_loot():
    for b in BLOCKS:
        d = b.get('drop', 'self')
        if d == 'none':
            tbl = {'type': 'minecraft:block', 'pools': []}
        else:
            name = jid(b['id']) if d == 'self' else (jid(d) if d != 'esencia' else jid('esencia_esporas'))
            e = loot_item(name) if d != 'esencia' else loot_item(name, 0, 2)
            if d not in ('self',) and b['kind'] in ('cube',) and d != 'esencia':
                e = loot_item(name, 1, 3 if d in ('mineral_carmesi', 'mineral_violeta') else 2)
            tbl = {'type': 'minecraft:block', 'pools': [{'rolls': 1.0, 'entries': [e], 'conditions': [{'condition': 'minecraft:survives_explosion'}]}]}
        if b['kind'] == 'slab' and d == 'self':
            tbl['pools'][0]['entries'][0]['functions'] = [{'function': 'minecraft:set_count', 'count': 2.0, 'conditions': [{'condition': 'minecraft:block_state_property', 'block': jid(b['id']), 'properties': {'type': 'double'}}]}]
        wjson(f'{DATA}/loot_table/blocks/{b["id"]}.json', tbl)
    for s in ALL:
        pools = []
        drops = list(s.get('drops', []))
        if drops: pools.append({'rolls': 1.0, 'entries': [loot_item(n, lo, hi) for (n, lo, hi) in drops]})
        if s['cat'] == 'boss':
            pools = [{'rolls': 1.0, 'entries': [loot_item(jid('corazon_esporifero'), 4, 8)]}, {'rolls': 1.0, 'entries': [loot_item(jid('nucleo_micelio'), 2, 4)]},
                     {'rolls': 1.0, 'entries': [loot_item(jid('esencia_esporas'), 6, 12)]},
                     {'rolls': {'type': 'minecraft:uniform', 'min': 2, 'max': 4}, 'entries': [loot_item(jid(f'{p[0]}_rey_micotico')) for p in PIECES]}]
        wjson(f'{DATA}/loot_table/entities/{s["id"]}.json', {'type': 'minecraft:entity', 'pools': pools})
    chests = {
        'aldea': [('minecraft:bread', 2, 5), (jid('carne_fungosa'), 2, 5), (jid('esencia_esporas'), 2, 6), ('minecraft:glow_berries', 3, 8), (jid('fragmento_fungoso'), 1, 3)],
        'ciudad': [(jid('cristal_micotico'), 1, 4), (jid('esencia_esporas'), 3, 8), (jid('mineral_carmesi'), 1, 4), (jid('mineral_violeta'), 1, 4), ('minecraft:golden_apple', 1, 1)],
        'templo': [(jid('nucleo_micelio'), 1, 2), (jid('piedra_viviente'), 1, 3), (jid('cristal_micotico'), 2, 5), (jid('espada_esporas'), 1, 1), (jid('baston_esporas'), 1, 1)],
        'laboratorio': [(jid('esencia_esporas'), 4, 10), (jid('daga_venenosa'), 1, 1), ('minecraft:potion', 1, 1), (jid('fragmento_fungoso'), 2, 5)],
        'nido': [(jid('carne_fungosa'), 1, 4), (jid('esencia_esporas'), 1, 4), ('minecraft:bone', 1, 5)],
        'tesoro': [(jid('corazon_esporifero'), 1, 2), (jid('cristal_micotico'), 3, 8), (jid('piedra_viviente'), 2, 5), ('minecraft:diamond', 1, 3), (jid('pico_cristal_fungoso'), 1, 1)],
        'jardin': [(jid('esencia_esporas'), 2, 6), (jid('hongo_luminoso'), 2, 6), (jid('planta_luminosa'), 1, 4), (jid('arco_micelio'), 1, 1)],
        'santuario': [(jid('nucleo_micelio'), 1, 2), (jid('corazon_esporifero'), 1, 1), (jid('hacha_micotica'), 1, 1), (jid('casco_guardian_fungoso'), 1, 1)],
        'ruinas': [(jid('fragmento_fungoso'), 1, 4), (jid('mineral_violeta'), 1, 3), ('minecraft:iron_ingot', 1, 4)],
        'trono': [(jid('corazon_esporifero'), 2, 4), (jid('nucleo_micelio'), 1, 3), (jid('cristal_micotico'), 4, 9), ('minecraft:diamond', 2, 5)],
        'torre': [(jid('cristal_micotico'), 1, 3), (jid('esencia_esporas'), 2, 5), (jid('peto_micelio'), 1, 1), (jid('botas_violeta'), 1, 1)],
        'isla': [(jid('esencia_esporas'), 2, 5), (jid('cristal_micotico'), 1, 3), (jid('nucleo_micelio'), 1, 1)],
        'puente': [(jid('fragmento_fungoso'), 1, 3), (jid('esencia_esporas'), 1, 3)],
    }
    for n, items in chests.items():
        wjson(f'{DATA}/loot_table/chests/{n}.json', {'type': 'minecraft:chest', 'pools': [
            {'rolls': {'type': 'minecraft:uniform', 'min': 3, 'max': 6}, 'entries': [dict(loot_item(a, lo, hi), weight=5) for (a, lo, hi) in items]}]})

def shaped(i, pattern, key, result, count=1, cat='misc'):
    wjson(f'{DATA}/recipe/{i}.json', {'type': 'minecraft:crafting_shaped', 'category': cat, 'key': key, 'pattern': pattern, 'result': {'id': result, 'count': count}})
def shapeless(i, ing, result, count=1, cat='misc'):
    wjson(f'{DATA}/recipe/{i}.json', {'type': 'minecraft:crafting_shapeless', 'category': cat, 'ingredients': ing, 'result': {'id': result, 'count': count}})

def gen_recipes():
    cr, es, st = jid('cristal_micotico'), jid('esencia_esporas'), 'minecraft:stick'
    shaped('espada_esporas', ['X', 'X', 'S'], {'X': cr, 'S': st}, jid('espada_esporas'), cat='equipment')
    shaped('hacha_micotica', ['XX', 'XS', ' S'], {'X': cr, 'S': st}, jid('hacha_micotica'), cat='equipment')
    shaped('pico_cristal_fungoso', ['XXX', ' S ', ' S '], {'X': cr, 'S': st}, jid('pico_cristal_fungoso'), cat='equipment')
    shaped('daga_venenosa', ['X', 'S'], {'X': jid('fragmento_fungoso'), 'S': st}, jid('daga_venenosa'), cat='equipment')
    shaped('arco_micelio', [' XS', 'XES', ' XS'], {'X': st, 'E': es, 'S': 'minecraft:string'}, jid('arco_micelio'), cat='equipment')
    shaped('baston_esporas', [' EC', ' SE', 'S  '], {'E': es, 'C': cr, 'S': st}, jid('baston_esporas'), cat='equipment')
    for (sid, _n, _c, _c2, _d, _df, _e, _t, _k, mat) in SETS:
        if not mat: continue
        for (pid, _pn, _a, _k2, pat) in PIECES:
            shaped(f'{pid}_{sid}', pat, {'X': jid(mat)}, jid(f'{pid}_{sid}'), cat='equipment')
    shapeless('madera_micotica', [jid('tronco_gigante')], jid('madera_micotica'), 4, 'building')
    shaped('madera_micotica_losa', ['XXX'], {'X': jid('madera_micotica')}, jid('madera_micotica_losa'), 6, 'building')
    shaped('madera_micotica_escalera', ['X  ', 'XX ', 'XXX'], {'X': jid('madera_micotica')}, jid('madera_micotica_escalera'), 4, 'building')
    shaped('ladrillos_micelio', ['XX', 'XX'], {'X': jid('piedra_fungosa')}, jid('ladrillos_micelio'), 4, 'building')
    shaped('ladrillos_micelio_losa', ['XXX'], {'X': jid('ladrillos_micelio')}, jid('ladrillos_micelio_losa'), 6, 'building')
    shaped('ladrillos_micelio_escalera', ['X  ', 'XX ', 'XXX'], {'X': jid('ladrillos_micelio')}, jid('ladrillos_micelio_escalera'), 4, 'building')
    shaped('ladrillos_podridos', ['XX', 'XX'], {'X': jid('piedra_podrida')}, jid('ladrillos_podridos'), 4, 'building')
    shaped('bloque_esporas', ['XXX', 'XXX', 'XXX'], {'X': es}, jid('bloque_esporas'), 1, 'building')
    shapeless('esencia_desde_bloque', [jid('bloque_esporas')], es, 9)
    shaped('bloque_cristal_micotico', ['XX', 'XX'], {'X': cr}, jid('bloque_cristal_micotico'), 1, 'building')
    shapeless('cristal_desde_bloque', [jid('bloque_cristal_micotico')], cr, 4)
    shaped('lampara_micelio', [' C ', 'CEC', ' C '], {'C': cr, 'E': es}, jid('lampara_micelio'), 2, 'building')
    shapeless('tallo_luminoso', [jid('tallo_hongo'), es], jid('tallo_luminoso'), 1, 'building')
    shapeless('nucleo_micelio', [jid('fragmento_fungoso'), jid('fragmento_fungoso'), es, es, cr], jid('nucleo_micelio'))
    shaped('altar_portal', ['BCB', 'BNB', 'BBB'], {'B': jid('ladrillos_micelio'), 'C': cr, 'N': jid('nucleo_micelio')}, jid('altar_portal'))
    for typ, tm in (('smelting', 200), ('campfire_cooking', 600), ('smoking', 100)):
        wjson(f'{DATA}/recipe/carne_fungosa_{typ}.json', {'type': f'minecraft:{typ}', 'category': 'food', 'ingredient': jid('carne_fungosa'),
              'result': {'id': jid('carne_fungosa_cocida')}, 'experience': 0.35, 'cookingtime': tm})

def gen_tags():
    mine = {'pickaxe': [], 'axe': [], 'shovel': [], 'hoe': []}; need = {'stone': [], 'iron': [], 'diamond': []}; dirt = []
    for b in BLOCKS:
        if b.get('tool'): mine[b['tool']].append(jid(b['id']))
        if b.get('need'): need[b['need']].append(jid(b['id']))
        if b.get('dirt'): dirt.append(jid(b['id']))
    for t, v in mine.items(): wjson(f'{RES_ROOT}/data/minecraft/tags/block/mineable/{t}.json', {'replace': False, 'values': v})
    for t, v in need.items(): wjson(f'{RES_ROOT}/data/minecraft/tags/block/needs_{t}_tool.json', {'replace': False, 'values': v})
    wjson(f'{RES_ROOT}/data/minecraft/tags/block/dirt.json', {'replace': False, 'values': dirt})
    wjson(f'{RES_ROOT}/data/minecraft/tags/block/overworld_carver_replaceables.json', {'replace': False, 'values': dirt + [jid('piedra_fungosa'), jid('piedra_podrida'), jid('arena_esporifera')]})
    wjson(f'{DATA}/tags/item/repairs_tools.json', {'values': [jid('cristal_micotico')]})
    for (sid, *_r, mat) in SETS:
        wjson(f'{DATA}/tags/item/repairs_{sid}.json', {'values': [jid(mat or 'corazon_esporifero')]})

def gen_lang():
    LANG.update({'message.reino_micotico.need_core': 'Necesitas un Núcleo de Micelio en la mano principal para activar el altar.',
                 'message.reino_micotico.no_dimension': 'El Reino Micótico no está disponible en este mundo.',
                 'itemGroup.reino_micotico': 'Reino Micótico', 'dimension.reino_micotico': 'Reino Micótico',
                 'death.attack.mob': ''})
    LANG.pop('death.attack.mob')
    for k, v in BIOME_NAMES.items(): LANG[f'biome.{MOD}.{k}'] = v
    wjson(f'{ASSET}/lang/es_es.json', LANG)
    wjson(f'{ASSET}/lang/es_mx.json', LANG)
    wjson(f'{ASSET}/lang/es_ar.json', LANG)
    wjson(f'{ASSET}/lang/en_us.json', LANG)

BIOME_NAMES = {'bosque_carmesi': 'Bosque Carmesí', 'bosque_violeta': 'Bosque Violeta', 'praderas_micelio': 'Praderas de Micelio',
               'pantano_esporifero': 'Pantano Esporífero', 'montanas_fungales': 'Montañas Fungales', 'jardines_bioluminiscentes': 'Jardines Bioluminiscentes',
               'cavernas_micoticas': 'Cavernas Micóticas', 'corazon_podrido': 'Corazón Podrido'}
