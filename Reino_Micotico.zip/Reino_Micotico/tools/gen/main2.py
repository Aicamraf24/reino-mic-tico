from main1 import *

JDIR = f'src/main/java/com/reinomicotico'

def gen_java_registries():
    # ---------------- ModBlocks
    L = ['package com.reinomicotico;', '',
         'import com.reinomicotico.block.MicoEggBlock;', 'import com.reinomicotico.block.PortalAltarBlock;', 'import java.util.function.Function;',
         'import net.minecraft.core.Registry;', 'import net.minecraft.core.registries.BuiltInRegistries;', 'import net.minecraft.core.registries.Registries;',
         'import net.minecraft.resources.ResourceKey;', 'import net.minecraft.world.item.BlockItem;', 'import net.minecraft.world.item.Item;',
         'import net.minecraft.world.level.block.*;', 'import net.minecraft.world.level.block.state.BlockBehaviour;', '',
         '/** Bloques del Reino Micotico (generado por gen/). */', 'public final class ModBlocks {', '\tprivate ModBlocks() {}', '',
         '\tprivate static Block register(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties settings, boolean withItem) {',
         '\t\tResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, ReinoMicotico.id(name));',
         '\t\tBlock block = factory.apply(settings.setId(key));',
         '\t\tif (withItem) {',
         '\t\t\tResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, ReinoMicotico.id(name));',
         '\t\t\tBlockItem bi = new BlockItem(block, new Item.Properties().setId(ik).useBlockDescriptionPrefix());',
         '\t\t\tRegistry.register(BuiltInRegistries.ITEM, ik, bi);', '\t\t}',
         '\t\treturn Registry.register(BuiltInRegistries.BLOCK, key, block);', '\t}', '']
    for b in BLOCKS:
        k = b['kind']; p = 'BlockBehaviour.Properties.of()'
        h = b['hard']
        if k == 'plant':
            p += '.noCollision().noOcclusion()' + ('.instabreak()' if h == 0 else f'.strength({h}f)')
        elif k == 'egg':
            p += '.strength(0.5f).noOcclusion().randomTicks()'
        else:
            p += f'.strength({h}f)'
            if k in ('slab', 'stairs', 'altar', 'cap') or b.get('stone'): p += '.noOcclusion()' if k in ('altar',) else ''
        if b.get('stone') or k == 'altar': p += '.requiresCorrectToolForDrops()'
        p += f'.sound(SoundType.{b["snd"]})'
        if b.get('light'): p += f'.lightLevel(s -> {b["light"]})'
        fac = {'cube': 'Block::new', 'bt': 'Block::new', 'pillar': 'RotatedPillarBlock::new', 'cap': 'HugeMushroomBlock::new', 'slab': 'SlabBlock::new',
               'plant': 'Block::new', 'altar': 'PortalAltarBlock::new', 'egg': 'MicoEggBlock::new'}.get(k)
        if k == 'stairs': fac = f'p -> new StairBlock({U(b["base"])}.defaultBlockState(), p)'
        L.append(f'\tpublic static final Block {U(b["id"])} = register("{b["id"]}", {fac}, {p}, {"false" if b.get("noitem") else "true"});')
    L += ['', '\tpublic static void initialize() {', '\t\t// el registro ocurre en la carga estatica de la clase', '\t}', '}']
    write(f'{JDIR}/ModBlocks.java', '\n'.join(L) + '\n')

    # ---------------- ModArmor / materiales de herramienta
    L = ['package com.reinomicotico;', '', 'import java.util.Map;', 'import net.minecraft.core.registries.BuiltInRegistries;', 'import net.minecraft.resources.ResourceKey;',
         'import net.minecraft.sounds.SoundEvents;', 'import net.minecraft.tags.BlockTags;', 'import net.minecraft.tags.TagKey;', 'import net.minecraft.world.item.Item;',
         'import net.minecraft.world.item.ToolMaterial;', 'import net.minecraft.world.item.equipment.ArmorMaterial;', 'import net.minecraft.world.item.equipment.ArmorType;',
         'import net.minecraft.world.item.equipment.EquipmentAsset;', 'import net.minecraft.world.item.equipment.EquipmentAssets;', '',
         'public final class ModArmor {', '\tprivate ModArmor() {}', '',
         '\tpublic static final TagKey<Item> REPAIRS_TOOLS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_tools"));',
         '\tpublic static final ToolMaterial MICOTICO = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1200, 8.0f, 3.0f, 22, REPAIRS_TOOLS);', '']
    for (sid, _n, _c, _c2, dur, df, ench, tough, kb, _m) in SETS:
        U_ = U(sid)
        L.append(f'\tpublic static final ResourceKey<EquipmentAsset> {U_}_KEY = ResourceKey.create(EquipmentAssets.ROOT_ID, ReinoMicotico.id("{sid}"));')
        L.append(f'\tpublic static final TagKey<Item> {U_}_REPAIRS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_{sid}"));')
        L.append(f'\tpublic static final ArmorMaterial {U_} = new ArmorMaterial({dur}, Map.of(ArmorType.BOOTS, {df[3]}, ArmorType.LEGGINGS, {df[2]}, ArmorType.CHESTPLATE, {df[1]}, ArmorType.HELMET, {df[0]}, ArmorType.BODY, {df[1]+2}), {ench}, SoundEvents.ARMOR_EQUIP_IRON, {tough}f, {kb}f, {U_}_REPAIRS, {U_}_KEY);')
    L.append('}')
    write(f'{JDIR}/ModArmor.java', '\n'.join(L) + '\n')

    # ---------------- ModItems
    L = ['package com.reinomicotico;', '', 'import com.reinomicotico.item.DaggerItem;', 'import com.reinomicotico.item.SporeStaffItem;', 'import java.util.function.Function;',
         'import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;', 'import net.minecraft.core.Registry;', 'import net.minecraft.core.registries.BuiltInRegistries;',
         'import net.minecraft.core.registries.Registries;', 'import net.minecraft.resources.ResourceKey;', 'import net.minecraft.world.food.FoodProperties;',
         'import net.minecraft.world.item.BowItem;', 'import net.minecraft.world.item.CreativeModeTabs;', 'import net.minecraft.world.item.Item;', 'import net.minecraft.world.item.SpawnEggItem;',
         'import net.minecraft.world.item.equipment.ArmorType;', '',
         'public final class ModItems {', '\tprivate ModItems() {}', '',
         '\tprivate static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {',
         '\t\tResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ReinoMicotico.id(name));',
         '\t\treturn Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));', '\t}', '']
    for (i, *_r) in RES:
        if i.startswith('carne'):
            nut, sat = (4, 0.3) if i == 'carne_fungosa' else (8, 0.8)
            L.append(f'\tpublic static final Item {U(i)} = register("{i}", Item::new, new Item.Properties().food(new FoodProperties.Builder().nutrition({nut}).saturationModifier({sat}f).build()));')
        else:
            L.append(f'\tpublic static final Item {U(i)} = register("{i}", Item::new, new Item.Properties());')
    for (sid, *_r) in SETS:
        for (pid, _pn, at, _k, _p) in PIECES:
            L.append(f'\tpublic static final Item {U(pid+"_"+sid)} = register("{pid}_{sid}", Item::new, new Item.Properties().humanoidArmor(ModArmor.{U(sid)}, ArmorType.{at}));')
    L += ['\tpublic static final Item ESPADA_ESPORAS = register("espada_esporas", Item::new, new Item.Properties().sword(ModArmor.MICOTICO, 3.0f, -2.4f));',
          '\tpublic static final Item HACHA_MICOTICA = register("hacha_micotica", Item::new, new Item.Properties().axe(ModArmor.MICOTICO, 5.0f, -3.0f));',
          '\tpublic static final Item PICO_CRISTAL_FUNGOSO = register("pico_cristal_fungoso", Item::new, new Item.Properties().pickaxe(ModArmor.MICOTICO, 1.0f, -2.8f));',
          '\tpublic static final Item DAGA_VENENOSA = register("daga_venenosa", DaggerItem::new, new Item.Properties().sword(ModArmor.MICOTICO, 1.0f, -1.6f));',
          '\tpublic static final Item ARCO_MICELIO = register("arco_micelio", BowItem::new, new Item.Properties().durability(520));',
          '\tpublic static final Item BASTON_ESPORAS = register("baston_esporas", SporeStaffItem::new, new Item.Properties().durability(250));', '']
    for s in ALL:
        L.append(f'\tpublic static final Item GENERADOR_{U(s["id"])} = register("generador_{s["id"]}", SpawnEggItem::new, new Item.Properties().spawnEgg(ModEntities.TYPES.get("{s["id"]}")));')
    L += ['', '\tpublic static void initialize() {']
    def tab(t, names, blocks=()):
        out = [f'\t\tCreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.{t}).register(entries -> {{']
        out += [f'\t\t\tentries.accept({n});' for n in names]
        out += [f'\t\t\tentries.accept(ModBlocks.{n});' for n in blocks]
        return out + ['\t\t});']
    bl = lambda f: [U(b['id']) for b in BLOCKS if f(b) and not b.get('noitem')]
    L += tab('BUILDING_BLOCKS', [], bl(lambda b: b['kind'] in ('cube', 'bt', 'slab', 'stairs') and b.get('st', ('',))[0] not in ('ore', 'leaves') and 'mena' not in b['id']))
    L += tab('NATURAL_BLOCKS', [], bl(lambda b: b['kind'] in ('pillar', 'cap', 'plant') or 'mena' in b['id'] or b['id'].startswith('hojas')))
    L += tab('FUNCTIONAL_BLOCKS', [], ['ALTAR_PORTAL'])
    L += tab('INGREDIENTS', [U(i) for (i, *_r) in RES if not i.startswith('carne')])
    L += tab('FOOD_AND_DRINKS', ['CARNE_FUNGOSA', 'CARNE_FUNGOSA_COCIDA'])
    L += tab('TOOLS_AND_UTILITIES', ['PICO_CRISTAL_FUNGOSO', 'HACHA_MICOTICA', 'BASTON_ESPORAS'])
    L += tab('COMBAT', ['ESPADA_ESPORAS', 'DAGA_VENENOSA', 'ARCO_MICELIO'] + [U(p[0] + '_' + s[0]) for s in SETS for p in PIECES])
    L += tab('SPAWN_EGGS', [f'GENERADOR_{U(s["id"])}' for s in ALL])
    L += ['\t}', '}']
    write(f'{JDIR}/ModItems.java', '\n'.join(L) + '\n')

def copy_static():
    import glob
    for f in glob.glob('/home/claude/java_static/**/*.java', recursive=True):
        rel = os.path.relpath(f, '/home/claude/java_static')
        write(f'{JDIR}/{rel}', open(f, encoding='utf-8').read())

def gen_build():
    write('settings.gradle', "pluginManagement {\n\trepositories {\n\t\tmaven { name = 'Fabric'; url = 'https://maven.fabricmc.net/' }\n\t\tmavenCentral()\n\t\tgradlePluginPortal()\n\t}\n}\n\nrootProject.name = 'reino_micotico'\n")
    write('gradle.properties', '''org.gradle.jvmargs=-Xmx2G
org.gradle.parallel=true
org.gradle.configuration-cache=false

# Versiones verificadas en docs.fabricmc.net / Fabric Maven para Minecraft 26.1.2 (ver README, seccion "Verificacion")
minecraft_version=26.1.2
loader_version=0.19.2
loom_version=1.15.5
fabric_api_version=0.145.4+26.1.2

mod_version=1.0.0
maven_group=com.reinomicotico
archives_base_name=reino_micotico
''')
    write('build.gradle', '''plugins {
	id 'net.fabricmc.fabric-loom' version "${loom_version}"
	id 'maven-publish'
}

version = project.mod_version
group = project.maven_group

base {
	archivesName = project.archives_base_name
}

repositories {
	// Fabric API, Loader y Minecraft se resuelven desde los repositorios que Loom agrega.
}

dependencies {
	minecraft "com.mojang:minecraft:${project.minecraft_version}"
	implementation "net.fabricmc:fabric-loader:${project.loader_version}"
	implementation "net.fabricmc.fabric-api:fabric-api:${project.fabric_api_version}"
}

processResources {
	inputs.property "version", project.version
	filesMatching("fabric.mod.json") {
		expand "version": inputs.properties.version
	}
}

tasks.withType(JavaCompile).configureEach {
	it.options.release = 25
	it.options.encoding = 'UTF-8'
}

java {
	withSourcesJar()
	sourceCompatibility = JavaVersion.VERSION_25
	targetCompatibility = JavaVersion.VERSION_25
}

jar {
	inputs.property "projectName", project.base.archivesName
	from("LICENSE") { rename { "${it}_${project.base.archivesName.get()}" } }
}
''')
    write('gradle/wrapper/gradle-wrapper.properties', 'distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-9.4.1-bin.zip\nnetworkTimeout=10000\nvalidateDistributionUrl=true\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists\n')
    wjson(f'{RES_ROOT}/fabric.mod.json', {'schemaVersion': 1, 'id': MOD, 'version': '${version}', 'name': 'Reino Micótico',
        'description': 'Una dimensión de hongos gigantes, 25 criaturas con cruces entre especies, híbridos, jefe final y mucho más.',
        'authors': ['Reino Micótico'], 'license': 'All-Rights-Reserved', 'icon': f'assets/{MOD}/icon.png', 'environment': '*',
        'entrypoints': {'main': ['com.reinomicotico.ReinoMicotico'], 'client': ['com.reinomicotico.client.ReinoMicoticoClient']},
        'depends': {'fabricloader': '>=0.19.1', 'minecraft': '~26.1.2', 'java': '>=25', 'fabric-api': '*'}})
    write('.github/workflows/build.yml', '''name: Compilar Reino Micotico
on:
  push:
  pull_request:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 25
      # No hace falta el wrapper: se usa Gradle 9.4.1 directamente
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 9.4.1
      - name: Compilar
        run: gradle build --stacktrace
      - uses: actions/upload-artifact@v4
        with:
          name: reino_micotico-jar
          path: build/libs/*.jar
''')
    write('.gitignore', '.gradle/\nbuild/\nrun/\n.idea/\n*.iml\nout/\n')
    write('LICENSE', 'Todos los derechos reservados. Proyecto personal.\n')
    # icono
    from PIL import Image
    ic = TX_icon()
    save_png(ic, f'{ASSET}/icon.png')

def TX_icon():
    from PIL import Image, ImageDraw
    img = Image.new('RGBA', (128, 128), (40, 20, 70, 255)); d = ImageDraw.Draw(img)
    d.rectangle([54, 70, 74, 120], fill=(232, 220, 200, 255))
    d.pieslice([14, 20, 114, 100], 180, 360, fill=(200, 32, 46, 255))
    for (x, y) in ((40, 50), (66, 40), (85, 58), (55, 62)): d.ellipse([x, y, x + 10, y + 10], fill=(245, 235, 220, 255))
    return img
