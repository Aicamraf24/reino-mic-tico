import math, random
from PIL import Image, ImageDraw
from util import hexrgb, shade, mix

S = 16; SS = 8  # tamano final y supermuestreo

def _big(part):
    big = Image.new('L', (S*SS, S*SS), 0); d = ImageDraw.Draw(big); k = SS
    t = part['t']
    if t == 'poly': d.polygon([(x*k, y*k) for x, y in part['p']], fill=255)
    elif t == 'line':
        (x0, y0), (x1, y1) = part['a'], part['b']; w = part['w']/2
        dx, dy = x1-x0, y1-y0; L = math.hypot(dx, dy) or 1; nx, ny = -dy/L*w, dx/L*w
        d.polygon([((x0+nx)*k, (y0+ny)*k), ((x1+nx)*k, (y1+ny)*k), ((x1-nx)*k, (y1-ny)*k), ((x0-nx)*k, (y0-ny)*k)], fill=255)
        d.ellipse([(x0-w)*k, (y0-w)*k, (x0+w)*k, (y0+w)*k], fill=255); d.ellipse([(x1-w)*k, (y1-w)*k, (x1+w)*k, (y1+w)*k], fill=255)
    elif t == 'circle':
        (cx, cy), r = part['c'], part['r']; d.ellipse([(cx-r)*k, (cy-r)*k, (cx+r)*k, (cy+r)*k], fill=255)
    elif t == 'ellipse':
        (cx, cy) = part['c']; rx, ry = part['rx'], part['ry']; d.ellipse([(cx-rx)*k, (cy-ry)*k, (cx+rx)*k, (cy+ry)*k], fill=255)
    elif t == 'rect':
        x0, y0, x1, y1 = part['r']; d.rectangle([x0*k, y0*k, x1*k-1, y1*k-1], fill=255)
    elif t == 'polyline':
        pts = part['p']; w = part['w']
        for a, b in zip(pts, pts[1:]):
            big.paste(255, mask=_big(dict(t='line', a=a, b=b, w=w)))
    return big

def _mask(part):
    return _big(part).resize((S, S), Image.BOX)

def compose(parts, dots=(), seed=0, outline=0.42):
    pid = [[-1]*S for _ in range(S)]
    for i, p in enumerate(parts):
        m = _mask(p).load(); thr = p.get('thr', 110)
        for y in range(S):
            for x in range(S):
                if m[x, y] >= thr: pid[y][x] = i
    out = Image.new('RGBA', (S, S), (0, 0, 0, 0)); op = out.load()
    def edge(x, y, own):
        return not (0 <= x < S and 0 <= y < S) or pid[y][x] == -1
    for y in range(S):
        for x in range(S):
            i = pid[y][x]
            if i < 0: continue
            base = hexrgb(parts[i]['col']) if isinstance(parts[i]['col'], str) else parts[i]['col']
            nb = lambda dx, dy: (0 <= x+dx < S and 0 <= y+dy < S) and pid[y+dy][x+dx] != -1
            is_edge = not (nb(1, 0) and nb(-1, 0) and nb(0, 1) and nb(0, -1))
            if is_edge and not parts[i].get('noline'):
                c = mix(base, (10, 8, 18), 1 - outline - 0.0)
            else:
                # bisel: luz arriba-izquierda
                up = pid[y-1][x] if y > 0 else -1; lf = pid[y][x-1] if x > 0 else -1
                dn = pid[y+1][x] if y < S-1 else -1; rt = pid[y][x+1] if x < S-1 else -1
                def e(j, same=i): return j == -1 or j != same
                if (e(up) or e(lf)) and not (e(dn) and e(rt)): c = shade(base, 1.38)
                elif e(dn) or e(rt): c = shade(base, 0.72)
                else:
                    ul = pid[y-1][x-1] if x > 0 and y > 0 else -1; dr = pid[y+1][x+1] if x < S-1 and y < S-1 else -1
                    c = shade(base, 1.14 if e(ul) else 0.88 if e(dr) else 1.0)
            op[x, y] = c + (255,)
    for (x, y, col) in dots:
        if 0 <= x < S and 0 <= y < S:
            c = hexrgb(col) if isinstance(col, str) else col
            if op[x, y][3] or True: op[x, y] = c + (255,)
    return out

P = lambda pts, col, **k: dict(t='poly', p=pts, col=col, **k)
L = lambda a, b, w, col, **k: dict(t='line', a=a, b=b, w=w, col=col, **k)
C = lambda c, r, col, **k: dict(t='circle', c=c, r=r, col=col, **k)
E = lambda c, rx, ry, col, **k: dict(t='ellipse', c=c, rx=rx, ry=ry, col=col, **k)
R = lambda r, col, **k: dict(t='rect', r=r, col=col, **k)

WOOD = '#8a5a34'; WOOD2 = '#5e3b22'; WHITE = '#fff6ea'; GLASS = '#cfe9ff'

def spots(cx, cy, rx, ry, n, col, seed):
    rng = random.Random(seed); out = []
    for _ in range(n):
        a = rng.random()*6.28; r = rng.random()**0.5
        out.append((int(cx + math.cos(a)*rx*r), int(cy + math.sin(a)*ry*r), col))
    return out

def icon(kind, color, accent='#ffffff', seed=0, deco=None):
    c = color; a = accent; dots = []
    if kind == 'sword':
        parts = [L((12.6, 2.4), (6.2, 8.8), 3.2, c), L((11.8, 3.6), (7.4, 8.0), 1.0, shade(c, 1.45), noline=True),
                 L((3.4, 7.4), (8.2, 12.2), 2.0, a), L((6.6, 9.6), (3.0, 13.2), 2.0, WOOD), C((2.3, 13.9), 1.5, a), C((5.8, 9.8), 0.9, WHITE, noline=True)]
        dots = [(13, 1, WHITE), (12, 2, WHITE)]
    elif kind == 'dagger':
        parts = [P([(13, 2), (14.2, 3.2), (8, 9.6), (6.4, 8.0)], c), L((11.6, 4.2), (8.4, 7.4), 0.8, shade(c, 1.5), noline=True),
                 L((4.8, 7.0), (8.8, 11.0), 2.0, a), L((6.8, 9.4), (3.2, 13.0), 2.0, WOOD2), C((2.6, 13.6), 1.4, a)]
        dots = [(12, 7, '#9dff4a'), (13, 8, '#9dff4a'), (9, 11, '#9dff4a'), (13, 4, WHITE)]
    elif kind == 'axe':
        parts = [L((3.0, 13.8), (10.2, 5.4), 2.0, WOOD), L((9.4, 4.6), (4.0, 12.6), 0.0001, WOOD2, noline=True),
                 P([(6.0, 2.4), (11.0, 0.8), (15.0, 3.4), (15.2, 9.2), (11.2, 10.6), (9.8, 7.8), (7.6, 6.2)], c),
                 P([(11.0, 2.2), (14.0, 4.0), (14.0, 7.4), (12.2, 5.8)], shade(c, 1.35), noline=True), C((3.0, 14.0), 1.2, a)]
        dots = [(10, 5, WHITE), (12, 7, WHITE), (13, 3, WHITE)]
    elif kind == 'pickaxe':
        parts = [L((3.0, 14.0), (10.8, 6.2), 2.0, WOOD),
                 P([(2.0, 6.6), (4.0, 3.0), (8.0, 1.4), (12.0, 1.8), (14.8, 4.6), (15.0, 8.0), (12.6, 5.6), (9.2, 4.6), (6.0, 5.4), (4.0, 8.4)], c),
                 P([(8.0, 2.4), (12.0, 2.8), (13.4, 4.4), (10.4, 3.8)], shade(c, 1.4), noline=True), C((3.0, 14.0), 1.2, a)]
        dots = [(5, 5, WHITE), (13, 4, WHITE)]
    elif kind == 'bow':
        pts = [(11.6, 1.2), (7.6, 3.0), (5.2, 6.0), (4.6, 9.0), (6.2, 12.4), (11.0, 14.8)]
        parts = [dict(t='polyline', p=pts, w=2.2, col=c), L((12.2, 1.6), (12.2, 14.4), 0.9, '#efe6d8', noline=True),
                 L((4.5, 7.4), (4.7, 10.6), 2.6, WOOD2), C((7.2, 3.0), 1.3, a), C((6.4, 12.8), 1.3, a)]
        dots = [(7, 5, shade(c, 1.5)), (5, 8, shade(c, 1.5))]
    elif kind == 'staff':
        parts = [L((3.2, 14.2), (9.4, 6.6), 2.0, WOOD),
                 P([(5.6, 6.0), (6.4, 2.8), (10.0, 0.9), (13.6, 2.4), (14.6, 5.4), (13.6, 6.4), (9.0, 6.0)], c),
                 C((10.6, 8.2), 1.9, '#7affd8'), L((9.0, 6.2), (11.0, 6.9), 1.0, a, noline=True)]
        dots = [(9, 3, WHITE), (12, 3, WHITE), (11, 5, WHITE), (7, 5, WHITE), (10, 8, WHITE)]
    elif kind in ('helmet', 'chest', 'legs', 'boots'):
        d = deco or {}
        cap = d.get('cap', None); glow = d.get('glow', '#ffffff')
        if kind == 'helmet':
            parts = [P([(2.6, 12.6), (2.4, 7.0), (4.2, 3.8), (8, 2.6), (11.8, 3.8), (13.6, 7.0), (13.4, 12.6), (10.8, 12.6), (10.6, 9.6), (5.4, 9.6), (5.2, 12.6)], c),
                     R((4.8, 7.0, 11.2, 9.4), '#1b1626'), R((2.6, 5.6, 13.4, 6.8), a, noline=True)]
            dots = [(6, 8, glow), (9, 8, glow)]
            if cap: parts += [P([(3.6, 3.8), (4.6, 1.6), (8, 0.4), (11.4, 1.6), (12.4, 3.8)], cap, noline=False)]; dots += [(6, 2, WHITE), (9, 1, WHITE), (11, 3, WHITE)]
        elif kind == 'chest':
            parts = [P([(0.8, 3.6), (4.8, 2.0), (6.8, 3.4), (9.2, 3.4), (11.2, 2.0), (15.2, 3.6), (15.2, 8.0), (12.6, 8.4), (12.6, 14.4), (3.4, 14.4), (3.4, 8.4), (0.8, 8.0)], c),
                     R((3.6, 10.6, 12.4, 12.0), a, noline=True), C((8, 7.4), 1.8, glow), L((1.0, 4.4), (4.4, 3.4), 1.0, a, noline=True), L((15.0, 4.4), (11.6, 3.4), 1.0, a, noline=True)]
            dots = [(8, 7, WHITE)]
            if cap: dots += [(3, 6, WHITE), (13, 6, WHITE)]
        elif kind == 'legs':
            parts = [P([(3.2, 1.6), (12.8, 1.6), (12.8, 6.6), (12.8, 14.4), (8.8, 14.4), (8.4, 7.0), (7.6, 7.0), (7.2, 14.4), (3.2, 14.4)], c),
                     R((3.2, 2.2, 12.8, 3.8), a, noline=True), C((5.2, 10.2), 1.2, glow, noline=True), C((10.8, 10.2), 1.2, glow, noline=True)]
            dots = [(8, 3, WHITE)]
        else:
            parts = [P([(2.4, 4.6), (6.6, 4.6), (6.6, 10.2), (8.2, 10.4), (8.2, 13.8), (2.4, 13.8)], c),
                     P([(9.4, 4.6), (13.6, 4.6), (13.6, 13.8), (7.8, 13.8), (7.8, 10.4), (9.4, 10.2)], c),
                     R((2.4, 4.6, 6.6, 6.2), a, noline=True), R((9.4, 4.6, 13.6, 6.2), a, noline=True)]
            dots = [(4, 12, glow), (11, 12, glow)]
    elif kind == 'gem':
        parts = [P([(2.4, 11.0), (3.4, 6.6), (5.4, 6.0), (5.6, 12.2), (4.0, 13.4)], shade(c, 0.9)), P([(10.4, 12.2), (10.6, 6.2), (12.6, 6.8), (13.8, 11.0), (12.2, 13.4)], shade(c, 0.9)),
                 P([(8, 0.8), (11.0, 3.6), (11.0, 11.4), (8, 15.0), (5.0, 11.4), (5.0, 3.6)], c), P([(8, 1.8), (5.8, 4.0), (5.8, 11.0), (8, 13.6)], shade(c, 1.4), noline=True)]
        dots = [(8, 3, WHITE), (7, 5, WHITE), (4, 7, WHITE), (13, 8, '#e8d0ff')]
    elif kind == 'orb':
        parts = [R((6.2, 1.8, 9.8, 4.6), '#9a6a3a'), P([(6.0, 4.4), (10.0, 4.4), (13.0, 8.4), (12.6, 12.6), (8, 14.8), (3.4, 12.6), (3.0, 8.4)], GLASS),
                 P([(3.6, 9.2), (6, 8.0), (8, 9.0), (10, 8.0), (12.4, 9.2), (12.4, 12.4), (8, 14.4), (3.6, 12.4)], c, noline=True)]
        dots = [(5, 7, WHITE), (5, 6, WHITE), (7, 11, WHITE), (10, 12, shade(c, 1.6)), (9, 10, shade(c, 1.6)), (12, 7, shade(c, 1.4))]
    elif kind == 'ore':
        parts = [P([(1.6, 11.6), (2.4, 6.6), (6.0, 5.2), (8.0, 9.0), (7.4, 13.4), (3.2, 14.0)], '#8d8698'), P([(7.0, 9.0), (8.6, 4.4), (13.0, 4.2), (14.6, 8.4), (13.0, 13.4), (8.6, 13.6)], '#7c7588'),
                 P([(4.6, 6.2), (6.6, 1.8), (10.4, 2.4), (11.4, 6.0), (8.0, 8.4)], '#9b94a8'),
                 P([(8.6, 6.4), (10.0, 5.4), (11.8, 7.4), (10.4, 9.6), (9.0, 8.8)], c), P([(3.4, 9.0), (4.8, 8.4), (5.6, 10.6), (4.2, 11.6)], c), P([(6.6, 3.2), (8.0, 2.8), (8.4, 4.4), (7.2, 5.0)], c)]
        dots = [(9, 6, WHITE), (4, 9, WHITE), (7, 3, WHITE)]
    elif kind == 'core':
        parts = [C((8, 8), 6.4, '#4a3a6a'), C((8, 8), 5.0, c), C((8, 8), 2.6, WHITE, noline=True), L((8, 2.0), (8, 14.0), 0.8, shade(c, 0.6), noline=True), L((2.0, 8), (14.0, 8), 0.8, shade(c, 0.6), noline=True)]
        dots = [(5, 5, shade(c, 1.5)), (11, 5, shade(c, 1.5)), (5, 11, shade(c, 1.5)), (11, 11, shade(c, 1.5)), (8, 8, '#ffffff')]
    elif kind == 'shard':
        parts = [P([(3.4, 14.0), (5.2, 6.0), (8.4, 1.4), (11.6, 5.4), (12.8, 14.0)], c), P([(5.4, 13.0), (6.4, 6.6), (8.4, 3.2), (8.8, 13.0)], shade(c, 1.3), noline=True)]
        dots = [(9, 6, '#8dffb0'), (10, 9, '#8dffb0'), (7, 11, '#8dffb0'), (8, 8, '#8dffb0'), (9, 12, WHITE)]
    elif kind == 'stone':
        parts = [P([(2.4, 11.0), (2.6, 6.0), (5.4, 3.0), (10.6, 3.0), (13.4, 6.0), (13.6, 11.0), (10.6, 13.6), (5.4, 13.6)], '#8a8498'), P([(4.0, 4.6), (7.0, 3.6), (9.0, 4.4), (6.0, 6.2)], '#a9a3b8', noline=True),
                 R((5.0, 7.0, 7.2, 8.8), c, noline=True), R((9.0, 7.0, 11.2, 8.8), c, noline=True), L((6.2, 11.2), (9.8, 11.2), 0.9, shade(c, 0.8), noline=True)]
        dots = [(6, 7, WHITE), (10, 7, WHITE), (12, 9, c), (3, 10, c), (8, 5, c)]
    elif kind == 'heart':
        parts = [P([(8, 14.4), (1.8, 8.4), (1.6, 5.0), (3.6, 2.6), (6.4, 2.6), (8, 4.6), (9.6, 2.6), (12.4, 2.6), (14.4, 5.0), (14.2, 8.4)], c),
                 P([(3.6, 4.0), (5.4, 3.8), (6.6, 5.4), (4.2, 6.4)], shade(c, 1.45), noline=True)]
        dots = [(9, 5, WHITE), (11, 8, WHITE), (7, 9, WHITE), (6, 12, shade(c, 0.8)), (12, 4, '#ffd0ea')]
    elif kind in ('meat', 'cooked'):
        parts = [L((11.4, 4.6), (14.6, 1.6), 2.6, '#f1e8d8'), C((14.2, 1.8), 1.7, '#f1e8d8'), C((15, 3.2), 1.2, '#f1e8d8'),
                 E((7.4, 9.0), 6.0, 4.8, c), E((6.4, 7.6), 3.2, 2.0, shade(c, 1.3), noline=True)]
        dots = [(8, 10, WHITE if kind == 'meat' else '#f4c58a'), (5, 11, WHITE if kind == 'meat' else '#f4c58a'), (10, 8, '#f6a0b8' if kind == 'meat' else '#7a3a26')]
    else:
        parts = [C((8, 8), 5, c)]
    return compose(parts, dots, seed)

def egg_icon(main, spot, seed, accent=None):
    """Huevo generador tipo Minecraft: huevo con manchas, colores de la criatura."""
    rng = random.Random(seed)
    egg = E((8, 8.8), 5.0, 6.4, main)
    img = compose([egg, P([(8, 1.6), (11.4, 5.0), (4.6, 5.0)], main, noline=True)], [])
    px = img.load()
    inside = [(x, y) for y in range(16) for x in range(16) if px[x, y][3] and px[x, y][:3] != mix(main, (10, 8, 18), 0.58)]
    # manchas del segundo color
    for _ in range(6):
        cx, cy = rng.choice(inside)
        for dx, dy in rng.choice([[(0, 0), (1, 0)], [(0, 0), (0, 1), (1, 1)], [(0, 0)], [(0, 0), (1, 0), (0, 1)]]):
            x, y = cx+dx, cy+dy
            if 0 <= x < 16 and 0 <= y < 16 and (x, y) in inside:
                px[x, y] = shade(spot, 0.92 + 0.15*((x+y) % 2)) + (255,)
    if accent:
        for _ in range(3):
            cx, cy = rng.choice(inside); px[cx, cy] = hexrgb(accent) + (255,)
    # brillo
    for (x, y) in ((5, 5), (5, 6), (6, 4)):
        if px[x, y][3] and (x, y) in inside: px[x, y] = shade(main, 1.5) + (255,)
    return img
