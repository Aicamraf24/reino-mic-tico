from main2 import *
import structs as ST

def ci(h):
    r, g, b = hexrgb(h); v = (255 << 24) | (r << 16) | (g << 8) | b  # ARGB opaco (26.1: alfa 0 = invisible, p. ej. el agua)
    return v - (1 << 32) if v >= (1 << 31) else v
def sb(name, props=None):
    d = {'Name': name}
    if props: d['Properties'] = props
    return d
def ssp(name): return {'type': 'minecraft:simple_state_provider', 'state': sb(name)}
def wsp(entries): return {'type': 'minecraft:weighted_state_provider', 'entries': [{'weight': w, 'data': sb(n)} for n, w in entries]}
def pf(rel, obj): wjson(f'{DATA}/worldgen/{rel}.json', obj)
BM = lambda i: f'{MOD}:{i}'
def surface_placement(count, extra=()):
    return [{'type': 'minecraft:count', 'count': count}, {'type': 'minecraft:in_square'}, {'type': 'minecraft:heightmap', 'heightmap': 'WORLD_SURFACE_WG'}] + list(extra) + [{'type': 'minecraft:biome'}]
HR = lambda a, b: {'type': 'minecraft:height_range', 'height': {'type': 'minecraft:uniform', 'min_inclusive': {'absolute': a}, 'max_inclusive': {'absolute': b}}}

# ---------------------------------------------------------------- features
PATCH_TRIES = {}
def patch_mods(tries, xz=5, y=2):
    return [{'type': 'minecraft:count', 'count': tries},
            {'type': 'minecraft:random_offset', 'xz_spread': {'type': 'minecraft:uniform', 'min_inclusive': -xz, 'max_inclusive': xz}, 'y_spread': {'type': 'minecraft:uniform', 'min_inclusive': -y, 'max_inclusive': y}},
            {'type': 'minecraft:block_predicate_filter', 'predicate': {'type': 'minecraft:all_of', 'predicates': [{'type': 'minecraft:matching_blocks', 'blocks': 'minecraft:air'}, {'type': 'minecraft:solid', 'offset': [0, -1, 0]}]}}]
def gen_features():
    # --- arboles / hongos gigantes
    def tree(name, trunk, leaf, kind='dark'):
        if kind == 'dark':
            cfg = {'trunk_placer': {'type': 'minecraft:dark_oak_trunk_placer', 'base_height': 9, 'height_rand_a': 3, 'height_rand_b': 3},
                   'foliage_placer': {'type': 'minecraft:dark_oak_foliage_placer', 'radius': 3, 'offset': 0},
                   'minimum_size': {'type': 'minecraft:three_layers_feature_size', 'limit': 1, 'lower_size': 0, 'middle_size': 1, 'upper_size': 2}}
        elif kind == 'small':
            cfg = {'trunk_placer': {'type': 'minecraft:straight_trunk_placer', 'base_height': 4, 'height_rand_a': 2, 'height_rand_b': 1},
                   'foliage_placer': {'type': 'minecraft:blob_foliage_placer', 'radius': 2, 'offset': 0, 'height': 3},
                   'minimum_size': {'type': 'minecraft:two_layers_feature_size', 'limit': 1, 'lower_size': 0, 'upper_size': 1}}
        else:  # fancy
            cfg = {'trunk_placer': {'type': 'minecraft:fancy_trunk_placer', 'base_height': 3, 'height_rand_a': 11, 'height_rand_b': 0},
                   'foliage_placer': {'type': 'minecraft:fancy_foliage_placer', 'radius': 2, 'offset': 4, 'height': 4},
                   'minimum_size': {'type': 'minecraft:two_layers_feature_size', 'limit': 0, 'lower_size': 0, 'upper_size': 0}}
        cfg.update({'trunk_provider': ssp(trunk), 'foliage_provider': ssp(leaf), 'ignore_vines': True, 'decorators': []})
        pf(f'configured_feature/{name}', {'type': 'minecraft:tree', 'config': cfg})
        pf(f'placed_feature/{name}', {'feature': BM(name), 'placement': []})
    T, S, L, R = BM('tallo_hongo'), BM('tallo_luminoso'), BM('sombrero_luminoso'), BM('sombrero_rosa')
    tree('hongo_gigante_carmesi', T, BM('sombrero_carmesi'))
    tree('hongo_gigante_violeta', T, BM('sombrero_violeta'))
    tree('hongo_gigante_luminoso', S, L)
    tree('hongo_gigante_rosa', T, R)
    tree('hongo_mediano_carmesi', T, BM('sombrero_carmesi'), 'small')
    tree('hongo_mediano_violeta', T, BM('sombrero_violeta'), 'small')
    tree('hongo_mediano_luminoso', S, L, 'small')
    tree('arbol_micotico', BM('tronco_gigante'), BM('hojas_fungales'), 'fancy')
    tree('arbol_luminoso', BM('tronco_gigante'), BM('hojas_luminosas'), 'fancy')
    for nm, cap, kind in (('hongo_colosal_rojo', 'sombrero_carmesi', 'huge_red_mushroom'), ('hongo_colosal_violeta', 'sombrero_violeta', 'huge_brown_mushroom')):
        pf(f'configured_feature/{nm}', {'type': f'minecraft:{kind}', 'config': {'cap_provider': ssp(BM(cap)), 'stem_provider': ssp(BM('tallo_hongo')), 'foliage_radius': 4,
              'can_place_on': {'type': 'minecraft:matching_block_tag', 'tag': 'minecraft:dirt'}}})
        pf(f'placed_feature/{nm}', {'feature': BM(nm), 'placement': []})
    def selector(name, feats, default):
        pf(f'configured_feature/{name}', {'type': 'minecraft:random_selector', 'config': {'features': [{'feature': BM(f), 'chance': c} for f, c in feats], 'default': BM(default)}})
    selector('bosque_carmesi_hongos', [('hongo_gigante_carmesi', 0.35), ('hongo_colosal_rojo', 0.2), ('hongo_mediano_carmesi', 0.3)], 'hongo_gigante_rosa')
    selector('bosque_violeta_hongos', [('hongo_gigante_violeta', 0.4), ('hongo_colosal_violeta', 0.2), ('hongo_mediano_violeta', 0.2)], 'arbol_micotico')
    selector('jardines_hongos', [('hongo_gigante_luminoso', 0.4), ('hongo_mediano_luminoso', 0.3), ('arbol_luminoso', 0.15)], 'hongo_gigante_rosa')
    selector('montanas_hongos', [('hongo_gigante_violeta', 0.3), ('hongo_colosal_rojo', 0.2), ('hongo_gigante_carmesi', 0.2)], 'hongo_mediano_violeta')
    selector('pantano_hongos', [('hongo_mediano_violeta', 0.4), ('arbol_micotico', 0.3)], 'hongo_mediano_carmesi')
    selector('praderas_hongos', [('hongo_mediano_carmesi', 0.3), ('hongo_mediano_violeta', 0.3), ('hongo_mediano_luminoso', 0.2)], 'hongo_mediano_carmesi')
    selector('corazon_hongos', [('hongo_colosal_violeta', 0.3), ('arbol_micotico', 0.3)], 'hongo_mediano_violeta')
    for n in ('bosque_carmesi_hongos', 'bosque_violeta_hongos', 'jardines_hongos', 'montanas_hongos', 'pantano_hongos', 'praderas_hongos', 'corazon_hongos'):
        pass
    # --- parches de plantas
    def patch(name, entries, tries=40):
        # 26.1 elimino random_patch: el parche se expresa con modificadores count + random_offset (ver gen de placed_feature)
        pf(f'configured_feature/{name}', {'type': 'minecraft:simple_block', 'config': {'to_place': wsp(entries)}})
        PATCH_TRIES[name] = tries
    patch('plantas_carmesi', [(BM('hongo_carmesi'), 4), (BM('hierba_micotica'), 6), (BM('hongo_venenoso'), 1)])
    patch('plantas_violeta', [(BM('hongo_violeta'), 4), (BM('hierba_micotica'), 6), (BM('planta_luminosa'), 2)])
    patch('plantas_luminosas', [(BM('hongo_luminoso'), 5), (BM('planta_luminosa'), 4), (BM('hierba_micotica'), 3)], 56)
    patch('plantas_pantano', [(BM('hongo_venenoso'), 5), (BM('hierba_micotica'), 4), (BM('hongo_violeta'), 1)])
    patch('plantas_cueva', [(BM('hongo_luminoso'), 5), (BM('cristales_micoticos'), 3), (BM('hongo_violeta'), 2)], 30)
    patch('plantas_corazon', [(BM('hongo_venenoso'), 4), (BM('hierba_micotica'), 2), (BM('cristales_micoticos'), 1)])
    # --- minerales
    def ore(name, block, size, deep=True):
        tg = [{'target': {'predicate_type': 'minecraft:tag_match', 'tag': 'minecraft:stone_ore_replaceables'}, 'state': sb(block)},
              {'target': {'predicate_type': 'minecraft:tag_match', 'tag': 'minecraft:deepslate_ore_replaceables'}, 'state': sb(block)}]
        pf(f'configured_feature/{name}', {'type': 'minecraft:ore', 'config': {'size': size, 'discard_chance_on_air_exposure': 0.0, 'targets': tg}})
    ore('ore_carmesi', BM('mena_carmesi'), 9); ore('ore_violeta', BM('mena_violeta'), 9); ore('ore_cristal', BM('mena_cristal'), 6)
    ore('ore_viviente', BM('mena_piedra_viviente'), 8); ore('ore_corazon', BM('mena_corazon'), 4)
    ore('ore_cristal_bloque', BM('bloque_cristal_micotico'), 14)
    ore('ore_carbon', 'minecraft:coal_ore', 17); ore('ore_hierro', 'minecraft:iron_ore', 9); ore('ore_oro', 'minecraft:gold_ore', 9)
    ore('ore_diamante', 'minecraft:diamond_ore', 5); ore('ore_redstone', 'minecraft:redstone_ore', 8); ore('ore_lapis', 'minecraft:lapis_ore', 7)
    tgs = [{'target': {'predicate_type': 'minecraft:tag_match', 'tag': 'minecraft:base_stone_overworld'}, 'state': sb(BM('piedra_fungosa'))}]
    pf('configured_feature/vetas_fungosas', {'type': 'minecraft:ore', 'config': {'size': 48, 'discard_chance_on_air_exposure': 0.0, 'targets': tgs}})
    tgs = [{'target': {'predicate_type': 'minecraft:tag_match', 'tag': 'minecraft:base_stone_overworld'}, 'state': sb(BM('piedra_podrida'))}]
    pf('configured_feature/vetas_podridas', {'type': 'minecraft:ore', 'config': {'size': 40, 'discard_chance_on_air_exposure': 0.0, 'targets': tgs}})
    def pl(name, count, lo, hi, rarity=None):
        pm = []
        if rarity: pm.append({'type': 'minecraft:rarity_filter', 'chance': rarity})
        pm += [{'type': 'minecraft:count', 'count': count}, {'type': 'minecraft:in_square'}, HR(lo, hi), {'type': 'minecraft:biome'}]
        pf(f'placed_feature/{name}', {'feature': BM(name), 'placement': pm})
    pl('ore_carmesi', 14, -30, 80); pl('ore_violeta', 14, -30, 80); pl('ore_cristal', 8, -50, 40); pl('ore_viviente', 8, -40, 60)
    pl('ore_corazon', 3, -50, 20, 2); pl('ore_cristal_bloque', 6, -40, 30)
    pl('ore_carbon', 16, 0, 120); pl('ore_hierro', 12, -30, 70); pl('ore_oro', 4, -50, 30); pl('ore_diamante', 3, -60, 12); pl('ore_redstone', 6, -50, 15); pl('ore_lapis', 3, -30, 30)
    pl('vetas_fungosas', 50, -50, 140); pl('vetas_podridas', 55, -50, 140)
    # --- decoracion de cuevas
    scan = {'type': 'minecraft:environment_scan', 'direction_of_search': 'down', 'max_steps': 14,
            'target_condition': {'type': 'minecraft:solid'}, 'allowed_search_condition': {'type': 'minecraft:matching_blocks', 'blocks': 'minecraft:air'}}
    for n in ('plantas_cueva',):
        pf(f'placed_feature/{n}', {'feature': BM(n), 'placement': [{'type': 'minecraft:count', 'count': 24}, {'type': 'minecraft:in_square'}, HR(-50, 50), scan] + patch_mods(PATCH_TRIES['plantas_cueva'], 4, 2) + [{'type': 'minecraft:biome'}]})
    # --- parches superficiales (aspecto micelio)
    def disk(name, state, target_blocks, r=(3, 6)):
        pf(f'configured_feature/{name}', {'type': 'minecraft:disk', 'config': {'state_provider': {'type': 'minecraft:rule_based_state_provider', 'fallback': ssp(state), 'rules': []},
           'target': {'type': 'minecraft:matching_blocks', 'blocks': target_blocks}, 'radius': {'type': 'minecraft:uniform', 'min_inclusive': r[0], 'max_inclusive': r[1]}, 'half_height': 2}})
        pf(f'placed_feature/{name}', {'feature': BM(name), 'placement': surface_placement(10)})
    tg = ['minecraft:grass_block', 'minecraft:dirt', 'minecraft:coarse_dirt']
    disk('micelio_carmesi_parche', BM('micelio_carmesi'), tg); disk('micelio_violeta_parche', BM('micelio_violeta'), tg)
    disk('tierra_fungosa_parche', BM('tierra_fungosa'), tg); disk('arena_esporifera_parche', BM('arena_esporifera'), tg, (3, 5))
    disk('piedra_podrida_parche', BM('piedra_podrida'), tg, (3, 7)); disk('piedra_fungosa_parche', BM('piedra_fungosa'), tg, (3, 6))
    # --- tipos de colocacion de arboles
    def treep(name, count, sel):
        pf(f'placed_feature/{name}', {'feature': BM(sel), 'placement': [{'type': 'minecraft:count', 'count': count}, {'type': 'minecraft:in_square'},
            {'type': 'minecraft:surface_water_depth_filter', 'max_water_depth': 0}, {'type': 'minecraft:heightmap', 'heightmap': 'OCEAN_FLOOR'}, {'type': 'minecraft:biome'}]})
    treep('arboles_carmesi', 7, 'bosque_carmesi_hongos'); treep('arboles_violeta', 7, 'bosque_violeta_hongos'); treep('arboles_jardines', 6, 'jardines_hongos')
    treep('arboles_montanas', 3, 'montanas_hongos'); treep('arboles_pantano', 3, 'pantano_hongos'); treep('arboles_praderas', 1, 'praderas_hongos'); treep('arboles_corazon', 2, 'corazon_hongos')
    def patchp(name, cfg, count, rarity=None):
        pm = ([{'type': 'minecraft:rarity_filter', 'chance': rarity}] if rarity else []) + [{'type': 'minecraft:count', 'count': count}, {'type': 'minecraft:in_square'}, {'type': 'minecraft:heightmap', 'heightmap': 'WORLD_SURFACE_WG'}] + patch_mods(PATCH_TRIES[cfg]) + [{'type': 'minecraft:biome'}]
        pf(f'placed_feature/{name}_s', {'feature': BM(cfg), 'placement': pm})
    for n, c in (('plantas_carmesi', 6), ('plantas_violeta', 6), ('plantas_luminosas', 8), ('plantas_pantano', 7), ('plantas_corazon', 5)): patchp(n, n, c)
    patchp('plantas_praderas', 'plantas_violeta', 12); patchp('plantas_montanas', 'plantas_carmesi', 3)

BIOMES = {  # id: (temp, down, water, fog, sky, grass, foliage, particle, clima, arboles, plantas, parches, extras)
 'bosque_carmesi': dict(t=0.8, d=0.5, water='#b84a6a', fog='#8a3050', sky='#c06080', grass='#b8283a', fol='#d0384a', part='crimson_spore',
                        trees=['arboles_carmesi'], plants=['plantas_carmesi_s'], disks=['micelio_carmesi_parche', 'tierra_fungosa_parche'],
                        clim=dict(temperature=[0.15, 0.7], humidity=[-0.2, 0.35], continentalness=[-0.1, 0.5], erosion=[-0.5, 0.4], weirdness=[-1, 1])),
 'bosque_violeta': dict(t=0.6, d=0.6, water='#8a4ad0', fog='#5a2a8a', sky='#8a5ad0', grass='#8a3ac0', fol='#a04ad8', part='spore_blossom_air',
                        trees=['arboles_violeta'], plants=['plantas_violeta_s'], disks=['micelio_violeta_parche'],
                        clim=dict(temperature=[-0.6, 0.1], humidity=[0.0, 0.7], continentalness=[-0.1, 0.5], erosion=[-0.5, 0.4], weirdness=[-1, 1])),
 'praderas_micelio': dict(t=0.7, d=0.3, water='#a070e0', fog='#9a70c0', sky='#a890e0', grass='#9a50c8', fol='#b060d8', part='spore_blossom_air',
                          trees=['arboles_praderas'], plants=['plantas_praderas_s'], disks=['micelio_violeta_parche', 'micelio_carmesi_parche'],
                          clim=dict(temperature=[-0.4, 0.4], humidity=[-0.9, -0.1], continentalness=[-0.2, 0.4], erosion=[0.1, 1.0], weirdness=[-1, 1])),
 'pantano_esporifero': dict(t=0.8, d=0.9, water='#5aa030', fog='#3a5a20', sky='#6a8a50', grass='#6a9a2a', fol='#7ab030', part='warped_spore',
                            trees=['arboles_pantano'], plants=['plantas_pantano_s'], disks=['arena_esporifera_parche', 'tierra_fungosa_parche'],
                            clim=dict(temperature=[0.0, 0.6], humidity=[0.5, 1.0], continentalness=[-1.0, -0.1], erosion=[0.2, 1.0], weirdness=[-1, 1])),
 'montanas_fungales': dict(t=0.3, d=0.4, water='#6a6ad0', fog='#6a60a0', sky='#9a90c8', grass='#8a60c0', fol='#9a70d0', part='spore_blossom_air',
                           trees=['arboles_montanas'], plants=['plantas_montanas_s'], disks=['piedra_fungosa_parche', 'micelio_violeta_parche'],
                           clim=dict(temperature=[-0.5, 0.3], humidity=[-0.5, 0.4], continentalness=[0.3, 1.0], erosion=[-1.0, -0.3], weirdness=[-1, 1])),
 'jardines_bioluminiscentes': dict(t=0.9, d=0.8, water='#20d0ff', fog='#3050c0', sky='#5a70e0', grass='#30c8e0', fol='#40d8f0', part='glow',
                                   trees=['arboles_jardines'], plants=['plantas_luminosas_s'], disks=['micelio_violeta_parche'],
                                   clim=dict(temperature=[0.4, 1.0], humidity=[0.3, 1.0], continentalness=[0.0, 0.6], erosion=[-0.2, 0.6], weirdness=[-1, 1])),
 'cavernas_micoticas': dict(t=0.7, d=0.5, water='#4ad0ff', fog='#2a2060', sky='#3a2a80', grass='#8a50c0', fol='#8a50c0', part='glow', trees=[], plants=[], disks=[],
                            clim=dict(temperature=[-1, 1], humidity=[-1, 1], continentalness=[-1, 1], erosion=[-1, 1], weirdness=[-1, 1], depth=[0.2, 1.0])),
 'corazon_podrido': dict(t=0.9, d=0.2, water='#4a5a3a', fog='#2a2a1a', sky='#4a4a40', grass='#5a6a2a', fol='#5a6a2a', part='warped_spore',
                         trees=['arboles_corazon'], plants=['plantas_corazon_s'], disks=['piedra_podrida_parche'],
                         clim=dict(temperature=[0.5, 1.0], humidity=[-1.0, -0.3], continentalness=[0.2, 1.0], erosion=[-0.7, 0.0], weirdness=[-1, 1])),
}

def gen_biomes():
    ALLC = ['minecraft:cave', 'minecraft:cave_extra_underground', 'minecraft:canyon']
    entries = []
    for bid, b in BIOMES.items():
        step = [[] for _ in range(11)]
        ores = ['ore_carmesi', 'ore_violeta', 'ore_cristal', 'ore_viviente', 'ore_cristal_bloque', 'ore_carbon', 'ore_hierro', 'ore_oro', 'ore_diamante', 'ore_redstone', 'ore_lapis',
                'vetas_podridas' if bid == 'corazon_podrido' else 'vetas_fungosas']
        if bid in ('corazon_podrido', 'cavernas_micoticas'): ores.append('ore_corazon')
        step[6] = [BM(o) for o in ores]
        step[7] = [BM('plantas_cueva')]
        step[8] = ['minecraft:spring_water']
        step[9] = [BM(t) for t in b['trees']] + [BM(p) for p in b['plants']]
        step[10] = [BM(d) for d in b['disks']]
        spawners = {k: [] for k in ('monster', 'creature', 'ambient', 'axolotls', 'underground_water_creature', 'water_creature', 'water_ambient', 'misc')}
        for s in ALL:
            for (bb, w, mn, mx) in s.get('biomes', []):
                if bb == bid:
                    cat = 'monster' if s['cat'] in ('hostile', 'boss') else 'creature'
                    spawners[cat].append({'type': f'{MOD}:{s["id"]}', 'weight': w, 'minCount': mn, 'maxCount': mx})
        eff = {'fog_color': ci(b['fog']), 'sky_color': ci(b['sky']), 'water_color': ci(b['water']), 'water_fog_color': ci(b['water']),
               'grass_color': ci(b['grass']), 'foliage_color': ci(b['fol']),
               'particle': {'options': {'type': f'minecraft:{b["part"]}'}, 'probability': 0.006}}
        pf(f'biome/{bid}', {'has_precipitation': False, 'temperature': b['t'], 'downfall': b['d'], 'effects': eff, 'attributes': {'minecraft:visual/fog_color': b['fog'], 'minecraft:visual/sky_color': b['sky']}, 'spawners': spawners, 'spawn_costs': {}, 'carvers': ALLC, 'features': step})
        c = b['clim']
        entries.append({'biome': f'{MOD}:{bid}', 'parameters': {'temperature': c['temperature'], 'humidity': c['humidity'], 'continentalness': c['continentalness'],
                        'erosion': c['erosion'], 'depth': c.get('depth', [-0.05, 0.15]) if bid != 'cavernas_micoticas' else c['depth'], 'weirdness': c['weirdness'], 'offset': 0.0}})
    # etiquetas de bioma para estructuras
    surface = [f'{MOD}:{k}' for k in BIOMES if k != 'cavernas_micoticas']
    TAGS = {'aldea': ['bosque_carmesi', 'praderas_micelio', 'bosque_violeta'], 'ciudad': ['jardines_bioluminiscentes', 'bosque_violeta'],
            'templo': ['praderas_micelio', 'bosque_carmesi', 'montanas_fungales'], 'torre': ['bosque_violeta', 'jardines_bioluminiscentes', 'bosque_carmesi'],
            'puente': ['bosque_carmesi', 'bosque_violeta', 'jardines_bioluminiscentes', 'pantano_esporifero'], 'laboratorio': ['pantano_esporifero', 'praderas_micelio'],
            'nido': ['bosque_carmesi', 'montanas_fungales', 'pantano_esporifero'], 'tesoro': ['cavernas_micoticas', 'corazon_podrido'],
            'jardin': ['jardines_bioluminiscentes', 'bosque_violeta'], 'santuario': ['montanas_fungales', 'jardines_bioluminiscentes'],
            'ruinas': [k for k in BIOMES if k != 'cavernas_micoticas'], 'trono': ['corazon_podrido'], 'isla': [k for k in BIOMES if k != 'cavernas_micoticas']}
    for n, v in TAGS.items(): wjson(f'{DATA}/tags/worldgen/biome/has_structure/{n}.json', {'values': [f'{MOD}:{b}' for b in v]})
    wjson(f'{DATA}/dimension/reino_micotico.json', {'type': 'minecraft:overworld', 'generator': {'type': 'minecraft:noise', 'settings': 'minecraft:overworld',
          'biome_source': {'type': 'minecraft:multi_noise', 'biomes': entries}}})

STRUCTS = [  # nombre archivo, funcion, tag, paso, adaptacion, start_height, separacion (spacing,sep), salt
 ('aldea_micotica', 'aldea', 'aldea', 'surface_structures', 'beard_thin', 'surf', (22, 8)),
 ('ciudad_hongos', 'ciudad', 'ciudad', 'surface_structures', 'beard_thin', 'surf', (40, 14)),
 ('templo_micelio', 'templo', 'templo', 'surface_structures', 'beard_thin', 'surf', (28, 10)),
 ('torre_gigante', 'torre', 'torre', 'surface_structures', 'beard_thin', 'surf', (20, 7)),
 ('puente_raices', 'puente', 'puente', 'surface_structures', 'beard_thin', 'surf', (18, 6)),
 ('laboratorio_esporas', 'laboratorio', 'laboratorio', 'surface_structures', 'beard_thin', 'surf', (26, 9)),
 ('nido_criaturas', 'nido', 'nido', 'surface_structures', 'beard_thin', 'surf', (14, 5)),
 ('cueva_tesoro', 'cueva', 'tesoro', 'underground_structures', 'bury', 'under', (12, 4)),
 ('jardin_secreto', 'jardin', 'jardin', 'surface_structures', 'beard_thin', 'surf', (20, 7)),
 ('santuario_micelio', 'santuario', 'santuario', 'surface_structures', 'beard_thin', 'surf', (30, 11)),
 ('ruinas_antiguas', 'ruinas', 'ruinas', 'surface_structures', 'beard_thin', 'surf', (16, 6)),
 ('trono_micelio', 'trono', 'trono', 'surface_structures', 'beard_thin', 'surf', (10, 4)),
 ('isla_flotante', 'isla', 'isla', 'surface_structures', 'none', 'sky', (9, 3)),
]
def egg_indexes():
    ids = [s['id'] for s in ALL]
    return [ids.index(x) for x in ('tortuga_fungosa', 'luciernaga_gigante', 'rana_bioluminiscente', 'escarabajo_colosal', 'arana_esporifera', 'caracol_cristal')]

def gen_structures():
    for n, (fname, fn, tag, step, adapt, sh, (sp, sep)) in enumerate(STRUCTS):
        v = ST.nido(egg_indexes()) if fn == 'nido' else getattr(ST, fn)()
        fp = path(f'{DATA}/structure/{fname}.nbt'); os.makedirs(os.path.dirname(fp), exist_ok=True)
        open(fp, 'wb').write(v.to_nbt())
        wjson(f'{DATA}/worldgen/template_pool/{fname}.json', {'fallback': 'minecraft:empty', 'elements': [{'weight': 1, 'element': {
            'element_type': 'minecraft:single_pool_element', 'location': f'{MOD}:{fname}', 'processors': 'minecraft:empty', 'projection': 'rigid'}}]})
        s = {'type': 'minecraft:jigsaw', 'biomes': f'#{MOD}:has_structure/{tag}', 'step': step, 'spawn_overrides': {}, 'terrain_adaptation': adapt,
             'start_pool': f'{MOD}:{fname}', 'size': 1, 'max_distance_from_center': 80, 'use_expansion_hack': False}
        if sh == 'surf': s['start_height'] = {'absolute': -ST.F}; s['project_start_to_heightmap'] = 'WORLD_SURFACE_WG'
        elif sh == 'sky': s['start_height'] = {'type': 'minecraft:uniform', 'min_inclusive': {'absolute': 100}, 'max_inclusive': {'absolute': 150}}
        else: s['start_height'] = {'type': 'minecraft:uniform', 'min_inclusive': {'absolute': -40}, 'max_inclusive': {'absolute': 20}}
        wjson(f'{DATA}/worldgen/structure/{fname}.json', s)
        wjson(f'{DATA}/worldgen/structure_set/{fname}.json', {'structures': [{'structure': f'{MOD}:{fname}', 'weight': 1}],
              'placement': {'type': 'minecraft:random_spread', 'spacing': sp, 'separation': sep, 'salt': 7000 + n*131}})
        LANG[f'structure.{MOD}.{fname}'] = fname.replace('_', ' ').title()
