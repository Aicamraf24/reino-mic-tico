import random, math
from PIL import Image, ImageDraw
from util import *

# ======================================================================= BLOQUES
# (id, nombre, kind, estilo/colores, dureza, herramienta, luz, sonido)
C = dict(carmesi='#c23a4a', violeta='#7c3fbf', cian='#2fd5ff', rosa='#e24fa0', piedra='#6b6478', podrida='#47553a',
         tierra='#5a4258', madera='#9a6aa8', corteza='#5a3a4a', hongo='#e8dcc8', esporas='#e8c0ff', veneno='#7aff4a',
         cristal='#b57cf0', ladrillo='#7a5a8a', raiz='#6a4a30', arena='#d8c8e8')

BLOCKS = [
 dict(id='micelio_carmesi', name='Micelio Carmesí', kind='bt', st=('myc', C['carmesi']), hard=0.6, tool='shovel', snd='GRASS', drop='self', dirt=True),
 dict(id='micelio_violeta', name='Micelio Violeta', kind='bt', st=('myc', C['violeta']), hard=0.6, tool='shovel', snd='GRASS', drop='self', dirt=True),
 dict(id='tierra_fungosa', name='Tierra Fungosa', kind='cube', st=('dirt', C['tierra']), hard=0.5, tool='shovel', snd='GRAVEL', drop='self', dirt=True),
 dict(id='piedra_fungosa', name='Piedra Fungosa', kind='cube', st=('stone', C['piedra']), hard=1.5, tool='pickaxe', snd='STONE', drop='self', stone=True),
 dict(id='piedra_podrida', name='Piedra Podrida', kind='cube', st=('rot', C['podrida']), hard=2.0, tool='pickaxe', snd='STONE', drop='self', stone=True),
 dict(id='arena_esporifera', name='Arena Esporífera', kind='cube', st=('sand', C['arena']), hard=0.5, tool='shovel', snd='SAND', drop='self'),
 dict(id='bloque_raices', name='Bloque de Raíces', kind='cube', st=('roots', C['raiz']), hard=1.2, tool='axe', snd='WOOD', drop='self'),
 dict(id='madera_micotica', name='Madera Micótica', kind='cube', st=('planks', C['madera']), hard=2.0, tool='axe', snd='WOOD', drop='self'),
 dict(id='madera_micotica_losa', name='Losa de Madera Micótica', kind='slab', base='madera_micotica', hard=2.0, tool='axe', snd='WOOD', drop='self'),
 dict(id='madera_micotica_escalera', name='Escalera de Madera Micótica', kind='stairs', base='madera_micotica', hard=2.0, tool='axe', snd='WOOD', drop='self'),
 dict(id='tronco_gigante', name='Tronco Gigante', kind='pillar', st=('log', C['corteza']), hard=2.5, tool='axe', snd='WOOD', drop='self'),
 dict(id='tallo_hongo', name='Tallo de Hongo', kind='pillar', st=('stem', C['hongo']), hard=0.8, tool='axe', snd='WOOD', drop='self'),
 dict(id='tallo_luminoso', name='Tallo Luminoso', kind='pillar', st=('stemwin', C['hongo']), hard=0.8, tool='axe', snd='WOOD', light=12, drop='self'),
 dict(id='hojas_fungales', name='Hojas Fungales', kind='cube', st=('leaves', '#a23cc2'), hard=0.3, tool='hoe', snd='GRASS', drop='esencia'),
 dict(id='hojas_luminosas', name='Hojas Luminosas', kind='cube', st=('leaves', C['cian']), hard=0.3, tool='hoe', snd='GRASS', light=10, drop='esencia'),
 dict(id='sombrero_carmesi', name='Sombrero de Hongo Carmesí', kind='cap', st=('cap', '#c8202e'), hard=0.4, tool='axe', snd='WOOD', drop='esencia'),
 dict(id='sombrero_violeta', name='Sombrero de Hongo Violeta', kind='cap', st=('cap', '#7c3fbf'), hard=0.4, tool='axe', snd='WOOD', drop='esencia'),
 dict(id='sombrero_luminoso', name='Sombrero de Hongo Luminoso', kind='cap', st=('capglow', C['cian']), hard=0.4, tool='axe', snd='WOOD', light=12, drop='esencia'),
 dict(id='sombrero_rosa', name='Sombrero de Hongo Rosa', kind='cap', st=('cap', C['rosa']), hard=0.4, tool='axe', snd='WOOD', drop='esencia'),
 dict(id='bloque_esporas', name='Bloque de Esporas', kind='cube', st=('spores', C['esporas']), hard=0.5, tool='hoe', snd='MOSS', light=5, drop='self'),
 dict(id='bloque_esporas_venenoso', name='Bloque de Esporas Venenosas', kind='cube', st=('spores', C['veneno']), hard=0.5, tool='hoe', snd='MOSS', light=4, drop='self'),
 dict(id='bloque_cristal_micotico', name='Bloque de Cristal Micótico', kind='cube', st=('crystal', C['cristal']), hard=1.5, tool='pickaxe', snd='AMETHYST', light=10, drop='self', stone=True),
 dict(id='ladrillos_micelio', name='Ladrillos de Micelio', kind='cube', st=('bricks', C['ladrillo']), hard=2.0, tool='pickaxe', snd='STONE', drop='self', stone=True),
 dict(id='ladrillos_micelio_losa', name='Losa de Ladrillos de Micelio', kind='slab', base='ladrillos_micelio', hard=2.0, tool='pickaxe', snd='STONE', drop='self', stone=True),
 dict(id='ladrillos_micelio_escalera', name='Escalera de Ladrillos de Micelio', kind='stairs', base='ladrillos_micelio', hard=2.0, tool='pickaxe', snd='STONE', drop='self', stone=True),
 dict(id='ladrillos_podridos', name='Ladrillos Podridos', kind='cube', st=('bricks', '#4a5a3a'), hard=2.0, tool='pickaxe', snd='STONE', drop='self', stone=True),
 dict(id='lampara_micelio', name='Lámpara de Micelio', kind='cube', st=('lamp', '#ffd98a'), hard=0.8, tool='pickaxe', snd='GLASS', light=15, drop='self'),
 dict(id='mena_carmesi', name='Mineral Carmesí (mena)', kind='cube', st=('ore', C['carmesi']), hard=3.0, tool='pickaxe', snd='STONE', drop='mineral_carmesi', need='stone', stone=True),
 dict(id='mena_violeta', name='Mineral Violeta (mena)', kind='cube', st=('ore', C['violeta']), hard=3.0, tool='pickaxe', snd='STONE', drop='mineral_violeta', need='stone', stone=True),
 dict(id='mena_cristal', name='Mena de Cristal Micótico', kind='cube', st=('ore', C['cristal']), hard=3.2, tool='pickaxe', snd='AMETHYST', light=6, drop='cristal_micotico', need='iron', stone=True),
 dict(id='mena_piedra_viviente', name='Piedra Viviente (mena)', kind='cube', st=('ore', C['cian']), hard=3.0, tool='pickaxe', snd='STONE', light=4, drop='piedra_viviente', need='stone', stone=True),
 dict(id='mena_corazon', name='Mena de Corazón Esporífero', kind='cube', st=('ore', '#ff4a8a'), hard=4.0, tool='pickaxe', snd='STONE', light=7, drop='corazon_esporifero', need='diamond', stone=True),
 # plantas / hongos pequenos (modelo propio)
 dict(id='hongo_luminoso', name='Hongo Luminoso', kind='plant', st=('mush_small', C['cian']), hard=0.0, tool=None, snd='GRASS', light=9, drop='self'),
 dict(id='hongo_venenoso', name='Hongo Venenoso', kind='plant', st=('mush_tall', '#5ac83a'), hard=0.0, tool=None, snd='GRASS', light=3, drop='self'),
 dict(id='hongo_carmesi', name='Hongo Carmesí', kind='plant', st=('mush_small', '#c8202e'), hard=0.0, tool=None, snd='GRASS', drop='self'),
 dict(id='hongo_violeta', name='Hongo Violeta', kind='plant', st=('mush_tall', '#7c3fbf'), hard=0.0, tool=None, snd='GRASS', drop='self'),
 dict(id='planta_luminosa', name='Planta Luminosa', kind='plant', st=('flower', '#ff7ad0'), hard=0.0, tool=None, snd='GRASS', light=8, drop='self'),
 dict(id='hierba_micotica', name='Hierba Micótica', kind='plant', st=('tuft', '#8a4ac8'), hard=0.0, tool=None, snd='GRASS', drop='shears'),
 dict(id='cristales_micoticos', name='Cristales Micóticos', kind='plant', st=('crystalc', C['cristal']), hard=1.0, tool='pickaxe', snd='AMETHYST', light=8, drop='cristal_micotico'),
 # especiales
 dict(id='altar_portal', name='Altar del Portal Micótico', kind='altar', st=('altar', '#7a5a8a'), hard=3.0, tool='pickaxe', snd='STONE', light=10, drop='self'),
 dict(id='huevo_micotico', name='Huevo Micótico', kind='egg', st=('egg', '#e8dcc8'), hard=0.5, tool=None, snd='MOSS', drop='none', noitem=True),
]
BY = {b['id']: b for b in BLOCKS}

# ======================================================================= ITEMS
RES = [
 ('cristal_micotico', 'Cristal Micótico', 'gem', '#b57cf0'),
 ('esencia_esporas', 'Esencia de Esporas', 'orb', '#e8a0ff'),
 ('mineral_carmesi', 'Mineral Carmesí', 'ore', '#d9304a'),
 ('mineral_violeta', 'Mineral Violeta', 'ore', '#8a4fd0'),
 ('nucleo_micelio', 'Núcleo de Micelio', 'core', '#7affc8'),
 ('fragmento_fungoso', 'Fragmento Fungoso', 'shard', '#c8a07a'),
 ('piedra_viviente', 'Piedra Viviente', 'stone', '#2fd5ff'),
 ('corazon_esporifero', 'Corazón Esporífero', 'heart', '#ff4a8a'),
 ('carne_fungosa', 'Carne Fungosa', 'meat', '#c86a7a'),
 ('carne_fungosa_cocida', 'Carne Fungosa Cocida', 'cooked', '#8a4a3a'),
]
SETS = [  # id, nombre, color, color2, durab, defensas(h,c,l,b), enchant, dureza, retroceso, material de receta
 ('carmesi', 'Carmesí', '#c8202e', '#f4eadb', 22, (3, 8, 6, 3), 12, 1.0, 0.0, 'mineral_carmesi'),
 ('violeta', 'Violeta', '#7c3fbf', '#d9b8ff', 25, (3, 8, 6, 3), 18, 1.0, 0.0, 'mineral_violeta'),
 ('micelio', 'de Micelio', '#d8c8a8', '#7a5a8a', 30, (4, 9, 7, 4), 14, 2.0, 0.0, 'fragmento_fungoso'),
 ('guardian_fungoso', 'del Guardián Fungoso', '#5a6a4a', '#41f2ff', 36, (4, 9, 7, 4), 16, 2.0, 0.05, 'piedra_viviente'),
 ('rey_micotico', 'del Rey Micótico', '#4a1a3a', '#ff4aff', 44, (5, 10, 8, 5), 22, 3.5, 0.1, None),
]
PIECES = [('casco', 'Casco', 'HELMET', 'helmet', ['XXX', 'X X']), ('peto', 'Peto', 'CHESTPLATE', 'chest', ['X X', 'XXX', 'XXX']),
          ('pantalones', 'Pantalones', 'LEGGINGS', 'legs', ['XXX', 'X X', 'X X']), ('botas', 'Botas', 'BOOTS', 'boots', ['X X', 'X X'])]
TOOLS = [
 ('espada_esporas', 'Espada de Esporas', 'sword', '#b57cf0'), ('hacha_micotica', 'Hacha Micótica', 'axe', '#c23a4a'),
 ('pico_cristal_fungoso', 'Pico de Cristal Fungoso', 'pickaxe', '#2fd5ff'), ('arco_micelio', 'Arco de Micelio', 'bow', '#d8c8a8'),
 ('baston_esporas', 'Bastón de Esporas', 'staff', '#e8a0ff'), ('daga_venenosa', 'Daga Venenosa', 'dagger', '#7aff4a'),
]

# ======================================================================= TEXTURAS 16x16
def noise_tex(base, var=0.08, seed=1):
    rng = random.Random(seed); img = Image.new('RGBA', (16, 16)); c = hexrgb(base)
    for x in range(16):
        for y in range(16):
            img.putpixel((x, y), shade(c, 1 + rng.uniform(-var, var)) + (255,))
    return img

def block_tex(style, color, seed, part='all'):
    rng = random.Random(seed); c = hexrgb(color); img = noise_tex(color, 0.07, seed)
    px = img.putpixel
    if style == 'myc':
        if part == 'top':
            for _ in range(40): px((rng.randrange(16), rng.randrange(16)), shade(c, rng.choice([0.75, 1.25])) + (255,))
            for _ in range(8): px((rng.randrange(16), rng.randrange(16)), (245, 235, 245, 255))
        elif part == 'side':
            img = noise_tex('#5a3f4a', 0.08, seed + 1)
            for x in range(16):
                h = 3 + rng.randrange(3)
                for y in range(h): img.putpixel((x, y), shade(c, 1 + rng.uniform(-0.1, 0.1)) + (255,))
        else: img = noise_tex('#5a3f4a', 0.08, seed + 2)
    elif style == 'dirt':
        for _ in range(30): px((rng.randrange(16), rng.randrange(16)), shade(c, 0.7) + (255,))
    elif style == 'stone':
        for _ in range(26): px((rng.randrange(16), rng.randrange(16)), shade(c, rng.choice([0.8, 1.2])) + (255,))
        for x in range(2, 14): px((x, 7 + (x // 4) % 2), shade(c, 0.65) + (255,))
    elif style == 'rot':
        for _ in range(30): px((rng.randrange(16), rng.randrange(16)), rng.choice([(90, 110, 50, 255), (30, 40, 20, 255), shade(c, 1.2) + (255,)]))
        for _ in range(8): px((rng.randrange(16), rng.randrange(16)), (15, 15, 10, 255))
    elif style == 'sand':
        for _ in range(40): px((rng.randrange(16), rng.randrange(16)), rng.choice([(255, 255, 255, 255), shade(c, 0.8) + (255,), (210, 140, 255, 255)]))
    elif style == 'roots':
        for y in range(16):
            for x in range(16):
                if (x + (y // 3) * 5) % 6 < 2: px((x, y), shade(c, 0.65) + (255,))
    elif style == 'planks':
        for y in range(16):
            for x in range(16):
                if y % 4 == 3: px((x, y), shade(c, 0.6) + (255,))
                elif (x + (y // 4) * 7) % 16 == 0: px((x, y), shade(c, 0.75) + (255,))
    elif style == 'log':
        if part == 'end':
            for y in range(16):
                for x in range(16):
                    d = max(abs(x - 7.5), abs(y - 7.5))
                    img.putpixel((x, y), shade(hexrgb('#b58aa0'), 0.75 + 0.2 * (int(d) % 2)) + (255,))
            for x in range(16):
                for y in (0, 15): img.putpixel((x, y), shade(c, 1) + (255,)); img.putpixel((y, x), shade(c, 1) + (255,))
        else:
            for x in range(16):
                f = 0.7 if x % 4 == 0 else 1.0
                for y in range(16): img.putpixel((x, y), shade(c, f * (1 + rng.uniform(-0.06, 0.06))) + (255,))
    elif style in ('stem', 'stemwin'):
        if part == 'end':
            for y in range(16):
                for x in range(16):
                    d = math.hypot(x - 7.5, y - 7.5); img.putpixel((x, y), shade(c, 0.8 + 0.15 * (int(d) % 2)) + (255,))
        else:
            for x in range(16):
                f = 0.85 if x % 3 == 0 else 1.0
                for y in range(16): img.putpixel((x, y), shade(c, f * (1 + rng.uniform(-0.05, 0.05))) + (255,))
            if style == 'stemwin':
                for (wx, wy) in ((3, 3), (10, 3), (3, 9), (10, 9)):
                    for dx in range(3):
                        for dy in range(4):
                            img.putpixel((wx + dx, wy + dy), (255, 214, 120, 255) if dy < 3 else (200, 150, 70, 255))
    elif style == 'leaves':
        for _ in range(60): px((rng.randrange(16), rng.randrange(16)), shade(c, rng.choice([0.6, 0.8, 1.25, 1.4])) + (255,))
    elif style in ('cap', 'capglow'):
        for _ in range(7):
            sx, sy = rng.randrange(1, 14), rng.randrange(1, 14)
            for dx in range(2):
                for dy in range(2): px((sx + dx, sy + dy), (248, 238, 224, 255))
        if style == 'capglow':
            for _ in range(24): px((rng.randrange(16), rng.randrange(16)), (190, 255, 255, 255))
    elif style == 'spores':
        for _ in range(70): px((rng.randrange(16), rng.randrange(16)), rng.choice([shade(c, 1.3), shade(c, 0.6), (255, 255, 255, 255)]))
    elif style == 'crystal':
        for y in range(16):
            for x in range(16):
                f = 0.7 + 0.6 * (((x + y) % 8) / 8.0); px((x, y), shade(c, f) + (255,))
        for _ in range(10): px((rng.randrange(16), rng.randrange(16)), (255, 255, 255, 255))
    elif style == 'bricks':
        for y in range(16):
            for x in range(16):
                if y % 4 == 3 or (x + (4 if (y // 4) % 2 else 0)) % 8 == 7: px((x, y), shade(c, 0.55) + (255,))
    elif style == 'lamp':
        for y in range(16):
            for x in range(16):
                edge = x in (0, 15) or y in (0, 15)
                px((x, y), (90, 70, 50, 255) if edge else shade(hexrgb('#ffe9a8'), 0.85 + 0.25 * (1 - math.hypot(x - 7.5, y - 7.5) / 11)) + (255,))
    elif style == 'ore':
        img = block_tex('stone', C['piedra'], seed + 9); px = img.putpixel
        for _ in range(9):
            sx, sy = rng.randrange(1, 14), rng.randrange(1, 14)
            for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1)):
                px((sx + dx, sy + dy), shade(c, 1.0 + 0.2 * rng.random()) + (255,))
            px((sx, sy), (255, 255, 255, 255))
    return img

def plant_tex(style, color, seed):
    """16x16: mitad superior = sombrero/petalos, inferior = tallo (opaco, sin transparencia)."""
    rng = random.Random(seed); c = hexrgb(color); img = Image.new('RGBA', (16, 16), (0, 0, 0, 255))
    for y in range(16):
        for x in range(16):
            if style in ('mush_small', 'mush_tall'):
                col = shade(c, 1 + rng.uniform(-0.1, 0.1)) if y < 8 else shade(hexrgb('#e8dcc8'), 0.9 + rng.uniform(-0.08, 0.08))
            elif style == 'flower':
                col = shade(c, 1 + rng.uniform(-0.1, 0.1)) if y < 8 else shade(hexrgb('#3a8a3a'), 1 + rng.uniform(-0.1, 0.1))
            elif style == 'tuft':
                col = shade(c, 0.8 + 0.4 * (x % 3) / 3 + rng.uniform(-0.05, 0.05))
            else:
                col = shade(c, 0.7 + 0.6 * (((x + y) % 8) / 8) + rng.uniform(-0.05, 0.05))
            img.putpixel((x, y), col + (255,))
    if style in ('mush_small', 'mush_tall'):
        for _ in range(4): img.putpixel((rng.randrange(16), rng.randrange(8)), (248, 238, 224, 255))
    if style in ('crystalc',):
        for _ in range(8): img.putpixel((rng.randrange(16), rng.randrange(16)), (255, 255, 255, 255))
    return img

# ======================================================================= ICONOS 16x16
def _outline(mask_img, base, hi, lo, edge):
    w, h = mask_img.size; out = Image.new('RGBA', (w, h), (0, 0, 0, 0)); mp = mask_img.load(); op = out.load()
    for y in range(h):
        for x in range(w):
            if mp[x, y] > 0:
                nb = [(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))]
                border = any(not (0 <= a < w and 0 <= b < h) or mp[a, b] == 0 for a, b in nb)
                if border: op[x, y] = edge + (255,)
                elif x + y < 14 and (mp[x - 1, y - 1] == 0 if x > 0 and y > 0 else True): op[x, y] = hi + (255,)
                elif x + y > 18: op[x, y] = lo + (255,)
                else: op[x, y] = base + (255,)
    return out

def icon(kind, color, accent='#ffffff', seed=0):
    m = Image.new('L', (16, 16), 0); d = ImageDraw.Draw(m)
    if kind == 'gem': d.polygon([(8, 1), (13, 5), (13, 10), (8, 15), (3, 10), (3, 5)], fill=255)
    elif kind == 'orb': d.ellipse([3, 3, 12, 12], fill=255); d.rectangle([6, 1, 9, 3], fill=255)
    elif kind == 'ore':
        for (x, y, r) in ((5, 9, 3), (10, 7, 3), (8, 11, 3), (6, 5, 2)): d.ellipse([x - r, y - r, x + r, y + r], fill=255)
    elif kind == 'core': d.ellipse([2, 2, 13, 13], fill=255); d.rectangle([7, 0, 8, 15], fill=255); d.rectangle([0, 7, 15, 8], fill=255)
    elif kind == 'shard': d.polygon([(4, 14), (6, 4), (9, 1), (11, 6), (12, 14)], fill=255)
    elif kind == 'stone': d.rounded_rectangle([2, 3, 13, 13], 3, fill=255)
    elif kind == 'heart': d.polygon([(8, 14), (2, 8), (2, 5), (4, 3), (8, 6), (12, 3), (14, 5), (14, 8)], fill=255)
    elif kind in ('meat', 'cooked'): d.ellipse([2, 4, 12, 12], fill=255); d.rectangle([10, 2, 14, 6], fill=255)
    elif kind == 'helmet': d.rounded_rectangle([2, 3, 13, 9], 3, fill=255); d.rectangle([2, 8, 5, 13], fill=255); d.rectangle([10, 8, 13, 13], fill=255)
    elif kind == 'chest': d.polygon([(1, 3), (5, 2), (7, 4), (9, 4), (11, 2), (15, 3), (15, 8), (13, 8), (13, 14), (3, 14), (3, 8), (1, 8)], fill=255)
    elif kind == 'legs': d.rectangle([3, 2, 12, 6], fill=255); d.rectangle([3, 6, 7, 14], fill=255); d.rectangle([8, 6, 12, 14], fill=255)
    elif kind == 'boots': d.rectangle([3, 3, 6, 11], fill=255); d.rectangle([3, 9, 8, 13], fill=255); d.rectangle([9, 3, 12, 11], fill=255); d.rectangle([9, 9, 14, 13], fill=255)
    elif kind == 'sword':
        d.line([(13, 2), (4, 11)], fill=255, width=3); d.line([(3, 9), (7, 13)], fill=255, width=2); d.line([(3, 13), (1, 15)], fill=255, width=2)
    elif kind == 'dagger':
        d.line([(12, 3), (6, 9)], fill=255, width=2); d.line([(4, 8), (8, 12)], fill=255, width=2); d.line([(4, 12), (2, 14)], fill=255, width=2)
    elif kind == 'axe':
        d.line([(3, 14), (11, 4)], fill=255, width=2); d.polygon([(8, 2), (14, 3), (14, 9), (10, 7)], fill=255)
    elif kind == 'pickaxe':
        d.line([(3, 14), (11, 6)], fill=255, width=2); d.arc([1, 0, 15, 12], 200, 340, fill=255, width=3)
    elif kind == 'bow':
        d.arc([2, 1, 14, 15], 280, 80, fill=255, width=2); d.line([(12, 2), (12, 14)], fill=255, width=1)
    elif kind == 'staff':
        d.line([(4, 14), (11, 5)], fill=255, width=2); d.ellipse([9, 1, 14, 6], fill=255)
    base = hexrgb(color); out = _outline(m, base, shade(base, 1.35), shade(base, 0.7), shade(base, 0.3))
    rng = random.Random(seed); op = out.load(); ac = hexrgb(accent)
    for _ in range(4):
        x, y = rng.randrange(16), rng.randrange(16)
        if op[x, y][3] and op[x, y][:3] != shade(base, 0.3): op[x, y] = ac + (255,)
    if kind in ('sword', 'dagger', 'axe', 'pickaxe', 'staff', 'bow'):
        pass
    return out

def armor_layer_tex(color, color2, seed, legs=False):
    """Placas con juntas, brillo en el borde y remaches (aplica a todas las zonas del modelo de armadura)."""
    rng = random.Random(seed); img = Image.new('RGBA', (64, 32), (0, 0, 0, 0)); c = hexrgb(color); c2 = hexrgb(color2)
    for x in range(64):
        for y in range(32):
            lx, ly = x % 8, y % 8; f = 1 + rng.uniform(-0.05, 0.05)
            col = shade(c, f)
            if lx == 7 or ly == 7: col = shade(c, 0.55)
            elif lx == 0 or ly == 0: col = shade(c, 1.28)
            if (lx, ly) in ((3, 3), (4, 3), (3, 4), (4, 4)): col = shade(c2, 1.0 if (lx, ly) == (3, 3) else 0.8)
            if ((x // 8) + (y // 8)) % 4 == 0 and 1 <= lx <= 6 and ly in (1, 6): col = shade(c2, 0.85)
            img.putpixel((x, y), col + (255,))
    for _ in range(18): img.putpixel((rng.randrange(64), rng.randrange(32)), (250, 242, 230, 255))
    return img
