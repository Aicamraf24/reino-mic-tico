import json
from util import *
from content import *
import species as SP
import tex as TX
import icons as IC
DECO = {'carmesi': dict(cap='#c8202e', glow='#ffd98a'), 'violeta': dict(cap='#7c3fbf', glow='#e8b0ff'), 'micelio': dict(cap=None, glow='#b57cf0'), 'guardian_fungoso': dict(cap=None, glow='#41f2ff'), 'rey_micotico': dict(cap='#c8202e', glow='#ff4aff')}

NS = MOD
def bid(i): return f'{NS}:{i}'

def lang_key_block(i): return f'block.{NS}.{i}'
LANG = {}

def gen_blocks():
    for n, b in enumerate(BLOCKS):
        i, k = b['id'], b['kind']; LANG[lang_key_block(i)] = b['name']
        st = b.get('st')
        def tex(name, img): save_png(img, f'src/main/resources/assets/{NS}/textures/block/{name}.png')
        item_model = f'{NS}:block/{i}'
        if k == 'cube':
            tex(i, block_tex(st[0], st[1], n))
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}.json', {'parent': 'minecraft:block/cube_all', 'textures': {'all': f'{NS}:block/{i}'}})
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {'': {'model': f'{NS}:block/{i}'}}})
        elif k == 'bt':
            for part in ('top', 'side', 'bottom'): tex(f'{i}_{part}', block_tex(st[0], st[1], n, part))
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}.json', {'parent': 'minecraft:block/cube_bottom_top', 'textures': {
                'top': f'{NS}:block/{i}_top', 'side': f'{NS}:block/{i}_side', 'bottom': f'{NS}:block/{i}_bottom'}})
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {'': {'model': f'{NS}:block/{i}'}}})
        elif k == 'pillar':
            tex(f'{i}_side', block_tex(st[0], st[1], n, 'side')); tex(f'{i}_end', block_tex(st[0], st[1], n, 'end'))
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}.json', {'parent': 'minecraft:block/cube_column', 'textures': {'end': f'{NS}:block/{i}_end', 'side': f'{NS}:block/{i}_side'}})
            m = f'{NS}:block/{i}'
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {'axis=y': {'model': m}, 'axis=z': {'model': m, 'x': 90}, 'axis=x': {'model': m, 'x': 90, 'y': 90}}})
        elif k == 'cap':
            tex(i, block_tex(st[0], st[1], n))
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}.json', {'parent': 'minecraft:block/template_single_face', 'textures': {'texture': f'{NS}:block/{i}'}})
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}_inventory.json', {'parent': 'minecraft:block/cube_all', 'textures': {'all': f'{NS}:block/{i}'}})
            m = f'{NS}:block/{i}'; ins = 'minecraft:block/mushroom_block_inside'
            mp = []
            for face, rot in (('north', {}), ('east', {'y': 90}), ('south', {'y': 180}), ('west', {'y': 270}), ('up', {'x': 270}), ('down', {'x': 90})):
                ap = dict(model=m, **rot); ap_in = dict(model=ins, **rot)
                if rot: ap['uvlock'] = True; ap_in['uvlock'] = True
                mp.append({'when': {face: 'true'}, 'apply': ap})
                mp.append({'when': {face: 'false'}, 'apply': ap_in})
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'multipart': mp})
            item_model = f'{NS}:block/{i}_inventory'
        elif k in ('slab', 'stairs'):
            base = BY[b['base']]; bn = BLOCKS.index(base)
            t = f'{NS}:block/{base["id"]}'; tx = {'bottom': t, 'top': t, 'side': t}
            if k == 'slab':
                for suf, par in (('', 'minecraft:block/slab'), ('_top', 'minecraft:block/slab_top')):
                    wjson(f'src/main/resources/assets/{NS}/models/block/{i}{suf}.json', {'parent': par, 'textures': tx})
                wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {
                    'type=bottom': {'model': f'{NS}:block/{i}'}, 'type=top': {'model': f'{NS}:block/{i}_top'},
                    'type=double': {'model': f'{NS}:block/{base["id"]}'}}})
            else:
                for suf, par in (('', 'minecraft:block/stairs'), ('_inner', 'minecraft:block/inner_stairs'), ('_outer', 'minecraft:block/outer_stairs')):
                    wjson(f'src/main/resources/assets/{NS}/models/block/{i}{suf}.json', {'parent': par, 'textures': tx})
                var = {}
                for fi, (face, by) in enumerate((('east', 0), ('south', 90), ('west', 180), ('north', 270))):
                    for half in ('bottom', 'top'):
                        for shape in ('straight', 'inner_left', 'inner_right', 'outer_left', 'outer_right'):
                            left = shape.endswith('left')
                            if half == 'bottom': y = (by - 90) % 360 if left else by
                            else: y = by if left else (by + 90) % 360
                            if shape == 'straight': y = by
                            suf = '' if shape == 'straight' else ('_inner' if shape.startswith('inner') else '_outer')
                            e = {'model': f'{NS}:block/{i}{suf}', 'uvlock': True}
                            if half == 'top': e['x'] = 180
                            if y: e['y'] = y
                            var[f'facing={face},half={half},shape={shape}'] = e
                wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': var})
        elif k == 'plant':
            tex(i, plant_tex(st[0], st[1], n))
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}.json', plant_model(st[0], f'{NS}:block/{i}'))
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {'': {'model': f'{NS}:block/{i}'}}})
        elif k == 'altar':
            tex('altar_portal', block_tex('bricks', '#7a5a8a', n)); tex('altar_crystal', block_tex('crystal', '#41f2ff', n + 1))
            def el(f, t, tx_): return {'from': f, 'to': t, 'faces': {d: {'uv': [0, 0, 16, 16], 'texture': tx_} for d in ('north', 'south', 'east', 'west', 'up', 'down')}}
            wjson(f'src/main/resources/assets/{NS}/models/block/{i}.json', {'textures': {'b': f'{NS}:block/altar_portal', 'c': f'{NS}:block/altar_crystal', 'particle': f'{NS}:block/altar_portal'},
                'elements': [el([0, 0, 0], [16, 4, 16], '#b'), el([4, 4, 4], [12, 11, 12], '#b'), el([2, 11, 2], [14, 14, 14], '#b'), el([5, 14, 5], [11, 16, 11], '#c')]})
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {'': {'model': f'{NS}:block/{i}'}}})
        elif k == 'egg':
            LANG[lang_key_block(i)] = 'Huevo Micótico'
            wjson(f'src/main/resources/assets/{NS}/blockstates/{i}.json', {'variants': {
                f'species={si},hatch={h}': {'model': f'{NS}:block/egg_{s["id"]}'} for si, s in enumerate(ALL) for h in range(3)}})
            continue
        if not b.get('noitem'):
            wjson(f'src/main/resources/assets/{NS}/items/{i}.json', {'model': {'type': 'minecraft:model', 'model': item_model}})

def plant_model(style, texref):
    def box(f, t, uvy, rot=None):
        d = {'from': f, 'to': t, 'faces': {x: {'uv': [0, uvy, 16, uvy + 8], 'texture': '#t'} for x in ('north', 'south', 'east', 'west', 'up', 'down')}}
        if rot: d['rotation'] = rot
        return d
    els = []
    if style == 'mush_small':
        els = [box([6, 0, 6], [10, 5, 10], 8), box([4, 5, 4], [12, 8, 12], 0), box([5, 8, 5], [11, 9, 11], 0)]
    elif style == 'mush_tall':
        els = [box([7, 0, 7], [9, 9, 9], 8), box([3, 9, 3], [13, 12, 13], 0), box([5, 12, 5], [11, 13, 11], 0)]
    elif style == 'flower':
        els = [box([7.5, 0, 7.5], [8.5, 7, 8.5], 8), box([5, 7, 7], [11, 11, 9], 0), box([7, 7, 5], [9, 11, 11], 0)]
    elif style == 'tuft':
        els = [box([3, 0, 3], [4, 7, 4], 0), box([9, 0, 4], [10, 9, 5], 0), box([6, 0, 10], [7, 6, 11], 0), box([11, 0, 11], [12, 8, 12], 0), box([5, 0, 6], [6, 10, 7], 0)]
    elif style == 'crystalc':
        els = [box([6, 0, 6], [10, 9, 10], 0), box([2, 0, 7], [5, 6, 10], 0, {'angle': 22.5, 'axis': 'z', 'origin': [3, 0, 8]}),
               box([11, 0, 6], [14, 7, 9], 0, {'angle': -22.5, 'axis': 'z', 'origin': [13, 0, 8]}), box([7, 0, 11], [10, 5, 14], 0, {'angle': 22.5, 'axis': 'x', 'origin': [8, 0, 13]})]
    return {'textures': {'t': texref, 'particle': texref}, 'elements': els}

def gen_items(ALL):
    def im(i, icon_path=None, parent='minecraft:item/generated'):
        wjson(f'src/main/resources/assets/{NS}/models/item/{i}.json', {'parent': parent, 'textures': {'layer0': f'{NS}:item/{i}'}})
        wjson(f'src/main/resources/assets/{NS}/items/{i}.json', {'model': {'type': 'minecraft:model', 'model': f'{NS}:item/{i}'}})
    for n, (i, nm, kind, col) in enumerate(RES):
        LANG[f'item.{NS}.{i}'] = nm; save_png(IC.icon(kind, col, '#f4eadb', n), f'src/main/resources/assets/{NS}/textures/item/{i}.png'); im(i)
    for n, (sid, snm, col, col2, *_r) in enumerate(SETS):
        for (pid, pnm, _a, kind, _p) in PIECES:
            i = f'{pid}_{sid}'; LANG[f'item.{NS}.{i}'] = f'{pnm} {snm}'
            save_png(IC.icon(kind, col, col2, n, deco=DECO[sid]), f'src/main/resources/assets/{NS}/textures/item/{i}.png'); im(i)
        wjson(f'src/main/resources/assets/{NS}/equipment/{sid}.json', {'layers': {'humanoid': [{'texture': f'{NS}:{sid}'}], 'humanoid_leggings': [{'texture': f'{NS}:{sid}'}]}})
        save_png(armor_layer_tex(col, col2, n), f'src/main/resources/assets/{NS}/textures/entity/equipment/humanoid/{sid}.png')
        save_png(armor_layer_tex(col, col2, n + 50, True), f'src/main/resources/assets/{NS}/textures/entity/equipment/humanoid_leggings/{sid}.png')
    for n, (i, nm, kind, col) in enumerate(TOOLS):
        LANG[f'item.{NS}.{i}'] = nm; save_png(IC.icon(kind, col, '#f4eadb', n + 30), f'src/main/resources/assets/{NS}/textures/item/{i}.png')
        if kind == 'bow':
            for k2, nm2 in ((0, 'pulling_0'), (1, 'pulling_1'), (2, 'pulling_2')):
                wjson(f'src/main/resources/assets/{NS}/models/item/{i}_{nm2}.json', {'parent': 'minecraft:item/bow', 'textures': {'layer0': f'{NS}:item/{i}'}})
            wjson(f'src/main/resources/assets/{NS}/models/item/{i}.json', {'parent': 'minecraft:item/bow', 'textures': {'layer0': f'{NS}:item/{i}'}})
            m = lambda s: {'type': 'minecraft:model', 'model': f'{NS}:item/{i}{s}'}
            wjson(f'src/main/resources/assets/{NS}/items/{i}.json', {'model': {'type': 'minecraft:condition', 'property': 'minecraft:using_item', 'on_false': m(''),
                  'on_true': {'type': 'minecraft:range_dispatch', 'property': 'minecraft:use_duration', 'scale': 0.05, 'entries': [
                      {'threshold': 0.65, 'model': m('_pulling_1')}, {'threshold': 0.9, 'model': m('_pulling_2')}], 'fallback': m('_pulling_0')}}})
        else:
            im(i, parent='minecraft:item/handheld')
    # huevos generadores: textura propia por criatura (colores de la criatura, sin depender de la plantilla vanilla)
    for k, s in enumerate(ALL):
        i = f'generador_{s["id"]}'; LANG[f'item.{NS}.{i}'] = f'Generar {s["name"]}'
        main = hexrgb(s['pal']['main']); acc = hexrgb(s['pal']['accent'])
        dist = sum(abs(main[j] - acc[j]) for j in range(3))
        spot = s['pal']['accent'] if dist > 150 else s['pal']['glow']
        save_png(IC.egg_icon(main, hexrgb(spot), k * 5 + 1, s['pal']['glow']), f'src/main/resources/assets/{NS}/textures/item/{i}.png')
        im(i)

def TX_RGB(h):
    r, g, b = hexrgb(h); v = (255 << 24) | (r << 16) | (g << 8) | b
    return v - (1 << 32) if v >= (1 << 31) else v

ALL = None
