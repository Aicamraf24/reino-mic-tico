package com.reinomicotico.entity;

import com.reinomicotico.ModEntities;
import com.reinomicotico.Species;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * El Rey Micotico. NO extiende Animal: no tiene modo amor, no puede reproducirse ni generar crias.
 * Tres fases segun la vida: raices+esporas / esbirros / aplastamiento furioso.
 */
public class MicoBoss extends Monster {
	private final ServerBossEvent bossEvent = new ServerBossEvent(
			Component.translatable("entity.reino_micotico.rey_micotico"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
	private int noPlayerTicks;

	public MicoBoss(EntityType<? extends MicoBoss> type, Level level) {
		super(type, level);
		this.xpReward = 500;
	}

	public static AttributeSupplier.Builder attributes(Species s) {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, s.hp)
				.add(Attributes.MOVEMENT_SPEED, s.speed)
				.add(Attributes.ATTACK_DAMAGE, s.damage)
				.add(Attributes.ARMOR, 10.0)
				.add(Attributes.FOLLOW_RANGE, 40.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
	}

	@Override
	protected PathNavigation createNavigation(Level level) {
		return new WallClimberNavigation(this, level);
	}

	@Override
	public boolean onClimbable() {
		return this.horizontalCollision;
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1, false));
		this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
		this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 24.0f));
		this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}

	public int phase() {
		float f = this.getHealth() / this.getMaxHealth();
		return f > 0.66f ? 1 : f > 0.33f ? 2 : 3;
	}

	@Override
	public void startSeenByPlayer(ServerPlayer p) {
		super.startSeenByPlayer(p);
		bossEvent.addPlayer(p);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer p) {
		super.stopSeenByPlayer(p);
		bossEvent.removePlayer(p);
	}

	@Override
	public boolean removeWhenFarAway(double d) {
		return false;
	}

	@Override
	public void aiStep() {
		super.aiStep();
		if (this.level().isClientSide()) return;
		ServerLevel sl = (ServerLevel) this.level();
		bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
		int ph = phase();
		bossEvent.setColor(ph == 1 ? BossEvent.BossBarColor.PURPLE : ph == 2 ? BossEvent.BossBarColor.PINK : BossEvent.BossBarColor.RED);
		List<Player> players = sl.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(32.0), p -> p.isAlive() && !p.isSpectator() && !p.isCreative());
		if (players.isEmpty()) {
			// regeneracion controlada: solo si nadie le combate durante 10 s
			if (++noPlayerTicks > 200 && this.tickCount % 20 == 0) this.heal(this.getMaxHealth() * 0.02f);
			return;
		}
		noPlayerTicks = 0;
		int t = this.tickCount;
		int rate = ph == 3 ? 70 : ph == 2 ? 90 : 110;
		// Fase 1+: raices que atrapan y hieren
		if (t % rate == 0) {
			for (Player p : players) {
				if (this.distanceToSqr(p) < 14 * 14) {
					p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 50, 3));
					p.hurtServer(sl, sl.damageSources().mobAttack(this), 5.0f + ph * 2);
					sl.sendParticles(ParticleTypes.COMPOSTER, p.getX(), p.getY() + 0.2, p.getZ(), 30, 0.6, 0.1, 0.6, 0.05);
				}
			}
		}
		// Esporas toxicas en area
		if (t % 160 == 40) {
			for (Player p : players) {
				if (this.distanceToSqr(p) < 18 * 18) {
					p.addEffect(new MobEffectInstance(MobEffects.POISON, 100, ph - 1));
					p.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 100, 0));
				}
			}
			sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, this.getX(), this.getY() + 2, this.getZ(), 120, 6, 2, 6, 0.02);
		}
		// Fase 2+: invoca criaturas (maximo 6 vivas)
		if (ph >= 2 && t % 300 == 150) {
			int n = sl.getEntitiesOfClass(MicoCreature.class, this.getBoundingBox().inflate(32.0), e -> e.sp() != null && e.sp().hostile()).size();
			String[] pool = {"devorador_micelio", "gusano_esporas", "arana_esporifera"};
			for (int i = 0; i < 2 && n + i < 6; i++) {
				EntityType<? extends Mob> et = ModEntities.TYPES.get(pool[this.random.nextInt(pool.length)]);
				Mob m = et.create(sl, EntitySpawnReason.MOB_SUMMONED);
				if (m != null) {
					m.setPos(this.getX() + (this.random.nextDouble() - 0.5) * 8, this.getY(), this.getZ() + (this.random.nextDouble() - 0.5) * 8);
					sl.addFreshEntity(m);
				}
			}
		}
		// Fase 3: aplastamiento en area
		if (ph == 3 && t % 120 == 60) {
			for (Player p : players) {
				double dx = p.getX() - this.getX(), dz = p.getZ() - this.getZ();
				double dist = Math.sqrt(dx * dx + dz * dz);
				if (dist < 9.0) {
					p.hurtServer(sl, sl.damageSources().mobAttack(this), 12.0f);
					p.push(dx / Math.max(dist, 0.1) * 1.2, 0.8, dz / Math.max(dist, 0.1) * 1.2);
					p.hurtMarked = true;
				}
			}
			sl.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 0.5, this.getZ(), 8, 3, 0.2, 3, 0.0);
		}
		// Fase 2: regeneracion leve y limitada mientras dure el combate
		if (ph == 2 && t % 40 == 0) this.heal(1.0f);
	}
}
