package com.reinomicotico.entity;

import com.reinomicotico.Breeding;
import com.reinomicotico.ModBlocks;
import com.reinomicotico.ModEntities;
import com.reinomicotico.Species;
import com.reinomicotico.SpeciesRegistry;
import com.reinomicotico.block.MicoEggBlock;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToDoGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Criatura generica del Reino Micotico. Todo su comportamiento sale de los datos de su {@link Species}:
 * un unico codigo, 37 especies (incluidos los hibridos). El jefe NO usa esta clase (ver MicoBoss).
 */
public class MicoCreature extends TamableAnimal {
	private static final EntityDataAccessor<Boolean> RESTING = SynchedEntityData.defineId(MicoCreature.class, EntityDataSerializers.BOOLEAN);
	private static final EntityDataAccessor<Boolean> EATING = SynchedEntityData.defineId(MicoCreature.class, EntityDataSerializers.BOOLEAN);

	private int eatTicks;
	private int abilityCooldown;
	private Species pendingChild;

	public MicoCreature(EntityType<? extends MicoCreature> type, Level level) {
		super(type, level);
		Species s = sp();
		if (s != null && s.fly) {
			this.moveControl = new FlyingMoveControl(this, 20, true);
		}
	}

	public Species sp() {
		return ModEntities.speciesOf(this.getType());
	}

	public static AttributeSupplier.Builder attributes(Species s) {
		AttributeSupplier.Builder b = Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, s.hp)
				.add(Attributes.MOVEMENT_SPEED, s.speed)
				.add(Attributes.ATTACK_DAMAGE, Math.max(s.damage, 1.0))
				.add(Attributes.FOLLOW_RANGE, s.hostile() ? 24.0 : 16.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, s.knockbackResist)
				.add(Attributes.TEMPT_RANGE, 10.0);
		if (s.fly) b.add(Attributes.FLYING_SPEED, Math.max(0.3, s.speed * 2.0));
		return b;
	}

	// ------------------------------------------------------------ datos sincronizados
	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(RESTING, false);
		builder.define(EATING, false);
	}

	public boolean isResting() { return this.entityData.get(RESTING); }
	public void setResting(boolean v) { this.entityData.set(RESTING, v); }
	public boolean isEating() { return this.entityData.get(EATING); }

	// ------------------------------------------------------------ navegacion / IA
	@Override
	protected PathNavigation createNavigation(Level level) {
		Species s = sp();
		if (s != null && s.fly) {
			FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
			nav.setCanOpenDoors(false);
			nav.setCanFloat(true);
			return nav;
		}
		if (s != null && s.climb) return new WallClimberNavigation(this, level);
		return super.createNavigation(level);
	}

	@Override
	public boolean onClimbable() {
		Species s = sp();
		if (s != null && s.climb) return this.horizontalCollision;
		return super.onClimbable();
	}

	@Override
	protected void registerGoals() {
		Species s = sp();
		if (s == null) return;
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new SitWhenOrderedToDoGoal(this));
		if (s.hostile() || s.neutral() || s.tame) {
			this.goalSelector.addGoal(2, new MeleeAttackGoal(this, s.hostile() ? 1.25 : 1.2, true));
		}
		if (s.flee && s.peaceful()) {
			this.goalSelector.addGoal(2, new PanicGoal(this, 1.5));
			this.goalSelector.addGoal(3, new AvoidEntityGoal<>(this, Player.class, 8.0f, 1.2, 1.5, e -> !this.isTame()));
		}
		if (s.breedable) {
			this.goalSelector.addGoal(3, new BreedGoal(this, 1.0, MicoCreature.class));
			List<net.minecraft.world.level.ItemLike> items = new ArrayList<>();
			for (String id : s.food) {
				net.minecraft.world.item.Item it = BuiltInRegistries.ITEM.getValue(net.minecraft.resources.Identifier.parse(id));
				if (it != null) items.add(it);
			}
			if (!items.isEmpty() && !s.hostile()) {
				this.goalSelector.addGoal(4, new TemptGoal(this, 1.1, Ingredient.of(items.toArray(new net.minecraft.world.level.ItemLike[0])), false));
			}
			this.goalSelector.addGoal(5, new FollowParentGoal(this, 1.1));
		}
		if (s.tame) this.goalSelector.addGoal(6, new FollowOwnerGoal(this, 1.0, 10.0f, 2.0f));
		if (!s.hostile() && !s.stationary) this.goalSelector.addGoal(7, new RestGoal(this));
		if (!s.stationary) {
			if (s.fly) this.goalSelector.addGoal(8, new WaterAvoidingRandomFlyingGoal(this, 1.0));
			else this.goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 1.0));
		}
		this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 8.0f));
		this.goalSelector.addGoal(10, new RandomLookAroundGoal(this));

		if (s.tame) {
			this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
			this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		}
		if (s.hostile() || s.neutral()) {
			this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
		}
		if (s.hostile()) {
			final MicoCreature self = this;
			this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Player.class, true) {
				@Override
				public boolean canUse() {
					return !self.isTame() && !self.isBaby() && super.canUse();
				}
			});
		}
	}

	// ------------------------------------------------------------ alimentacion / domesticacion
	private static String keyOf(ItemStack stack) {
		return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
	}

	@Override
	public boolean isFood(ItemStack stack) {
		Species s = sp();
		return s != null && s.breedable && s.food.contains(keyOf(stack));
	}

	private boolean isTameItem(ItemStack stack) {
		return keyOf(stack).equals("reino_micotico:esencia_esporas");
	}

	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		Species s = sp();
		if (s != null && s.tame && !this.isTame() && isTameItem(stack)) {
			if (!this.level().isClientSide()) {
				stack.consume(1, player);
				if (this.random.nextInt(3) == 0) {
					this.tame(player);
					this.navigation.stop();
					this.setTarget(null);
					this.setOrderedToSit(true);
					this.level().broadcastEntityEvent(this, (byte) 7);
				} else {
					this.level().broadcastEntityEvent(this, (byte) 6);
				}
			}
			return InteractionResult.SUCCESS;
		}
		if (this.isTame() && this.isOwnedBy(player) && !this.isFood(stack) && hand == InteractionHand.MAIN_HAND) {
			if (!this.level().isClientSide()) {
				this.setOrderedToSit(!this.isOrderedToSit());
				this.navigation.stop();
				this.setTarget(null);
			}
			return InteractionResult.SUCCESS;
		}
		InteractionResult r = super.mobInteract(player, hand);
		if (r.consumesAction() && this.isFood(stack) && !this.level().isClientSide()) {
			this.eatTicks = 40;
			this.entityData.set(EATING, true);
		}
		return r;
	}

	// ------------------------------------------------------------ reproduccion
	@Override
	public boolean canMate(Animal other) {
		if (other == this || !(other instanceof MicoCreature o)) return false;
		if (!this.isInLove() || !o.isInLove()) return false;
		Species a = sp(), b = o.sp();
		return a != null && b != null && Breeding.compatible(a, b);
	}

	private boolean populationOk(ServerLevel level) {
		Species s = sp();
		AABB box = this.getBoundingBox().inflate(48.0);
		int n = level.getEntitiesOfClass(MicoCreature.class, box, e -> e.getType() == this.getType()).size();
		return n < s.maxPop;
	}

	@Override
	public void spawnChildFromBreeding(ServerLevel level, Animal partner) {
		if (!(partner instanceof MicoCreature o) || !populationOk(level)) {
			this.setAge(6000);
			partner.setAge(6000);
			this.resetLove();
			partner.resetLove();
			return;
		}
		pendingChild = Breeding.offspring(sp(), o.sp(), this.random);
		o.pendingChild = pendingChild;
		if (pendingChild.egg && layEgg(level, pendingChild)) {
			this.setAge(6000);
			partner.setAge(6000);
			this.resetLove();
			partner.resetLove();
			level.broadcastEntityEvent(this, (byte) 18);
			pendingChild = null;
			o.pendingChild = null;
			return;
		}
		super.spawnChildFromBreeding(level, partner);
	}

	private boolean layEgg(ServerLevel level, Species child) {
		BlockPos base = this.blockPosition();
		for (BlockPos c : BlockPos.betweenClosed(base.offset(-1, -1, -1), base.offset(1, 1, 1))) {
			BlockPos p = c.immutable();
			if (level.getBlockState(p).isAir() && level.getBlockState(p.below()).isFaceSturdy(level, p.below(), Direction.UP)) {
				BlockState st = ModBlocks.HUEVO_MICOTICO.defaultBlockState().setValue(MicoEggBlock.SPECIES, SpeciesRegistry.indexOf(child.id));
				level.setBlockAndUpdate(p, st);
				return true;
			}
		}
		return false;
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
		Species child = pendingChild;
		if (child == null && otherParent instanceof MicoCreature o) child = Breeding.offspring(sp(), o.sp(), this.random);
		if (child == null) child = sp();
		EntityType<? extends Mob> t = ModEntities.TYPES.get(child.id);
		Mob m = t.create(level, EntitySpawnReason.BREEDING);
		if (m instanceof MicoCreature baby) {
			if (otherParent instanceof MicoCreature o) baby.inheritStats(this, o);
			return baby;
		}
		return null;
	}

	/** Estadisticas del hijo: media de los progenitores con una variacion de +-10 %. */
	public void inheritStats(MicoCreature a, MicoCreature b) {
		inherit(Attributes.MAX_HEALTH, a, b);
		inherit(Attributes.MOVEMENT_SPEED, a, b);
		inherit(Attributes.ATTACK_DAMAGE, a, b);
		this.setHealth(this.getMaxHealth());
	}

	private void inherit(net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attr, MicoCreature a, MicoCreature b) {
		if (this.getAttribute(attr) == null || a.getAttribute(attr) == null || b.getAttribute(attr) == null) return;
		double avg = (a.getAttributeBaseValue(attr) + b.getAttributeBaseValue(attr)) / 2.0;
		double v = avg * (0.9 + this.random.nextDouble() * 0.2);
		this.getAttribute(attr).setBaseValue(v);
	}

	// ------------------------------------------------------------ comportamiento por tick
	@Override
	public void aiStep() {
		super.aiStep();
		if (this.level().isClientSide()) return;
		if (eatTicks > 0 && --eatTicks == 0) this.entityData.set(EATING, false);
		Species s = sp();
		if (s == null) return;
		if (abilityCooldown > 0) abilityCooldown--;
		LivingEntity target = this.getTarget();
		if (target == null || !this.isAlive() || this.tickCount % 10 != 0) return;
		double d = this.distanceToSqr(target);
		ServerLevel sl = (ServerLevel) this.level();
		// emboscada: arranque de velocidad al detectar a la presa
		if (s.ambush && d < 100.0 && d > 9.0 && abilityCooldown == 0) {
			this.addEffect(new MobEffectInstance(MobEffects.SPEED, 50, 1));
			abilityCooldown = 200;
		}
		// habilidades por contacto
		if (d < (this.getBbWidth() + 1.5) * (this.getBbWidth() + 1.5) && abilityCooldown <= 100) {
			switch (s.ability) {
				case "poison" -> target.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
				case "bleed" -> target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
				case "spores" -> {
					target.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 120, 0));
					sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, target.getX(), target.getY() + 1, target.getZ(), 12, 0.6, 0.6, 0.6, 0.02);
				}
				case "grab" -> target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 3));
				case "slam" -> {
					target.push(0.0, 0.7, 0.0);
					target.hurtMarked = true;
				}
				default -> { }
			}
			if (!s.ability.isEmpty()) abilityCooldown = 160;
		}
		// la Reina invoca esbirros (limitado)
		if ("summon".equals(s.ability) && abilityCooldown == 0 && d < 400.0) {
			int n = sl.getEntitiesOfClass(MicoCreature.class, this.getBoundingBox().inflate(24.0), e -> e.sp() != null && e.sp().id.equals("gusano_esporas")).size();
			if (n < 4) {
				EntityType<? extends Mob> t = ModEntities.TYPES.get("gusano_esporas");
				for (int i = 0; i < 2; i++) {
					Mob m = t.create(sl, EntitySpawnReason.MOB_SUMMONED);
					if (m != null) {
						m.setPos(this.getX() + (this.random.nextDouble() - 0.5) * 4, this.getY(), this.getZ() + (this.random.nextDouble() - 0.5) * 4);
						sl.addFreshEntity(m);
					}
				}
			}
			abilityCooldown = 400;
		}
	}

	@Override
	public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason reason) {
		if (!super.checkSpawnRules(level, reason)) return false;
		Species s = sp();
		if (s == null || reason != EntitySpawnReason.NATURAL) return true;
		// control de acumulacion de entidades
		int n = level.getEntitiesOfClass(MicoCreature.class, this.getBoundingBox().inflate(40.0), e -> e.getType() == this.getType()).size();
		return n < s.maxPop;
	}

	@Override
	public boolean removeWhenFarAway(double distSq) {
		Species s = sp();
		return s != null && s.hostile() && !this.isTame();
	}

	@Override
	public boolean canFallInLove() {
		Species s = sp();
		return s != null && s.breedable && super.canFallInLove();
	}
}
