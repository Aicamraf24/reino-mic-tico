package com.reinomicotico.block;

import com.reinomicotico.ModItems;
import com.reinomicotico.Portal;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Altar del Portal Micotico: clic derecho con un Nucleo de Micelio para viajar (ida y vuelta). */
public class PortalAltarBlock extends Block {
	public PortalAltarBlock(Properties props) {
		super(props);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) return InteractionResult.SUCCESS;
		ItemStack held = player.getMainHandItem();
		if (!held.is(ModItems.NUCLEO_MICELIO)) {
			player.displayClientMessage(Component.translatable("message.reino_micotico.need_core"), true);
			return InteractionResult.SUCCESS;
		}
		if (!player.isCreative()) held.shrink(1);
		if (player instanceof ServerPlayer sp) Portal.travel(sp);
		return InteractionResult.SUCCESS;
	}
}
