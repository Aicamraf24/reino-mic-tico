package com.reinomicotico;

import com.reinomicotico.block.MicoEggBlock;
import com.reinomicotico.block.PortalAltarBlock;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Bloques del Reino Micotico (generado por gen/). */
public final class ModBlocks {
	private ModBlocks() {}

	private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties settings, boolean withItem) {
		ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, ReinoMicotico.id(name));
		Block block = factory.apply(settings.setId(key));
		if (withItem) {
			ResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, ReinoMicotico.id(name));
			BlockItem bi = new BlockItem(block, new Item.Properties().setId(ik).useBlockDescriptionPrefix());
			Registry.register(BuiltInRegistries.ITEM, ik, bi);
		}
		return Registry.register(BuiltInRegistries.BLOCK, key, block);
	}

	public static final Block MICELIO_CARMESI = register("micelio_carmesi", Block::new, BlockBehaviour.Properties.of().strength(0.6f).sound(SoundType.GRASS), true);
	public static final Block MICELIO_VIOLETA = register("micelio_violeta", Block::new, BlockBehaviour.Properties.of().strength(0.6f).sound(SoundType.GRASS), true);
	public static final Block TIERRA_FUNGOSA = register("tierra_fungosa", Block::new, BlockBehaviour.Properties.of().strength(0.5f).sound(SoundType.GRAVEL), true);
	public static final Block PIEDRA_FUNGOSA = register("piedra_fungosa", Block::new, BlockBehaviour.Properties.of().strength(1.5f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block PIEDRA_PODRIDA = register("piedra_podrida", Block::new, BlockBehaviour.Properties.of().strength(2.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block ARENA_ESPORIFERA = register("arena_esporifera", Block::new, BlockBehaviour.Properties.of().strength(0.5f).sound(SoundType.SAND), true);
	public static final Block BLOQUE_RAICES = register("bloque_raices", Block::new, BlockBehaviour.Properties.of().strength(1.2f).sound(SoundType.WOOD), true);
	public static final Block MADERA_MICOTICA = register("madera_micotica", Block::new, BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.WOOD), true);
	public static final Block MADERA_MICOTICA_LOSA = register("madera_micotica_losa", SlabBlock::new, BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.WOOD), true);
	public static final Block MADERA_MICOTICA_ESCALERA = register("madera_micotica_escalera", p -> new StairBlock(MADERA_MICOTICA.defaultBlockState(), p), BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.WOOD), true);
	public static final Block TRONCO_GIGANTE = register("tronco_gigante", RotatedPillarBlock::new, BlockBehaviour.Properties.of().strength(2.5f).sound(SoundType.WOOD), true);
	public static final Block TALLO_HONGO = register("tallo_hongo", RotatedPillarBlock::new, BlockBehaviour.Properties.of().strength(0.8f).sound(SoundType.WOOD), true);
	public static final Block TALLO_LUMINOSO = register("tallo_luminoso", RotatedPillarBlock::new, BlockBehaviour.Properties.of().strength(0.8f).sound(SoundType.WOOD).lightLevel(s -> 12), true);
	public static final Block HOJAS_FUNGALES = register("hojas_fungales", Block::new, BlockBehaviour.Properties.of().strength(0.3f).sound(SoundType.GRASS), true);
	public static final Block HOJAS_LUMINOSAS = register("hojas_luminosas", Block::new, BlockBehaviour.Properties.of().strength(0.3f).sound(SoundType.GRASS).lightLevel(s -> 10), true);
	public static final Block SOMBRERO_CARMESI = register("sombrero_carmesi", HugeMushroomBlock::new, BlockBehaviour.Properties.of().strength(0.4f).sound(SoundType.WOOD), true);
	public static final Block SOMBRERO_VIOLETA = register("sombrero_violeta", HugeMushroomBlock::new, BlockBehaviour.Properties.of().strength(0.4f).sound(SoundType.WOOD), true);
	public static final Block SOMBRERO_LUMINOSO = register("sombrero_luminoso", HugeMushroomBlock::new, BlockBehaviour.Properties.of().strength(0.4f).sound(SoundType.WOOD).lightLevel(s -> 12), true);
	public static final Block SOMBRERO_ROSA = register("sombrero_rosa", HugeMushroomBlock::new, BlockBehaviour.Properties.of().strength(0.4f).sound(SoundType.WOOD), true);
	public static final Block BLOQUE_ESPORAS = register("bloque_esporas", Block::new, BlockBehaviour.Properties.of().strength(0.5f).sound(SoundType.MOSS).lightLevel(s -> 5), true);
	public static final Block BLOQUE_ESPORAS_VENENOSO = register("bloque_esporas_venenoso", Block::new, BlockBehaviour.Properties.of().strength(0.5f).sound(SoundType.MOSS).lightLevel(s -> 4), true);
	public static final Block BLOQUE_CRISTAL_MICOTICO = register("bloque_cristal_micotico", Block::new, BlockBehaviour.Properties.of().strength(1.5f).requiresCorrectToolForDrops().sound(SoundType.AMETHYST).lightLevel(s -> 10), true);
	public static final Block LADRILLOS_MICELIO = register("ladrillos_micelio", Block::new, BlockBehaviour.Properties.of().strength(2.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block LADRILLOS_MICELIO_LOSA = register("ladrillos_micelio_losa", SlabBlock::new, BlockBehaviour.Properties.of().strength(2.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block LADRILLOS_MICELIO_ESCALERA = register("ladrillos_micelio_escalera", p -> new StairBlock(LADRILLOS_MICELIO.defaultBlockState(), p), BlockBehaviour.Properties.of().strength(2.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block LADRILLOS_PODRIDOS = register("ladrillos_podridos", Block::new, BlockBehaviour.Properties.of().strength(2.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block LAMPARA_MICELIO = register("lampara_micelio", Block::new, BlockBehaviour.Properties.of().strength(0.8f).sound(SoundType.GLASS).lightLevel(s -> 15), true);
	public static final Block MENA_CARMESI = register("mena_carmesi", Block::new, BlockBehaviour.Properties.of().strength(3.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block MENA_VIOLETA = register("mena_violeta", Block::new, BlockBehaviour.Properties.of().strength(3.0f).requiresCorrectToolForDrops().sound(SoundType.STONE), true);
	public static final Block MENA_CRISTAL = register("mena_cristal", Block::new, BlockBehaviour.Properties.of().strength(3.2f).requiresCorrectToolForDrops().sound(SoundType.AMETHYST).lightLevel(s -> 6), true);
	public static final Block MENA_PIEDRA_VIVIENTE = register("mena_piedra_viviente", Block::new, BlockBehaviour.Properties.of().strength(3.0f).requiresCorrectToolForDrops().sound(SoundType.STONE).lightLevel(s -> 4), true);
	public static final Block MENA_CORAZON = register("mena_corazon", Block::new, BlockBehaviour.Properties.of().strength(4.0f).requiresCorrectToolForDrops().sound(SoundType.STONE).lightLevel(s -> 7), true);
	public static final Block HONGO_LUMINOSO = register("hongo_luminoso", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().instabreak().sound(SoundType.GRASS).lightLevel(s -> 9), true);
	public static final Block HONGO_VENENOSO = register("hongo_venenoso", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().instabreak().sound(SoundType.GRASS).lightLevel(s -> 3), true);
	public static final Block HONGO_CARMESI = register("hongo_carmesi", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().instabreak().sound(SoundType.GRASS), true);
	public static final Block HONGO_VIOLETA = register("hongo_violeta", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().instabreak().sound(SoundType.GRASS), true);
	public static final Block PLANTA_LUMINOSA = register("planta_luminosa", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().instabreak().sound(SoundType.GRASS).lightLevel(s -> 8), true);
	public static final Block HIERBA_MICOTICA = register("hierba_micotica", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().instabreak().sound(SoundType.GRASS), true);
	public static final Block CRISTALES_MICOTICOS = register("cristales_micoticos", Block::new, BlockBehaviour.Properties.of().noCollision().noOcclusion().strength(1.0f).sound(SoundType.AMETHYST).lightLevel(s -> 8), true);
	public static final Block ALTAR_PORTAL = register("altar_portal", PortalAltarBlock::new, BlockBehaviour.Properties.of().strength(3.0f).noOcclusion().requiresCorrectToolForDrops().sound(SoundType.STONE).lightLevel(s -> 10), true);
	public static final Block HUEVO_MICOTICO = register("huevo_micotico", MicoEggBlock::new, BlockBehaviour.Properties.of().strength(0.5f).noOcclusion().randomTicks().sound(SoundType.MOSS), false);

	public static void initialize() {
		// el registro ocurre en la carga estatica de la clase
	}
}
