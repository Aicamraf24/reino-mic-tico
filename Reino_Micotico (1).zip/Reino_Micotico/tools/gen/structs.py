import math, random
from util import *

M = MOD + ':'
BR, BRS, BRST = M+'ladrillos_micelio', M+'ladrillos_micelio_losa', M+'ladrillos_micelio_escalera'
ROTBR, ROT, STONE = M+'ladrillos_podridos', M+'piedra_podrida', M+'piedra_fungosa'
STEM, STEMW, LOG, WOOD = M+'tallo_hongo', M+'tallo_luminoso', M+'tronco_gigante', M+'madera_micotica'
WOODS, WOODST = M+'madera_micotica_losa', M+'madera_micotica_escalera'
CAPC, CAPV, CAPL, CAPR = M+'sombrero_carmesi', M+'sombrero_violeta', M+'sombrero_luminoso', M+'sombrero_rosa'
LAMP, CRY, ROOTB, SPORE = M+'lampara_micelio', M+'bloque_cristal_micotico', M+'bloque_raices', M+'bloque_esporas'
MYCC, MYCV, DIRT = M+'micelio_carmesi', M+'micelio_violeta', M+'tierra_fungosa'
HLUM, HVEN, HCAR, HVIO, PLUM, CRYC = M+'hongo_luminoso', M+'hongo_venenoso', M+'hongo_carmesi', M+'hongo_violeta', M+'planta_luminosa', M+'cristales_micoticos'
ALTAR = M+'altar_portal'
F = 3  # capas de cimiento bajo el suelo (el origen se hunde 3 bloques)
Y = {'axis': 'y'}

def foundation(v, x0, z0, x1, z1, block=STONE):
    for x in range(x0, x1+1):
        for z in range(z0, z1+1):
            for y in range(0, F): v.set(x, y, z, block)

def disc_foundation(v, cx, cz, r, block=STONE):
    for x in range(cx-r, cx+r+1):
        for z in range(cz-r, cz+r+1):
            if math.hypot(x-cx, z-cz) <= r+0.3:
                for y in range(0, F): v.set(x, y, z, block)

def mushroom_house(v, cx, cz, r, h, cap, rng, doorface='south', loot='aldea'):
    y0 = F
    v.cyl(cx, cz, r, y0, y0+h, STEMW if False else STEM, Y, hollow=True)
    for y in (y0+2, y0+3):
        for (dx, dz) in ((r, 0), (-r, 0), (0, -r)):
            v.set(cx+dx, y, cz+dz, STEMW, Y)
    # puerta
    dz = r
    for y in (y0+1, y0+2): v.set(cx, y, cz+dz, 'minecraft:air')
    # suelo e interior
    for x in range(cx-r+1, cx+r):
        for z in range(cz-r+1, cz+r):
            if math.hypot(x-cx, z-cz) < r-0.9: v.set(x, y0, z, WOOD)
    v.dome(cx, y0+h, cz, r+3, 3, cap, None)
    v.set(cx, y0+h-1, cz, LAMP)
    v.chest(cx+1, y0+1, cz-1, loot)

def spiral(v, cx, cz, r0, r1, y0, n, block):
    for i in range(n):
        a = i*0.34
        y = y0 + i//2
        for rr in (r0, r1):
            v.set(cx+round(rr*math.cos(a)), y, cz+round(rr*math.sin(a)), block)

# ------------------------------------------------------------------ estructuras
def aldea():
    v = Vox(33, 16, 33); rng = random.Random(11)
    disc_foundation(v, 16, 16, 15, STONE)
    for x in range(1, 32):
        for z in range(1, 32):
            if math.hypot(x-16, z-16) <= 15: v.set(x, F, z, MYCV if (x+z) % 5 else MYCC)
    for (cx, cz, r, h, cap) in ((8, 8, 3, 5, CAPC), (24, 8, 3, 6, CAPV), (8, 24, 3, 5, CAPR), (24, 24, 3, 6, CAPC), (16, 5, 2, 4, CAPL)):
        mushroom_house(v, cx, cz, r, h, cap, rng)
    # pozo central
    v.hollow(14, F, 14, 18, F+2, 18, BR)
    for x in range(15, 18):
        for z in range(15, 18): v.set(x, F, z, 'minecraft:water', {'level': 0}); v.set(x, F+1, z, 'minecraft:air'); v.set(x, F+2, z, 'minecraft:air')
    for (x, z) in ((14, 14), (18, 14), (14, 18), (18, 18)):
        v.fill(x, F+3, z, x, F+5, z, LOG, Y)
    v.fill(14, F+6, 14, 18, F+6, 18, WOODS)
    for x in range(10, 23): v.set(x, F, 22, M+'bloque_raices') if x % 2 == 0 else None
    for (x, z) in ((12, 12), (20, 12), (12, 20), (20, 20)):
        v.set(x, F+1, z, HLUM); v.set(x+1, F+1, z, PLUM)
    return v

def ciudad():
    v = Vox(47, 44, 47); c = 23
    disc_foundation(v, c, c, 22, STONE)
    for y in range(F, F+3):
        v.cyl(c, c, 21 - (y-F), y, y, BR)
    for x in range(c-19, c+20):
        for z in range(c-19, c+20):
            if math.hypot(x-c, z-c) <= 18: v.set(x, F+3, z, MYCV if (x+z) % 4 else MYCC)
    # torre principal
    v.cyl(c, c, 5, F+3, F+30, STEM, Y, hollow=True)
    for y in range(F+6, F+30, 4):
        for (dx, dz) in ((5, 0), (-5, 0), (0, 5), (0, -5)): v.set(c+dx, y, c+dz, STEMW, Y); v.set(c+dx, y+1, c+dz, STEMW, Y)
    spiral(v, c, c, 3, 4, F+4, 50, BR)
    v.dome(c, F+31, c, 13, 5, CAPR, None)
    v.dome(c, F+36, c, 6, 3, CAPV, None)
    v.cyl(c, c, 1, F+39, F+43, STEMW, Y)
    # torres menores
    for (dx, dz, cap) in ((14, 0, CAPV), (-14, 0, CAPC), (0, 14, CAPL), (0, -14, CAPR)):
        tx, tz = c+dx, c+dz
        v.cyl(tx, tz, 3, F+3, F+17, STEM, Y, hollow=True)
        for y in (F+8, F+12): v.set(tx+3, y, tz, STEMW, Y); v.set(tx-3, y, tz, STEMW, Y); v.set(tx, y, tz+3, STEMW, Y)
        v.dome(tx, F+18, tz, 7, 3, cap, None)
        v.set(tx, F+17, tz, LAMP)
        # puente al torre principal
        for t in range(6, 12):
            px = c + round(dx*t/14) ; pz = c + round(dz*t/14)
            v.set(px, F+12, pz, BRS); v.set(px+(1 if dz else 0), F+12, pz+(1 if dx else 0), BRS)
    for (dx, dz) in ((9, 9), (-9, 9), (9, -9), (-9, -9)):
        v.set(c+dx, F+4, c+dz, LAMP); v.chest(c+dx+1, F+4, c+dz, 'ciudad')
    for (dx, dz) in ((16, 8), (-16, -8), (8, -16), (-8, 16)):
        v.fill(c+dx, F+4, c+dz, c+dx, F+6, c+dz, STEM, Y); v.dome(c+dx, F+7, c+dz, 3, 1, CAPC, None)
    return v

def templo():
    v = Vox(27, 22, 27); c = 13
    foundation(v, 0, 0, 26, 26, STONE)
    sizes = [12, 10, 8, 6, 4]
    for i, h in enumerate(sizes):
        y = F + i*3
        for yy in range(y, y+3): v.fill(c-h, yy, c-h, c+h, yy, c+h, BR if (yy % 2) else ROTBR)
    # tunel y camara
    for z in range(c, 27):
        for x in range(c-1, c+2):
            for y in range(F, F+3): v.set(x, y, z, 'minecraft:air')
    for x in range(c-3, c+4):
        for z in range(c-3, c+4):
            for y in range(F, F+5): v.set(x, y, z, 'minecraft:air')
    for (dx, dz) in ((-3, -3), (3, -3), (-3, 3), (3, 3)): v.fill(c+dx, F, c+dz, c+dx, F+3, c+dz, STEMW, Y)
    v.chest(c, F, c-2, 'templo'); v.chest(c+1, F, c-2, 'templo')
    v.set(c, F+4, c, LAMP); v.set(c-2, F, c+2, CRYC); v.set(c+2, F, c+2, CRYC)
    v.fill(c-1, F+15, c-1, c+1, F+16, c+1, CRY); v.set(c, F+17, c, LAMP)
    return v

def torre():
    v = Vox(15, 54, 15); c = 7
    disc_foundation(v, c, c, 6, STONE)
    v.cyl(c, c, 6, F, F+38, STEM, Y, hollow=True)
    for y in range(F+4, F+38, 5):
        for (dx, dz) in ((6, 0), (-6, 0), (0, 6), (0, -6)): v.set(c+dx, y, c+dz, STEMW, Y); v.set(c+dx, y+1, c+dz, STEMW, Y)
    for y in (F+1, F+2): v.set(c, y, c+6, 'minecraft:air')
    spiral(v, c, c, 3, 4, F+1, 74, BR)
    v.fill(c-4, F+39, c-4, c+4, F+39, c+4, WOOD)
    v.dome(c, F+40, c, 7, 5, CAPV, None)
    v.dome(c, F+45, c, 3, 3, CAPL, None)
    v.chest(c, F+40, c-2, 'torre'); v.set(c, F+41, c, LAMP)
    return v

def puente():
    v = Vox(31, 12, 7)
    for x in range(0, 31):
        t = x/30.0
        h = round(math.sin(t*math.pi)*5)
        for z in (2, 3, 4):
            v.set(x, F+h, z, ROOTB)
            for y in range(F, F+h): 
                if z == 3 and (x % 4 == 0): v.set(x, y, z, ROOTB)
        for z in (1, 5): v.set(x, F+h+1, z, WOODS)
        if x % 5 == 0:
            for z in (1, 5): v.set(x, F+h+1, z, LOG, Y); v.set(x, F+h+2, z, HCAR if x % 10 else HLUM)
    for x in (0, 1, 29, 30):
        for z in range(1, 6):
            for y in range(0, F+1): v.set(x, y, z, STONE)
    v.chest(15, F+6, 3, 'puente')
    return v

def laboratorio():
    v = Vox(17, 11, 17)
    foundation(v, 1, 1, 15, 15, STONE)
    v.hollow(1, F, 1, 15, F+5, 15, ROTBR)
    for x in range(2, 15):
        for z in range(2, 15): v.set(x, F, z, WOOD)
    for y in (F+2, F+3):
        for x in range(3, 14, 2): v.set(x, y, 1, CRY); v.set(x, y, 15, CRY)
        for z in range(3, 14, 2): v.set(1, y, z, CRY); v.set(15, y, z, CRY)
    for y in (F+1, F+2): v.set(8, y, 15, 'minecraft:air')
    v.fill(0, F+6, 0, 16, F+6, 16, WOODS)
    for (x, z) in ((3, 3), (13, 3), (3, 13), (13, 13)): v.set(x, F+1, z, 'minecraft:cauldron'); v.set(x, F+5, z, LAMP)
    v.set(8, F+1, 3, 'minecraft:brewing_stand'); v.set(6, F+1, 3, 'minecraft:brewing_stand'); v.set(10, F+1, 3, 'minecraft:cauldron')
    v.chest(3, F+1, 8, 'laboratorio', 'east'); v.chest(13, F+1, 8, 'laboratorio', 'west')
    v.fill(7, F+1, 8, 9, F+1, 8, BRS); v.set(8, F+2, 8, HVEN)
    return v

def nido(idx):
    v = Vox(19, 9, 19); c = 9
    disc_foundation(v, c, c, 8, STONE)
    for x in range(19):
        for z in range(19):
            d = math.hypot(x-c, z-c)
            if d <= 8:
                v.set(x, F, z, ROOTB if d > 5 else SPORE)
                if 5 < d <= 8: v.set(x, F+1, z, ROOTB)
                if 6.5 < d <= 8 and (x+z) % 2: v.set(x, F+2, z, ROOTB)
    for i, (dx, dz) in enumerate(((0, 0), (2, 1), (-2, 2), (1, -2), (-2, -2), (3, -1))):
        v.set(c+dx, F+1, c+dz, M+'huevo_micotico', {'species': idx[i % len(idx)], 'hatch': 0})
    v.chest(c-3, F+1, c+3, 'nido')
    return v

def cueva():
    v = Vox(17, 11, 17); c = 8; rng = random.Random(5)
    for x in range(17):
        for y in range(11):
            for z in range(17):
                d = math.sqrt((x-c)**2 + ((y-5)*1.4)**2 + (z-c)**2)
                if d <= 8.5:
                    if d > 6.6: v.set(x, y, z, CRY if rng.random() < 0.35 else STONE)
                    else: v.set(x, y, z, 'minecraft:air')
    for x in range(3, 14):
        for z in range(3, 14):
            if math.hypot(x-c, z-c) < 6: v.set(x, 2, z, ROT if rng.random() < .6 else STONE)
    v.chest(c-2, 3, c, 'tesoro', 'east'); v.chest(c+2, 3, c, 'tesoro', 'west')
    for (dx, dz) in ((3, 3), (-3, 3), (3, -3), (-3, -3), (0, 4)): v.set(c+dx, 3, c+dz, CRYC)
    v.set(c, 3, c, M+'mena_corazon'); v.set(c, 9, c, LAMP)
    return v

def jardin():
    v = Vox(19, 10, 19); c = 9; rng = random.Random(8)
    disc_foundation(v, c, c, 8, STONE)
    for x in range(19):
        for z in range(19):
            d = math.hypot(x-c, z-c)
            if d <= 7.4:
                v.set(x, F, z, MYCV if (x*z) % 3 else MYCC)
                if d > 6.2:
                    for y in range(F+1, F+4): v.set(x, y, z, ROTBR)
                elif d < 2.2: v.set(x, F, z, 'minecraft:water', {'level': 0})
                elif rng.random() < 0.45: v.set(x, F+1, z, rng.choice([HLUM, PLUM, HVIO, HCAR, M+'hierba_micotica']))
    for y in (F+1, F+2): v.set(c, y, c+7, 'minecraft:air'); v.set(c, y, c+6, 'minecraft:air')
    v.fill(c, F+1, c-4, c, F+3, c-4, STEM, Y); v.dome(c, F+4, c-4, 3, 1, CAPL, None)
    v.chest(c+3, F+1, c-4, 'jardin')
    return v

def santuario():
    v = Vox(23, 16, 23); c = 11
    disc_foundation(v, c, c, 10, STONE)
    for x in range(23):
        for z in range(23):
            d = math.hypot(x-c, z-c)
            if d <= 10: v.set(x, F, z, BR if int(d) % 2 else ROTBR)
    for i in range(8):
        a = i*math.pi/4; px, pz = c+round(9*math.cos(a)), c+round(9*math.sin(a))
        v.fill(px, F+1, pz, px, F+8, pz, STEMW, Y); v.set(px, F+9, pz, CAPV); v.set(px, F+10, pz, LAMP)
    v.cyl(c, c, 3, F+1, F+1, BR)
    v.set(c, F+2, c, ALTAR); v.set(c, F+3, c, CRYC)
    for (dx, dz) in ((2, 0), (-2, 0), (0, 2), (0, -2)): v.set(c+dx, F+2, c+dz, LAMP)
    v.chest(c-5, F+1, c, 'santuario', 'east')
    return v

def ruinas():
    v = Vox(21, 10, 21); rng = random.Random(21)
    foundation(v, 1, 1, 19, 19, STONE)
    for x in range(1, 20):
        for z in range(1, 20):
            v.set(x, F, z, ROTBR if rng.random() < 0.6 else ROT)
    for (x0, z0, x1, z1) in ((3, 3, 17, 17), (7, 7, 13, 13)):
        for x in range(x0, x1+1):
            for z in range(z0, z1+1):
                if x in (x0, x1) or z in (z0, z1):
                    hgt = rng.randint(0, 5)
                    for y in range(F+1, F+1+hgt): 
                        if rng.random() < 0.85: v.set(x, y, z, ROTBR if rng.random() < .7 else BR)
    for _ in range(14): v.set(rng.randint(2, 18), F+1, rng.randint(2, 18), rng.choice([HVEN, HVIO, HLUM, PLUM]))
    v.chest(10, F+1, 10, 'ruinas')
    return v

def trono():
    v = Vox(47, 32, 47); c = 23
    disc_foundation(v, c, c, 22, ROT)
    for x in range(47):
        for z in range(47):
            d = math.hypot(x-c, z-c)
            if d <= 21: v.set(x, F, z, ROTBR if (x//2+z//2) % 2 else ROT)
            if 21 < d <= 22: v.set(x, F, z, ROOTB)
    for i in range(14):
        a = i*2*math.pi/14; px, pz = c+round(19*math.cos(a)), c+round(19*math.sin(a))
        v.fill(px, F+1, pz, px, F+11, pz, LOG, Y); v.set(px, F+12, pz, CAPC if i % 2 else CAPV); v.set(px, F+13, pz, LAMP)
        v.set(px, F+1, pz, ROTBR)
    # peldanos y trono (al norte)
    for k in range(4):
        v.fill(c-8+k, F+1+k, c-20, c+8-k, F+1+k, c-14+k*0, ROTBR)
    ty = F+5
    v.fill(c-3, ty, c-20, c+3, ty, c-17, ROOTB)
    v.fill(c-1, ty+1, c-19, c+1, ty+1, c-18, ROOTB)
    for y in range(ty+1, ty+9):
        v.set(c-2, y, c-20, ROOTB); v.set(c+2, y, c-20, ROOTB)
        if y < ty+7: v.fill(c-1, y, c-20, c+1, y, c-20, ROOTB)
    for dx in (-2, -1, 0, 1, 2): v.set(c+dx, ty+9, c-20, CAPC); v.set(c+dx, ty+10, c-20, CAPC)
    v.set(c, ty+11, c-20, LAMP)
    v.chest(c-5, ty, c-19, 'trono'); v.chest(c+5, ty, c-19, 'trono')
    for (dx, dz) in ((-10, -6), (10, -6), (-12, 6), (12, 6), (0, 10)):
        v.set(c+dx, F+1, c+dz, CRYC); v.set(c+dx+1, F+1, c+dz, HVEN)
    v.entity(c, ty+1, c-16, M+'rey_micotico')
    return v

def isla():
    v = Vox(23, 20, 23); c = 11; rng = random.Random(33)
    for x in range(23):
        for z in range(23):
            d = math.hypot(x-c, z-c)
            if d <= 10:
                depth = int((10-d)*0.9)
                for y in range(9-depth, 10):
                    v.set(x, y, z, STONE if y < 8 else DIRT)
                v.set(x, 10, z, MYCV if (x+z) % 3 else MYCC)
    v.fill(c, 11, c, c, 15, c, STEMW, Y); v.dome(c, 16, c, 6, 3, CAPL, None)
    for _ in range(18): v.set(rng.randint(2, 20), 11, rng.randint(2, 20), rng.choice([HLUM, PLUM, HCAR, HVIO]))
    v.set(c+4, 11, c, 'minecraft:water', {'level': 0}); v.set(c+5, 11, c, 'minecraft:water', {'level': 0})
    v.chest(c-4, 11, c+1, 'isla')
    return v
