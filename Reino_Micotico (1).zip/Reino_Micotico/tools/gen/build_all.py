import shutil, zipfile, os, sys
sys.path.insert(0, '/home/claude/gen')
from util import *
if os.path.exists(OUT): shutil.rmtree(OUT)
import world as W
from world import *

gen_entities()
gen_species_json()
A.gen_blocks()
A.gen_items(ALL)
gen_loot(); gen_recipes(); gen_tags()
W.gen_features(); W.gen_biomes(); W.gen_structures()
gen_lang()
gen_java_registries(); copy_static(); gen_build()
# generador incluido en el ZIP para poder regenerar
shutil.copytree('/home/claude/gen', path('tools/gen'), ignore=shutil.ignore_patterns('__pycache__'))
write('README.md', open('/home/claude/gen/README_template.md', encoding='utf-8').read())
print('proyecto generado en', OUT)
