import math, random
from util import *

def P(name, role, box, pivot, rot=(0, 0, 0), parent=None, tags=()):
    return dict(name=name, role=role, box=tuple(box), pivot=tuple(pivot), rot=tuple(rot), parent=parent, tags=set(tags))

def cap(parts, parent, cx, cy, cz, r, h=2, name='cap', sig=False, extra=()):
    t = {'cap'} | ({'sig'} if sig else set()) | set(extra)
    parts.append(P(name + '_a', 'static', (-r, -h, -r, 2*r, h, 2*r), (cx, cy, cz), parent=parent, tags=t))
    if r >= 3:
        parts.append(P(name + '_b', 'static', (-r+2, -h-1.5, -r+2, 2*r-4, 1.5, 2*r-4), (cx, cy, cz), parent=parent, tags=t))
    parts.append(P(name + '_s', 'static', (-1, 0, -1, 2, max(2, h), 2), (cx, cy, cz), parent=parent, tags={'stem'} | set(extra)))

# ---------------------------------------------------------------- planes
def quad(p):
    L, W, H, leg, lw, hs = p['L'], p['W'], p['H'], p['leg'], p['lw'], p['hs']
    neck = p.get('neck', 0); by = 24 - leg - H/2
    parts = [P('body', 'body', (-W/2, -H/2, -L/2, W, H, L), (0, by, 0))]
    hy = by - H/2 + 2 - neck
    if neck:
        parts.append(P('neck', 'static', (-hs/3, -neck, -1.5, 2*hs/3, neck+2, 3), (0, by - H/2 + 2, -L/2 + 2), rot=(-0.35, 0, 0), parent=None, tags=()))
    parts.append(P('head', 'head', (-hs/2, -hs/2, -hs+1, hs, hs, hs), (0, hy, -L/2 + 0.5 - neck*0.35), tags={'face'}))
    for i, (sx, sz) in enumerate([(-1, -1), (1, -1), (-1, 1), (1, 1)]):
        parts.append(P(f'leg{i}', 'leg', (-lw/2, 0, -lw/2, lw, leg, lw), (sx*(W/2 - lw/2), 24 - leg, sz*(L/2 - lw/2 - 0.5)), tags={'leg'}))
    f = p.get('feats', [])
    if 'ears' in f:
        eh = p.get('ear', 3)
        for sx in (-1, 1):
            parts.append(P(f'ear{sx}', 'static', (-1, -eh, -0.5, 2, eh, 1), (sx*hs/3, -hs/2, -hs/2 + 2), rot=(0, 0, sx*0.3), parent='head', tags={'sig'} if p.get('ear_sig') else ()))
    if 'antlers' in f:
        for sx in (-1, 1):
            parts.append(P(f'ant{sx}', 'static', (-0.5, -7, -0.5, 1, 7, 1), (sx*hs/4, -hs/2, -hs/2 + 2), rot=(0.15, 0, sx*0.4), parent='head', tags={'sig', 'glow'}))
            parts.append(P(f'antb{sx}', 'static', (-0.5, -4, -0.5, 1, 4, 1), (0, -4, 0), rot=(-0.5, 0, sx*0.9), parent=f'ant{sx}', tags={'sig', 'glow'}))
            parts.append(P(f'antc{sx}', 'static', (-0.5, -4, -0.5, 1, 4, 1), (0, -7, 0), rot=(0.4, 0, -sx*0.3), parent=f'ant{sx}', tags={'sig', 'glow'}))
    if 'tail' in f:
        tl, tw = p.get('tail', (5, 3))
        parts.append(P('tail', 'tail', (-tw/2, -tw/2, 0, tw, tw, tl), (0, by - H/2 + 2, L/2 - 1), rot=(-0.5, 0, 0), tags={'sig'} if p.get('tail_sig') else ()))
    if 'snout' in f:
        sl = p.get('snout', 3)
        parts.append(P('snout', 'static', (-1.5, -1, -sl, 3, 2.5, sl), (0, hs*0.15, -hs + 1.5), parent='head', tags={'snout'}))
    if 'tusks' in f:
        for sx in (-1, 1):
            parts.append(P(f'tusk{sx}', 'static', (-0.5, -3, -0.5, 1, 3, 1), (sx*hs/3, hs*0.3, -hs + 1), rot=(0.3, 0, sx*0.3), parent='head', tags={'tusk'}))
    if 'jaw' in f:
        parts.append(P('jaw', 'jaw', (-hs/2 + 1, 0, -hs + 1, hs - 2, 3, hs - 1), (0, hs/2 - 1, 0), parent='head', tags={'dark'}))
        for sx in (-1, 0, 1):
            parts.append(P(f'fang{sx}', 'static', (-0.5, -2, -0.5, 1, 2, 1), (sx*hs/3, 0.3, -hs + 1.5), parent='jaw', tags={'tusk'}))
    if 'spikes' in f:
        for i in range(4):
            parts.append(P(f'spike{i}', 'static', (-1, -4, -1, 2, 4, 2), (0, -H/2, -L/2 + 3 + i*(L-5)/3), rot=(0, 0, 0), parent='body', tags={'tusk'}))
    for i, (cx, cz, r) in enumerate(p.get('caps', [])):
        cap(parts, 'body', cx, -H/2, cz, r, 2, f'bcap{i}', sig=(i == 0 and p.get('cap_sig', False)))
    if 'hat' in f:
        cap(parts, 'head', 0, -hs/2 + 1, -hs/2 + 1, p.get('hat', 5), 2, 'hat', sig=True)
    if 'horns' in f:
        for sx in (-1, 1):
            parts.append(P(f'horn{sx}', 'static', (-0.5, -5, -0.5, 1.5, 5, 1.5), (sx*hs/3, -hs/2, -hs/2 + 2), rot=(0.3, 0, sx*0.5), parent='head', tags={'tusk'}))
    return parts

def biped(p):
    m = p.get('m', 1.0); a = 24
    lh = 12*m; th = 12*m; tw = 8*m; hs = p.get('hs', 8)*m; aw = 4*m
    parts = [P('body', 'body', (-tw/2, -th, -2*m, tw, th, 4*m), (0, a - lh, 0))]
    parts.append(P('head', 'head', (-hs/2, -hs, -hs/2, hs, hs, hs), (0, a - lh - th, 0), tags={'face'}))
    for i, sx in enumerate((-1, 1)):
        parts.append(P(f'leg{i}', 'leg', (-aw/2, 0, -aw/2, aw, lh, aw), (sx*aw*0.55, a - lh, 0), tags={'leg'}))
        parts.append(P(f'arm{i}', 'arm', (-aw/2 - (0 if sx < 0 else 0), -1.5*m, -aw/2, aw*p.get('armw', 1.0), p.get('armh', 12)*m, aw*p.get('armw', 1.0)), (sx*(tw/2 + aw/2), a - lh - th + 2*m, 0), tags={'leg', 'arm'}))
    f = p.get('feats', [])
    if 'hat' in f: cap(parts, 'head', 0, -hs + 1, 0, int(hs*0.9), 2, 'hat', sig=True)
    if 'shoulders' in f:
        for i, sx in enumerate((-1, 1)):
            cap(parts, f'arm{i}', 0, -1.5*m, 0, 4, 2, f'sh{i}')
    if 'backcap' in f:
        cap(parts, 'body', 0, -th*0.5, 3*m, int(p.get('bc', 5)), 2, 'bk')
    if 'horns' in f:
        for sx in (-1, 1):
            parts.append(P(f'horn{sx}', 'static', (-0.5, -5, -0.5, 1.5, 5, 1.5), (sx*hs/3, -hs, 0), rot=(0, 0, sx*0.5), parent='head', tags={'tusk'}))
    if 'cracks' in f:
        parts.append(P('chest', 'static', (-tw/2 + 1, 2, -2*m - 0.5, tw - 2, 4*m, 1), (0, -th, 0), parent='body', tags={'glow'}))
    if 'staff' in f:
        parts.append(P('staff', 'static', (-1, -14, -1, 2, 30, 2), (0, 10*m, -2), parent='arm1', tags={'dark'}))
        cap(parts, 'staff', 0, -14, 0, 3, 2, 'sc', extra=('glow',))
    if 'claws' in f:
        for i in (0, 1):
            parts.append(P(f'claw{i}', 'static', (-1, 0, -2, 2, 3, 4), (0, p.get('armh', 12)*m - 1, 0), parent=f'arm{i}', tags={'tusk'}))
    return parts

def side_legs(parts, n, y, z0, z1, span, drop, thick=1.5, length=14, parent=None):
    """patas laterales (insectos/aranas): n pares, repartidas de z0 a z1."""
    for i in range(n):
        z = z0 + (z1 - z0)*i/max(1, n - 1)
        for k, sx in enumerate((-1, 1)):
            idx = i*2 + k
            yaw = (-0.5 + i*(1.0/max(1, n - 1)))*(0.9 if n > 1 else 0)
            box = (0, -thick/2, -thick/2, length, thick, thick) if sx > 0 else (-length, -thick/2, -thick/2, length, thick, thick)
            parts.append(P(f'leg{idx}', 'sleg', box, (sx*span, y, z), rot=(0, sx*yaw, sx*drop), parent=parent, tags={'leg'}))

def spider(p):
    s = p.get('s', 1.0); y = 24 - 6*s
    parts = [P('body', 'body', (-4*s, -3*s, -4*s, 8*s, 6*s, 8*s), (0, y, 0)),
             P('abd', 'static', (-5*s, -4*s, 0, 10*s, 8*s, 11*s), (0, y - 1*s, 4*s), parent=None, tags={'sac'}),
             P('head', 'head', (-3*s, -3*s, -5*s, 6*s, 6*s, 6*s), (0, y, -4*s), tags={'face'})]
    for sx in (-1, 1):
        parts.append(P(f'fang{sx}', 'static', (-0.5, 0, -0.5, 1.2, 3*s, 1.2), (sx*1.5*s, 2*s, -5*s), parent='head', tags={'tusk'}))
    side_legs(parts, 4, y + 1*s, -3*s, 3*s, 3.5*s, 0.55, thick=2*s if s < 2 else 3, length=int(14*s))
    f = p.get('feats', [])
    if 'backcap' in f: cap(parts, 'abd', 0, -4*s, 5*s, int(p.get('bc', 5)*s), 2, 'bk', sig=True)
    if 'crown' in f:
        for i, a in enumerate((-0.6, -0.2, 0.2, 0.6)):
            parts.append(P(f'crown{i}', 'static', (-0.7, -5, -0.7, 1.4, 5, 1.4), (a*5*s, -3*s, -1*s), rot=(0, 0, a*0.4), parent='head', tags={'glow'}))
    if 'cap_head' in f:
        cap(parts, 'head', 0, -3*s, -2*s, int(p.get('hc', 7)*s), 3, 'hc', sig=True)
    return parts

def insect(p):
    """escarabajo / reptador con 6 patas laterales."""
    s = p.get('s', 1.0); y = 24 - 5*s
    parts = [P('body', 'body', (-5*s, -3*s, -6*s, 10*s, 6*s, 12*s), (0, y, 0), tags={'shell'}),
             P('head', 'head', (-3*s, -2.5*s, -4*s, 6*s, 5*s, 5*s), (0, y, -6*s), tags={'face'})]
    side_legs(parts, 3, y + 2*s, -4*s, 4*s, 4.5*s, 0.6, thick=1.5*s, length=int(8*s) + 2)
    f = p.get('feats', [])
    if 'horn' in f:
        parts.append(P('horn', 'static', (-1, -6*s, -1, 2, 6*s, 2), (0, -2*s, -3*s), rot=(-0.7, 0, 0), parent='head', tags={'tusk', 'sig'}))
        parts.append(P('horn2', 'static', (-0.7, -3*s, -0.7, 1.4, 3*s, 1.4), (0, -5*s, 0), rot=(0.9, 0, 0), parent='horn', tags={'tusk', 'sig'}))
    if 'antenna' in f:
        for sx in (-1, 1):
            parts.append(P(f'ant{sx}', 'static', (-0.4, -6, -0.4, 0.8, 6, 0.8), (sx*1.5, -2, -4*s), rot=(-0.5, 0, sx*0.4), parent='head', tags={'glow', 'sig'}))
    if 'caps' in f:
        for i, (cx, cz, r) in enumerate(p.get('caps', [])): cap(parts, 'body', cx, -3*s, cz, r, 2, f'bc{i}')
    if 'wingcase' in f:
        for sx in (-1, 1):
            parts.append(P(f'case{sx}', 'wing', (0 if sx > 0 else -4*s, -1, 0, 4*s, 1, 11*s), (sx*0.5, -3*s, -5.5*s), rot=(0, 0, sx*0.05), parent='body', tags={'shell', 'wing_' + ('r' if sx > 0 else 'l')}))
    return parts

def seg(p):
    n = p.get('n', 6); w = p.get('w', 6); h = p.get('h', 5); ln = p.get('ln', 5); y = 24 - h/2
    parts = []
    for i in range(n):
        k = 1.0 - 0.45*i/n if p.get('taper', True) else 1.0
        parts.append(P(f'seg{i}', f'seg{i}', (-w*k/2, -h*k/2, 0, w*k, h*k, ln), (0, y, i*(ln - 0.5) - 0 + 0), tags={'shell'} if i % 2 else ()))
    parts.append(P('head', 'head', (-w/2, -h/2, -4, w, h, 5), (0, y, 0), tags={'face'}))
    f = p.get('feats', [])
    if 'legs' in f:
        k = 0
        for i in range(n):
            for sx in (-1, 1):
                parts.append(P(f'leg{k}', 'sleg', (0 if sx > 0 else -6, -0.5, -0.5, 6, 1, 1), (sx*w*0.45, y + h/2 - 1, i*(ln - 0.5) + ln/2), rot=(0, 0, sx*0.9), tags={'leg'}))
                k += 1
    if 'antenna' in f:
        for sx in (-1, 1):
            parts.append(P(f'ant{sx}', 'static', (-0.4, -7, -0.4, 0.8, 7, 0.8), (sx*2, -h/2, -3), rot=(-0.7, 0, sx*0.3), parent='head', tags={'glow', 'sig'}))
    if 'jaws' in f:
        parts.append(P('jaw', 'jaw', (-w/2 + 1, 0, -4, w - 2, 2, 5), (0, h/2 - 1.5, 0), parent='head', tags={'dark'}))
        for sx in (-1, 1): parts.append(P(f'fang{sx}', 'static', (-0.5, -2, -0.5, 1, 2, 1), (sx*w/4, 0, -3.5), parent='jaw', tags={'tusk'}))
    if 'caps' in f:
        for i in range(2, n, 2): cap(parts, f'seg{i}', 0, -h/2*0.8, ln/2, 3, 2, f'sc{i}')
    return parts

def turtle(p):
    parts = [P('body', 'body', (-5, -2, -7, 10, 4, 14), (0, 20, 0), tags={'belly'}),
             P('shell1', 'static', (-6, -3, -8, 12, 3, 16), (0, 0, 0), parent='body', tags={'shell'}),
             P('shell2', 'static', (-4, -5, -6, 8, 2, 12), (0, 0, 0), parent='body', tags={'shell'}),
             P('head', 'head', (-2.5, -2.5, -5, 5, 5, 5), (0, 19, -7), tags={'face'})]
    for i, (sx, sz) in enumerate([(-1, -1), (1, -1), (-1, 1), (1, 1)]):
        parts.append(P(f'leg{i}', 'leg', (-1.5, 0, -1.5, 3, 4, 3), (sx*5.5, 20, sz*5), tags={'leg'}))
    for i, (cx, cz, r) in enumerate([(-2, -2, 3), (2, 3, 2)]): cap(parts, 'shell2', cx, -5, cz, r, 2, f'tc{i}', sig=(i == 0))
    return parts

def snail(p):
    parts = [P('body', 'body', (-2.5, -2, -6, 5, 3, 12), (0, 22, 0), tags={'belly'}),
             P('head', 'head', (-2, -2, -3, 4, 4, 3), (0, 20, -6), rot=(-0.4, 0, 0), tags={'face'}),
             P('shell1', 'static', (-4, -9, -1, 8, 9, 3), (0, 0, 0), parent='body', rot=(0, 0, 0), tags={'shell', 'sig'}),
             P('shell2', 'static', (-3, -7, -1, 6, 7, 3), (0, -1, 3), parent='body', tags={'shell', 'sig', 'glow'}),
             P('shell3', 'static', (-2, -5, -1, 4, 5, 2), (0, -2, 6), parent='body', tags={'shell', 'sig'})]
    for sx in (-1, 1):
        parts.append(P(f'eye{sx}', 'static', (-0.5, -5, -0.5, 1, 5, 1), (sx*1.2, -2, -1), rot=(-0.2, 0, sx*0.2), parent='head', tags={'glow'}))
    return parts

def frog(p):
    parts = [P('body', 'body', (-3.5, -2.5, -4, 7, 5, 8), (0, 19, 0)),
             P('head', 'head', (-3.5, -2, -5, 7, 4, 5), (0, 18, -3.5), tags={'face'})]
    for sx in (-1, 1):
        parts.append(P(f'eye{sx}', 'static', (-1.5, -3, -1.5, 3, 3, 3), (sx*2.5, -1.5, -2.5), parent='head', tags={'eye'}))
    for i, (sx, sz, l, w) in enumerate([(-1, -1, 4, 2), (1, -1, 4, 2), (-1, 1, 7, 3), (1, 1, 7, 3)]):
        parts.append(P(f'leg{i}', 'leg', (-w/2, 0, -w/2, w, l, w), (sx*(3.5 + (0.5 if sz > 0 else 0)), 24 - l, sz*3), tags={'leg'}))
    for i, (x, z) in enumerate([(-1.5, 0.5), (1.5, 2.5), (0, -2)]):
        parts.append(P(f'glow{i}', 'static', (-1, -0.5, -1, 2, 0.5, 2), (x, -2.5, z), parent='body', tags={'glow'}))
    return parts

def fly(p):
    kind = p['kind']; parts = []
    if kind == 'firefly':
        parts = [P('body', 'body', (-1.5, -1.5, -2, 3, 3, 4), (0, 17, 0)),
                 P('head', 'head', (-1.5, -1.5, -3, 3, 3, 3), (0, 17, -2), tags={'face'}),
                 P('abd', 'static', (-2.5, -2.5, 0, 5, 5, 7), (0, 0.5, 2), parent='body', tags={'glow', 'sac'})]
        for sx in (-1, 1):
            parts.append(P(f'wing{sx}', 'wing', (0 if sx > 0 else -6, 0, 0, 6, 0.5, 8), (sx*1, -1.5, -1), rot=(0, 0, sx*0.2), parent='body', tags={'sig', 'wing_' + ('r' if sx > 0 else 'l')}))
            parts.append(P(f'ant{sx}', 'static', (-0.3, -5, -0.3, 0.6, 5, 0.6), (sx*0.8, -1.5, -1.5), rot=(-0.6, 0, sx*0.3), parent='head', tags={'glow', 'sig'}))
        for i in range(3):
            for sx in (-1, 1):
                parts.append(P(f'leg{i*2+(sx>0)}', 'static', (-0.4, 0, -0.4, 0.8, 3, 0.8), (sx*1.2, 1.5, -1 + i*1.5), rot=(0, 0, sx*0.3), parent='body', tags={'leg'}))
    elif kind == 'butterfly':
        parts = [P('body', 'body', (-1, -1, -4, 2, 2, 8), (0, 16, 0)),
                 P('head', 'head', (-1.5, -1.5, -2.5, 3, 3, 3), (0, 16, -4), tags={'face'})]
        for sx in (-1, 1):
            side = 'r' if sx > 0 else 'l'
            parts.append(P(f'wing{sx}a', 'wing', (0 if sx > 0 else -8, 0, -5, 8, 0.5, 6), (sx*0.8, -1, 0), parent='body', tags={'wing_'+side, 'sig', 'wingpat'}))
            parts.append(P(f'wing{sx}b', 'wing', (0 if sx > 0 else -6, 0, 1, 6, 0.5, 5), (sx*0.8, -1, 0), parent='body', tags={'wing_'+side, 'wingpat'}))
            parts.append(P(f'ant{sx}', 'static', (-0.3, -5, -0.3, 0.6, 5, 0.6), (sx*0.8, -1.5, -1.5), rot=(-0.5, 0, sx*0.4), parent='head', tags={'glow', 'sig'}))
    elif kind == 'bat':
        parts = [P('body', 'body', (-2.5, -3, -2, 5, 6, 4), (0, 17, 0)),
                 P('head', 'head', (-2.5, -2.5, -4, 5, 5, 4), (0, 14.5, -1), tags={'face'})]
        for sx in (-1, 1):
            side = 'r' if sx > 0 else 'l'
            parts.append(P(f'ear{sx}', 'static', (-1, -3, -0.5, 2, 3, 1), (sx*1.8, -2.5, -2), rot=(0, 0, sx*0.2), parent='head', tags={'sig'}))
            parts.append(P(f'wing{sx}a', 'wing', (0 if sx > 0 else -8, 0, -2, 8, 0.5, 8), (sx*2.5, -2, 0), parent='body', tags={'wing_'+side}))
            parts.append(P(f'wing{sx}b', 'wing', (0 if sx > 0 else -7, 0, -1, 7, 0.5, 7), (sx*7.5 if sx > 0 else -8, 0, 0), parent=f'wing{sx}a' if False else 'body', tags={'wing_'+side}))
        cap(parts, 'body', 0, -3, 0, 3, 1, 'bk')
    return parts

def plant(p):
    parts = [P('body', 'body', (-3, -14, -3, 6, 14, 6), (0, 24, 0), tags={'stem'})]
    for i, (x, z, a) in enumerate([(-5, 0, -1.0), (5, 0, 1.0), (0, 5, 0), (0, -5, 0)]):
        parts.append(P(f'leg{i}', 'static', (-1.5, -1, -5, 3, 1, 9) if i < 2 else (-4, -1, -1.5, 8, 1, 3), (x*0.6, -1, z*0.6), rot=(0, 0, a*0.5), parent='body', tags={'leaf'}))
    parts.append(P('head', 'head', (-6, -7, -6, 12, 7, 12), (0, 10, 0), tags={'cap', 'face'}))
    parts.append(P('jaw', 'jaw', (-5, 0, -5, 10, 3, 10), (0, 0, 0), parent='head', tags={'dark', 'maw'}))
    for i, (x, z) in enumerate([(-4, -5), (0, -5), (4, -5), (-4, 5), (0, 5), (4, 5)]):
        parts.append(P(f'tooth{i}', 'static', (-0.7, -2, -0.7, 1.4, 2, 1.4), (x, 0, z), parent='jaw', tags={'tusk'}))
    for sx in (-1, 1):
        parts.append(P(f'tentacle{sx}', 'static', (-0.7, -9, -0.7, 1.4, 9, 1.4), (sx*5, -7, 0), rot=(0, 0, sx*0.5), parent='head', tags={'glow'}))
    return parts

PLANS = dict(quad=quad, biped=biped, spider=spider, insect=insect, seg=seg, turtle=turtle, snail=snail, frog=frog, fly=fly, plant=plant)

# ---------------------------------------------------------------- species data
# cat: peaceful | neutral | hostile | boss
def S(id, name, cat, plan, hb, hp, spd, dmg, pal, **kw):
    d = dict(id=id, name=name, cat=cat, plan=plan, hb=hb, hp=hp, spd=spd, dmg=dmg, pal=pal)
    d.update(kw); return d

PAL = lambda main, accent, dark, glow, cap='#c8202e', spot='#f4eadb': dict(main=main, accent=accent, dark=dark, glow=glow, cap=cap, spot=spot)

BASE = [
 S('ciervo_micotico','Ciervo Micótico','peaceful','quad',(0.9,1.6),22,0.25,0,PAL('#7a4fb0','#e8dcff','#3d2466','#41f2ff','#a23cc2','#f1e6ff'),
   p=dict(L=14,W=7,H=8,leg=12,lw=3,hs=6,neck=5,feats=['antlers','ears','tail'],ear=3,tail=(3,3),caps=[(-1,-1,3),(1.5,3,2)]),
   tame=True,food=['minecraft:brown_mushroom','minecraft:glow_berries'],drops=[('reino_micotico:carne_fungosa',1,2),('minecraft:leather',0,2)],biomes=[('bosque_violeta',12,2,4),('jardines_bioluminiscentes',6,1,3),('praderas_micelio',8,2,3)],climb=False,ride=True),
 S('conejo_esporas','Conejo de Esporas','peaceful','quad',(0.55,0.55),6,0.3,0,PAL('#e6dff2','#ffffff','#9c8bb8','#6bf3ff','#ff6ed0','#ffffff'),
   p=dict(L=7,W=4,H=4,leg=4,lw=2,hs=4,feats=['ears','tail'],ear=6,tail=(2,2),caps=[(0,0,2)]),
   tame=True,food=['minecraft:carrot','minecraft:brown_mushroom'],drops=[('reino_micotico:esencia_esporas',0,1),('minecraft:rabbit_hide',0,1)],biomes=[('praderas_micelio',14,2,5),('bosque_violeta',10,2,4),('jardines_bioluminiscentes',8,2,4)],flee=True),
 S('tortuga_fungosa','Tortuga Fungosa','peaceful','turtle',(0.95,0.6),14,0.12,0,PAL('#5f7a3a','#b6c97a','#2d3d1a','#8dffb0','#d94a4a','#f6efdc'),
   p={},egg=True,food=['minecraft:red_mushroom','minecraft:kelp'],drops=[('reino_micotico:fragmento_fungoso',0,1)],biomes=[('praderas_micelio',6,1,3),('pantano_esporifero',8,1,3)]),
 S('luciernaga_gigante','Luciérnaga Gigante','peaceful','fly',(0.6,0.6),6,0.2,0,PAL('#3a3340','#ffe36a','#1d1a22','#fff27a'),
   p=dict(kind='firefly'),fly=True,egg=True,food=['minecraft:glow_berries','minecraft:sugar'],drops=[('reino_micotico:esencia_esporas',1,2)],biomes=[('jardines_bioluminiscentes',14,3,6)],flee=True),
 S('caracol_cristal','Caracol de Cristal','peaceful','snail',(0.6,0.75),10,0.06,0,PAL('#8a9a7a','#d8e6c0','#4a5a3a','#d27bff','#b57cf0'),
   p={},egg=True,climb=True,food=['minecraft:brown_mushroom','minecraft:kelp'],drops=[('reino_micotico:cristal_micotico',0,1)],biomes=[('praderas_micelio',8,1,3),('jardines_bioluminiscentes',8,1,3),('pantano_esporifero',6,1,3),('cavernas_micoticas',6,1,2)]),
 S('zorro_micelio','Zorro de Micelio','peaceful','quad',(0.65,0.7),12,0.3,2,PAL('#d9742c','#f8eadf','#6b3a14','#ff7ad0','#e24fa0','#fff0f8'),
   p=dict(L=10,W=4.5,H=4.5,leg=6,lw=2,hs=5,feats=['ears','tail','snout','hat'],ear=4,ear_sig=True,tail=(7,4),tail_sig=True,hat=4),
   tame=True,food=['minecraft:sweet_berries','minecraft:brown_mushroom'],drops=[('reino_micotico:esencia_esporas',0,1)],biomes=[('bosque_carmesi',8,1,3),('bosque_violeta',6,1,3)],flee=True),
 S('rana_bioluminiscente','Rana Bioluminiscente','peaceful','frog',(0.6,0.55),8,0.22,0,PAL('#2a8fa8','#bff8ff','#12526a','#5dffd6'),
   p={},egg=True,tame=True,food=['minecraft:slime_ball','minecraft:glow_berries'],drops=[('reino_micotico:esencia_esporas',0,1)],biomes=[('pantano_esporifero',14,2,5),('jardines_bioluminiscentes',8,2,4)],flee=True),
 S('mariposa_esporifera','Mariposa Esporífera','peaceful','fly',(0.5,0.5),4,0.2,0,PAL('#b04fd8','#ffd0f5','#5c2a78','#7cf9ff'),
   p=dict(kind='butterfly'),fly=True,egg=True,food=['minecraft:sugar','minecraft:glow_berries'],drops=[('reino_micotico:esencia_esporas',0,1)],biomes=[('jardines_bioluminiscentes',12,3,6),('bosque_violeta',8,2,4),('bosque_carmesi',6,2,4)],flee=True),
 # neutrales
 S('golem_hongos','Gólem de Hongos','neutral','biped',(1.4,2.7),60,0.22,9,PAL('#6d6a78','#a29db0','#3a3745','#ff9a3c','#c8202e','#f4eadb'),
   p=dict(m=1.5,hs=7,armw=1.4,armh=11,feats=['hat','shoulders','cracks']),kb=0.8,drops=[('reino_micotico:fragmento_fungoso',1,3),('reino_micotico:piedra_viviente',0,1)],biomes=[('montanas_fungales',6,1,1)]),
 S('jabali_micotico','Jabalí Micótico','neutral','quad',(1.0,1.0),20,0.25,4,PAL('#6b4a3c','#c9a98c','#33211a','#ffb84a','#b82f36','#f6e7d4'),
   p=dict(L=14,W=8,H=9,leg=6,lw=3,hs=7,feats=['snout','tusks','ears','spikes'],ear=2,snout=3,caps=[(-1.5,-2,3),(1.5,3,3)]),
   tame=True,food=['minecraft:brown_mushroom','minecraft:red_mushroom'],drops=[('reino_micotico:carne_fungosa',1,3),('minecraft:leather',0,1)],biomes=[('bosque_carmesi',10,2,4),('praderas_micelio',6,2,3),('montanas_fungales',8,2,3)]),
 S('escarabajo_colosal','Escarabajo Colosal','neutral','insect',(1.4,1.0),30,0.2,5,PAL('#3a2f6a','#6b5fb0','#1a1438','#41f2ff','#d94a4a','#f6efdc'),
   p=dict(s=1.4,feats=['horn','antenna','caps','wingcase'],caps=[(-2,0,3),(2,3,2)]),egg=True,tame=True,food=['minecraft:red_mushroom','minecraft:sugar'],drops=[('reino_micotico:fragmento_fungoso',1,2)],biomes=[('bosque_carmesi',6,1,2),('praderas_micelio',5,1,2),('cavernas_micoticas',8,1,2)]),
 S('ciempies_fungoso','Ciempiés Fungoso','neutral','seg',(0.7,0.6),16,0.24,3,PAL('#8a4a2a','#d9a26a','#3d1d0e','#9dff6a','#c8202e','#f6efdc'),
   p=dict(n=8,w=6,h=5,ln=5,feats=['legs','antenna','caps']),egg=True,climb=True,food=['minecraft:red_mushroom','minecraft:spider_eye'],drops=[('reino_micotico:esencia_esporas',0,2)],biomes=[('pantano_esporifero',8,1,2),('cavernas_micoticas',10,1,3)]),
 S('guardian_micelio','Guardián de Micelio','neutral','biped',(0.9,2.5),50,0.23,7,PAL('#5a6a4a','#c9d9a8','#2a3a22','#41f2ff','#7c3fbf','#d9c8ff'),
   p=dict(m=1.1,hs=8,armh=14,feats=['hat','staff','shoulders']),kb=0.5,drops=[('reino_micotico:nucleo_micelio',0,1),('reino_micotico:fragmento_fungoso',1,2)],biomes=[('bosque_violeta',3,1,1),('jardines_bioluminiscentes',3,1,1)]),
 S('murcielago_esporas','Murciélago de Esporas','neutral','fly',(0.55,0.9),8,0.2,2,PAL('#4a3a6a','#a58fd0','#241a38','#d27bff','#7c3fbf','#f1e6ff'),
   p=dict(kind='bat'),fly=True,food=['minecraft:glow_berries','minecraft:spider_eye'],drops=[('reino_micotico:esencia_esporas',0,1)],biomes=[('cavernas_micoticas',12,2,5),('bosque_violeta',5,1,3),('montanas_fungales',6,2,4)]),
 S('oso_fungoso','Oso Fungoso','neutral','quad',(1.5,1.6),45,0.22,8,PAL('#5a3a2a','#a37a58','#2c1a10','#ff7ad0','#a23cc2','#f6e7ff'),
   p=dict(L=18,W=11,H=11,leg=9,lw=4,hs=8,feats=['snout','ears','tail'],ear=2,snout=3,tail=(2,3),caps=[(-2,-3,4),(3,2,3),(-3,5,3)]),
   tame=True,food=['minecraft:sweet_berries','minecraft:honey_bottle'],drops=[('reino_micotico:carne_fungosa',2,4),('minecraft:leather',1,2)],biomes=[('bosque_carmesi',4,1,2),('montanas_fungales',8,1,2)],ride=True),
 # hostiles
 S('devorador_micelio','Devorador de Micelio','hostile','quad',(1.2,1.2),30,0.3,6,PAL('#4a2438','#9a3a5a','#1e0e18','#ff4a4a','#a2233a','#f4eadb'),
   p=dict(L=15,W=8,H=8,leg=8,lw=3,hs=8,feats=['jaw','ears','tail','caps'],ear=3,tail=(5,3),caps=[(0,-2,4)]),drops=[('reino_micotico:esencia_esporas',1,2),('minecraft:bone',0,2)],biomes=[('bosque_carmesi',10,2,3),('montanas_fungales',8,2,3),('corazon_podrido',12,2,4),('cavernas_micoticas',6,2,3)],ambush=True,ability='bleed'),
 S('arana_esporifera','Araña Esporífera','hostile','spider',(1.3,0.9),22,0.3,4,PAL('#3a2a4a','#7a5a9a','#1a1224','#e7ff4a','#c8202e','#f4eadb'),
   p=dict(s=1.0,feats=['backcap'],bc=6),climb=True,egg=True,food=['minecraft:spider_eye','minecraft:rotten_flesh'],drops=[('minecraft:string',1,2),('reino_micotico:esencia_esporas',0,2)],biomes=[('bosque_carmesi',15,1,3),('bosque_violeta',10,1,3),('pantano_esporifero',8,1,3),('cavernas_micoticas',12,1,3),('corazon_podrido',8,1,3)],ambush=True,ability='poison'),
 S('reptador_micotico','Reptador Micótico','hostile','insect',(0.9,0.5),14,0.34,3,PAL('#5a6a2a','#9aba4a','#2a3412','#ff9a3c','#7a8a2a','#e8f0c0'),
   p=dict(s=0.9,feats=['antenna']),climb=True,egg=True,food=['minecraft:rotten_flesh','minecraft:spider_eye'],drops=[('reino_micotico:fragmento_fungoso',0,1)],biomes=[('bosque_violeta',6,1,3),('praderas_micelio',6,1,3),('pantano_esporifero',10,2,4),('corazon_podrido',8,2,4)],ambush=True),
 S('planta_carnivora','Planta Carnívora Gigante','hostile','plant',(1.4,2.2),40,0.0,8,PAL('#3d7a2a','#9ad84a','#1a3a12','#ff4a8a','#c8202e','#f6efdc'),
   p={},drops=[('reino_micotico:esencia_esporas',1,3),('minecraft:slime_ball',0,2)],biomes=[('pantano_esporifero',10,1,2),('corazon_podrido',8,1,2)],ambush=True,ability='grab',stationary=True),
 S('gusano_esporas','Gusano de Esporas','hostile','seg',(0.85,0.8),20,0.22,4,PAL('#b07a6a','#e8c0a8','#5a3a30','#b6ff4a','#c8202e','#f4eadb'),
   p=dict(n=6,w=8,h=7,ln=6,feats=['jaws','caps'],taper=True),egg=True,food=['minecraft:rotten_flesh','minecraft:spider_eye'],drops=[('reino_micotico:esencia_esporas',1,2)],biomes=[('pantano_esporifero',14,1,3),('praderas_micelio',8,1,2),('corazon_podrido',10,1,3),('cavernas_micoticas',10,1,3)],ambush=True,ability='spores'),
 S('cazador_hongos','Cazador de Hongos','hostile','biped',(0.7,2.0),26,0.3,5,PAL('#6a3a2a','#b87a5a','#2a1610','#ff4a4a','#8a2a3a','#f4eadb'),
   p=dict(m=1.0,hs=8,armh=12,feats=['hat','claws']),drops=[('reino_micotico:esencia_esporas',0,2),('minecraft:arrow',0,3),('reino_micotico:mineral_carmesi',0,1)],biomes=[('bosque_carmesi',25,1,2),('corazon_podrido',12,1,3)],ambush=True),
 S('bestia_podrida','Bestia Podrida','hostile','quad',(1.8,1.9),70,0.26,10,PAL('#4a5a3a','#8a9a5a','#1e2a14','#b6ff4a','#5a6a2a','#d9d0a0'),
   p=dict(L=20,W=13,H=13,leg=11,lw=4,hs=10,feats=['jaw','horns','spikes','tail'],tail=(6,4),caps=[(-3,-4,4),(3,3,5)]),kb=0.4,drops=[('reino_micotico:fragmento_fungoso',1,3),('reino_micotico:corazon_esporifero',0,1),('minecraft:rotten_flesh',1,3)],biomes=[('corazon_podrido',15,1,2),('montanas_fungales',4,1,1)],ambush=True,ability='slam'),
 S('coloso_fungico','Coloso Fúngico','hostile','biped',(2.6,5.0),180,0.22,16,PAL('#5a4a6a','#8a7a9a','#2a2234','#ff4a8a','#a2233a','#f4eadb'),
   p=dict(m=2.0,hs=7,armw=1.4,armh=11,feats=['hat','shoulders','backcap','cracks']),kb=0.9,drops=[('reino_micotico:corazon_esporifero',1,2),('reino_micotico:nucleo_micelio',0,1),('reino_micotico:piedra_viviente',1,3)],biomes=[('montanas_fungales',1,1,1),('corazon_podrido',3,1,1)],ability='slam'),
 S('reina_esporas','Reina de las Esporas','hostile','spider',(2.2,1.8),120,0.28,8,PAL('#5a1a4a','#c24a9a','#240a1e','#ff7ad0','#e24fa0','#fff0f8'),
   p=dict(s=1.8,feats=['crown','cap_head'],hc=6),climb=True,egg=True,kb=0.5,drops=[('reino_micotico:corazon_esporifero',1,2),('reino_micotico:esencia_esporas',3,6)],biomes=[('corazon_podrido',2,1,1)],ambush=True,ability='summon'),
 S('rey_micotico','El Rey Micótico','boss','spider',(4.6,3.4),600,0.27,14,PAL('#4a1a3a','#8a2a5a','#1e0a18','#c04aff','#c8202e','#f4eadb'),
   p=dict(s=3.2,feats=['crown','cap_head'],hc=6),kb=1.0,boss=True,drops=[('reino_micotico:corazon_esporifero',4,8),('reino_micotico:nucleo_micelio',2,4)]),
]

# --------------------------------------------------------------- hybrids
# (id, nombre, padre A (cuerpo), padre B (rasgos), paleta override)
HYB = [
 ('cervizorro_micotico','Cervizorro Micótico','ciervo_micotico','zorro_micelio',PAL('#d9742c','#f8eadf','#6b3a14','#41f2ff','#e24fa0','#fff0f8')),
 ('ranortuga_luminosa','Ranortuga Luminosa','rana_bioluminiscente','tortuga_fungosa',PAL('#2a8f7a','#bff8d0','#12523a','#5dffd6','#d94a4a','#f6efdc')),
 ('escaraciempies','Escaraciempiés','escarabajo_colosal','ciempies_fungoso',PAL('#5a3a5a','#d9a26a','#2a1a2a','#9dff6a','#c8202e','#f6efdc')),
 ('luciconejo','Luciconejo','conejo_esporas','luciernaga_gigante',PAL('#eef0f6','#ffffff','#a8b0c8','#6bffd8','#7cf9ff','#ffffff')),
 ('osojabali_fungoso','Osojabalí Fungoso','oso_fungoso','jabali_micotico',PAL('#5a3a3c','#b88a6c','#2c1a1a','#ffb84a','#b82f36','#f6e7d4')),
 ('luminariposa','Luminariposa','mariposa_esporifera','luciernaga_gigante',PAL('#d8a04f','#fff0b0','#6a4a1a','#fff27a','#ff9a3c','#fff6d8')),
 ('murcimariposa','Murcimariposa','murcielago_esporas','mariposa_esporifera',PAL('#7a3a9a','#e0b0f0','#3a1a4a','#7cf9ff','#b04fd8','#f1e6ff')),
 ('caracoltuga_cristal','Caracoltuga de Cristal','caracol_cristal','tortuga_fungosa',PAL('#7a9a6a','#d8f0c0','#3a5a2a','#d27bff','#b57cf0','#f6efdc')),
 ('ciervojabali','Ciervojabalí','ciervo_micotico','jabali_micotico',PAL('#6a4a8a','#d8c8e8','#33214a','#41f2ff','#a23cc2','#f1e6ff')),
 ('zorroso_fungoso','Zorroso Fungoso','zorro_micelio','oso_fungoso',PAL('#b8602c','#f0d8c0','#4a2a14','#ff7ad0','#e24fa0','#fff0f8')),
 ('gusaciempies','Gusaciempiés','gusano_esporas','ciempies_fungoso',PAL('#a0603a','#e0b088','#4a2a1a','#b6ff4a','#c8202e','#f4eadb')),
 ('reptaarana','Reptaraña','arana_esporifera','reptador_micotico',PAL('#4a4a2a','#9aba4a','#1e2412','#e7ff4a','#7a8a2a','#e8f0c0')),
 ('devorabestia','Devorabestia','devorador_micelio','bestia_podrida',PAL('#4a3a34','#9a6a5a','#1e1612','#ff4a4a','#a2233a','#d9d0a0')),
]

def blend_params(a, b, key):
    return a['p']

def build_species():
    sp = {s['id']: s for s in BASE}
    allsp = list(BASE)
    for hid, hname, ida, idb, pal in HYB:
        a, b = sp[ida], sp[idb]
        h = dict(id=hid, name=hname, cat=('hostile' if 'hostile' in (a['cat'], b['cat']) else 'neutral' if 'neutral' in (a['cat'], b['cat']) else 'peaceful'),
                 plan=a['plan'], hb=(round((a['hb'][0]+b['hb'][0])/2, 2), round((a['hb'][1]+b['hb'][1])/2, 2)),
                 hp=round((a['hp']+b['hp'])/2*1.1), spd=round((a['spd']+b['spd'])/2, 3), dmg=round((a['dmg']+b['dmg'])/2),
                 pal=pal, p=dict(a['p']), hybrid=True, parents=(ida, idb), egg=(a.get('egg', False) and b.get('egg', False)),
                 fly=a.get('fly', False) or b.get('fly', False), climb=a.get('climb', False) or b.get('climb', False),
                 tame=a.get('tame', False) and b.get('tame', False), food=list(dict.fromkeys(a.get('food', []) + b.get('food', []))),
                 drops=list(dict.fromkeys(a.get('drops', [])[:1] + b.get('drops', [])[:1])), biomes=[], flee=a.get('flee') or b.get('flee'),
                 ambush=a.get('ambush') or b.get('ambush'), ability=a.get('ability') or b.get('ability'), kb=max(a.get('kb', 0), b.get('kb', 0)),
                 stationary=False)
        allsp.append(h); sp[hid] = h
    return allsp, sp

def hybrid_parts(h, sp):
    """modelo hibrido: cuerpo de A + rasgos distintivos (sig) de B, proporciones mezcladas."""
    a, b = sp[h['parents'][0]], sp[h['parents'][1]]
    pa = PLANS[a['plan']](a['p']) if a['plan'] != 'fly' else fly(a['p'])
    pb = PLANS[b['plan']](b['p'])
    parts = [dict(x, tags=set(x['tags'])) for x in pa]
    names = {x['name'] for x in parts}
    sigb = [x for x in pb if 'sig' in x['tags'] or 'glow' in x['tags']]
    # los rasgos de B se anclan a partes equivalentes de A (cabeza/cuerpo) y se renombran
    anchor = 'body' if 'body' in names else parts[0]['name']
    ref = {'head', anchor}
    pnames = {x['name'] for x in pb}
    for x in sigb:
        y = dict(x, tags=set(x['tags']) | {'sig2'}); y['name'] = 'b_' + x['name']
        par = x['parent']
        if par is None or par not in pnames:
            y['parent'] = anchor
            bx = list(y['pivot']); bx[0] *= 0.5; y['pivot'] = tuple(bx)
        else:
            y['parent'] = par if par in names and par in ref else ('b_' + par if par in {s['name'] for s in sigb} else ('head' if par == 'head' else anchor))
        if y['role'] in ('wing',) and a['plan'] != 'fly' and b['plan'] != 'fly':
            continue
        if y['role'] == 'tail' and any(q['role'] == 'tail' for q in parts):
            continue
        parts.append(y)
    # tambien algo de la forma de B: cap de B sobre el cuerpo
    cap(parts, anchor, 0, -(2 + 0.0), 0, 3, 2, 'hyb', sig=True)
    return parts
