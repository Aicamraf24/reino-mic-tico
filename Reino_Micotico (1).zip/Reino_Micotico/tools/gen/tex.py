import math, random
from PIL import Image, ImageDraw
from util import *

def net_size(box):
    x, y, z, w, h, d = box
    w, h, d = max(1, math.ceil(w)), max(1, math.ceil(h)), max(1, math.ceil(d))
    return w, h, d, 2*d + 2*w, d + h

def pack(parts):
    """Empaqueta las redes UV de cada caja; devuelve (tam, asigna u,v a cada parte)."""
    items = []
    for p in parts:
        w, h, d, nw, nh = net_size(p['box'])
        items.append((nh, nw, p, (w, h, d)))
    for size in (64, 128, 256, 512):
        order = sorted(items, key=lambda t: (-t[0], -t[1]))
        x = y = rowh = 0; ok = True; pos = []
        for nh, nw, p, dims in order:
            if x + nw > size: x = 0; y += rowh; rowh = 0
            if y + nh > size: ok = False; break
            pos.append((p, x, y, dims)); x += nw; rowh = max(rowh, nh)
        if ok:
            for p, u, v, dims in pos:
                p['u'], p['v'], p['dims'] = u, v, dims
            return size
    raise RuntimeError('no cabe')

def jitter(rng, c, amt=0.07):
    f = 1 + rng.uniform(-amt, amt)
    return shade(c, f)

def part_colors(pal, part, baby=False):
    t = part['tags']
    main, acc, dark, glow, capc, spot = (hexrgb(pal[k]) for k in ('main', 'accent', 'dark', 'glow', 'cap', 'spot'))
    if baby:
        main = mix(main, (255, 240, 235), 0.28); acc = mix(acc, (255, 255, 255), 0.3)
    if 'cap' in t: return capc
    if 'stem' in t: return mix(spot, main, 0.15)
    if 'glow' in t: return glow
    if 'shell' in t: return dark if 'sac' not in t else glow
    if 'sac' in t: return glow
    if 'tusk' in t: return (236, 228, 205)
    if 'dark' in t: return dark
    if 'belly' in t: return acc
    if 'leaf' in t: return mix(main, acc, 0.4)
    if 'leg' in t: return mix(main, dark, 0.35)
    if 'wingpat' in t or 'wing_l' in t or 'wing_r' in t: return mix(main, acc, 0.35)
    if 'eye' in t: return acc
    if 'snout' in t: return acc
    return main

def paint_face(img, rect, col, rng, light=1.0):
    x0, y0, w, h = rect
    for xx in range(x0, x0 + w):
        for yy in range(y0, y0 + h):
            img.putpixel((xx, yy), jitter(rng, shade(col, light)))

def paint_part(img, part, pal, rng, hostile=False, baby=False, variant=0):
    u, v = part['u'], part['v']; w, h, d = part['dims']
    base = part_colors(pal, part, baby)
    acc = hexrgb(pal['accent']); spot = hexrgb(pal['spot']); glow = hexrgb(pal['glow']); dark = hexrgb(pal['dark'])
    faces = {
        'top': (u + d, v, w, d, 1.12), 'bottom': (u + d + w, v, w, d, 0.78),
        'left': (u, v + d, d, h, 0.92), 'front': (u + d, v + d, w, h, 1.0),
        'right': (u + d + w, v + d, d, h, 0.88), 'back': (u + 2*d + w, v + d, w, h, 0.84)}
    for nm, (fx, fy, fw, fh, lt) in faces.items():
        paint_face(img, (fx, fy, fw, fh), base, rng, lt)
    t = part['tags']
    # moteado / manchas
    if 'cap' in t and w >= 3:
        for nm in ('top', 'front', 'left', 'right', 'back'):
            fx, fy, fw, fh, _ = faces[nm]
            for _ in range(max(1, fw*fh//7)):
                x = rng.randrange(fx, fx + fw); y = rng.randrange(fy, fy + fh)
                img.putpixel((x, y), spot)
    elif 'stem' in t or 'sac' in t or 'shell' in t:
        for nm in ('front', 'left', 'right', 'back', 'top'):
            fx, fy, fw, fh, _ = faces[nm]
            for _ in range(max(1, fw*fh//9)):
                x = rng.randrange(fx, fx + fw); y = rng.randrange(fy, fy + fh)
                c = glow if ('sac' in t or 'glow' in t) else shade(base, 1.25 if rng.random() < .5 else .7)
                img.putpixel((x, y), c)
    elif 'wing_l' in t or 'wing_r' in t or 'wingpat' in t:
        fx, fy, fw, fh, _ = faces['top']
        for x in range(fx, fx + fw):
            for y in range(fy, fy + fh):
                if (x + y) % 3 == 0: img.putpixel((x, y), glow)
                elif (x*y) % 5 == 0: img.putpixel((x, y), shade(acc, 0.9))
    else:
        # manchas de pelaje / pintas del acento
        for nm in ('top', 'front', 'left', 'right', 'back'):
            fx, fy, fw, fh, _ = faces[nm]
            n = max(0, fw*fh//14)
            for _ in range(n):
                x = rng.randrange(fx, fx + fw); y = rng.randrange(fy, fy + fh)
                img.putpixel((x, y), shade(acc, 0.95) if variant % 2 == 0 else shade(dark, 1.4))
        if 'belly' in t or part['role'] == 'body':
            fx, fy, fw, fh, _ = faces['bottom']; paint_face(img, (fx, fy, fw, fh), acc, rng, 1.0)
    # cara
    if 'face' in t:
        fx, fy, fw, fh, _ = faces['front']
        ey = fy + max(0, int(fh*0.32)); big = 2 if (baby and fw >= 4) else 1
        ex = max(1, fw//4)
        eye = (255, 70, 60) if hostile else (20, 16, 28)
        for sx in (fx + ex - 0, fx + fw - ex - big):
            for dx in range(big):
                for dy in range(big):
                    if fx <= sx + dx < fx + fw and fy <= ey + dy < fy + fh:
                        img.putpixel((sx + dx, ey + dy), eye)
            if fw >= 5 and fx <= sx < fx + fw:
                img.putpixel((sx, max(fy, ey - 1)), glow if hostile else (250, 250, 250))
        if fh >= 4 and fw >= 3:
            my = fy + fh - 2
            for x in range(fx + fw//3, fx + fw - fw//3):
                img.putpixel((x, my), shade(dark, 0.6))
    if 'eye' in t:
        fx, fy, fw, fh, _ = faces['front']
        img.putpixel((fx + fw//2, fy + fh//2), (10, 10, 14))
    if 'maw' in t:
        for nm in ('top',):
            fx, fy, fw, fh, _ = faces[nm]; paint_face(img, (fx, fy, fw, fh), (200, 50, 80), rng, 1.0)

def species_texture(parts, size, pal, hostile, baby, seed, variant=0):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    rng = random.Random(seed)
    for p in parts:
        paint_part(img, p, pal, rng, hostile, baby, variant)
    return img

def egg_texture(pal, seed, spotted=True):
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0)); rng = random.Random(seed)
    main = mix(hexrgb(pal['accent']), hexrgb(pal['main']), 0.45); spot = hexrgb(pal['glow']) if spotted else hexrgb(pal['dark'])
    for x in range(16):
        for y in range(16):
            img.putpixel((x, y), jitter(rng, main, 0.06))
    for _ in range(14):
        img.putpixel((rng.randrange(16), rng.randrange(16)), spot)
    for _ in range(10):
        img.putpixel((rng.randrange(16), rng.randrange(16)), hexrgb(pal['cap']))
    return img
