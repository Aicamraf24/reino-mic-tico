import os, json, gzip, struct, random, math
from PIL import Image, ImageDraw

OUT = '/home/claude/out/Reino_Micotico'
MOD = 'reino_micotico'
PKG = 'com.reinomicotico'

def path(*p):
    return os.path.join(OUT, *p)

def write(rel, text):
    fp = path(rel)
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, 'w', encoding='utf-8', newline='\n') as f:
        f.write(text)

def wjson(rel, obj):
    write(rel, json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def save_png(img, rel):
    fp = path(rel)
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    img.save(fp)

def hexrgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def mix(a, b, t):
    a = hexrgb(a) if isinstance(a, str) else a
    b = hexrgb(b) if isinstance(b, str) else b
    return tuple(int(a[i]*(1-t)+b[i]*t) for i in range(3))

def shade(c, f):
    c = hexrgb(c) if isinstance(c, str) else c
    return tuple(max(0, min(255, int(v*f))) for v in c)

# ---------------- NBT writer ----------------
def _s(v):
    b = v.encode('utf-8'); return struct.pack('>H', len(b)) + b

def _payload(t, v):
    if t == 'byte': return struct.pack('>b', v)
    if t == 'short': return struct.pack('>h', v)
    if t == 'int': return struct.pack('>i', v)
    if t == 'long': return struct.pack('>q', v)
    if t == 'float': return struct.pack('>f', v)
    if t == 'double': return struct.pack('>d', v)
    if t == 'str': return _s(v)
    if t == 'list':
        et, items = v
        out = struct.pack('>b', ID[et]) + struct.pack('>i', len(items))
        for i in items: out += _payload(et, i)
        return out
    if t == 'compound':
        out = b''
        for k, (kt, kv) in v.items():
            out += struct.pack('>b', ID[kt]) + _s(k) + _payload(kt, kv)
        return out + b'\x00'
    raise ValueError(t)

ID = {'byte':1,'short':2,'int':3,'long':4,'float':5,'double':6,'str':8,'list':9,'compound':10}

def nbt_gz(compound):
    data = struct.pack('>b', 10) + _s('') + _payload('compound', compound)
    return gzip.compress(data, 9, mtime=0)

DATA_VERSION = 4671  # asumido (1.21.11); el juego aplica DataFixer si es menor

class Vox:
    """Constructor de estructuras: cuadricula de bloques -> NBT de plantilla de estructura."""
    def __init__(self, sx, sy, sz):
        self.size = (sx, sy, sz); self.b = {}; self.entities = []
    def set(self, x, y, z, name, props=None, nbt=None):
        if 0 <= x < self.size[0] and 0 <= y < self.size[1] and 0 <= z < self.size[2]:
            self.b[(x, y, z)] = (name, tuple(sorted((props or {}).items())), nbt)
    def get(self, x, y, z): return self.b.get((x, y, z))
    def fill(self, x0, y0, z0, x1, y1, z1, name, props=None):
        for x in range(min(x0, x1), max(x0, x1)+1):
            for y in range(min(y0, y1), max(y0, y1)+1):
                for z in range(min(z0, z1), max(z0, z1)+1):
                    self.set(x, y, z, name, props)
    def hollow(self, x0, y0, z0, x1, y1, z1, name, props=None):
        for x in range(x0, x1+1):
            for y in range(y0, y1+1):
                for z in range(z0, z1+1):
                    if x in (x0, x1) or y in (y0, y1) or z in (z0, z1):
                        self.set(x, y, z, name, props)
    def cyl(self, cx, cz, r, y0, y1, name, props=None, hollow=False):
        for y in range(y0, y1+1):
            for x in range(cx-r, cx+r+1):
                for z in range(cz-r, cz+r+1):
                    d = math.hypot(x-cx, z-cz)
                    if d <= r+0.3 and (not hollow or d >= r-0.9):
                        self.set(x, y, z, name, props)
    def dome(self, cx, cy, cz, r, h, name, props=None, thick=True):
        for y in range(0, h+1):
            rr = r*math.sqrt(max(0.0, 1-(y/(h+0.5))**2))
            for x in range(cx-r, cx+r+1):
                for z in range(cz-r, cz+r+1):
                    d = math.hypot(x-cx, z-cz)
                    if d <= rr+0.2 and (thick or d >= rr-1.1 or y == h):
                        self.set(x, cy+y, z, name, props)
    def chest(self, x, y, z, loot, facing='south'):
        self.set(x, y, z, 'minecraft:chest', {'facing': facing},
                 {'id': ('str', 'minecraft:chest'), 'LootTable': ('str', f'{MOD}:chests/{loot}')})
    def entity(self, x, y, z, eid):
        self.entities.append((x, y, z, eid))
    def to_nbt(self):
        palette = []; idx = {}
        blocks = []
        for (x, y, z), (name, props, nbt) in sorted(self.b.items()):
            key = (name, props)
            if key not in idx:
                idx[key] = len(palette); palette.append(key)
            e = {'pos': ('list', ('int', [x, y, z])), 'state': ('int', idx[key])}
            if nbt: e['nbt'] = ('compound', nbt)
            blocks.append(e)
        pal = []
        for name, props in palette:
            c = {'Name': ('str', name)}
            if props: c['Properties'] = ('compound', {k: ('str', str(v)) for k, v in props})
            pal.append(c)
        ents = []
        for x, y, z, eid in self.entities:
            ents.append({'pos': ('list', ('double', [x+0.5, float(y), z+0.5])),
                         'blockPos': ('list', ('int', [x, y, z])),
                         'nbt': ('compound', {'id': ('str', eid), 'PersistenceRequired': ('byte', 1)})})
        root = {'DataVersion': ('int', DATA_VERSION),
                'size': ('list', ('int', list(self.size))),
                'palette': ('list', ('compound', pal)),
                'blocks': ('list', ('compound', blocks)),
                'entities': ('list', ('compound', ents))}
        return nbt_gz(root)
