# Reino Micótico — mod de Fabric para Minecraft Java 26.1.2

Dimensión fantástica de hongos gigantes: 8 biomas, 25 criaturas (+13 híbridos), reproducción entre especies, huevos, domesticación,
jefe final **El Rey Micótico**, 40+ bloques, 8 recursos, 5 armaduras, 6 armas/herramientas, 13 estructuras y portal.

> **Estado honesto (léelo primero).** Este proyecto fue **generado y validado estáticamente**, pero **no se ha compilado ni probado en el juego**:
> el entorno donde se generó no tiene acceso a Internet ni a los JAR de Minecraft/Fabric. Ver la sección *Verificación* para saber qué está
> comprobado y qué no. Es muy probable que la primera compilación muestre algunos errores de API (Minecraft 26.1.x cambió muchas firmas);
> la lista de puntos de riesgo está más abajo y cada uno se corrige en 1–3 líneas.

## Compilar

Requisitos: **JDK 25**. Gradle **9.4.1**. Loom `1.15.5`, Fabric Loader `0.19.2`, Fabric API `0.145.4+26.1.2` (ver `gradle.properties`).

- **GitHub Actions**: sube el proyecto; `.github/workflows/build.yml` compila con Gradle 9.4.1 (sin wrapper) y publica el `.jar` como artefacto.
- **Local**: el *Gradle Wrapper* no incluye `gradle-wrapper.jar` (binario que no se pudo descargar). Ejecuta una vez `gradle wrapper --gradle-version 9.4.1` y luego `./gradlew build`.
  El `.jar` queda en `build/libs/`.

## Uso en el juego

1. **Portal**: fabrica un *Altar del Portal Micótico* (receta: 6 Ladrillos de Micelio, 2 Cristales Micóticos, 1 Núcleo de Micelio) y colócalo.
   Clic derecho con un **Núcleo de Micelio** en la mano (se consume uno por viaje) → viajas al Reino Micótico en las mismas X/Z. Al llegar se genera un altar de regreso;
   usa otro Núcleo para volver al Overworld. Inventario y progreso se conservan.
2. **Núcleo de Micelio**: 2 Fragmentos Fungosos + 2 Esencias de Esporas + 1 Cristal Micótico (sin forma), o drop de Guardianes, Colosos y del jefe.
3. **Domesticar** (Ciervo, Conejo, Zorro, Rana, Jabalí, Oso, Escarabajo y sus híbridos): clic derecho con *Esencia de Esporas* (33 % por intento). Clic con la mano vacía: sentar/levantar. Siguen y defienden al dueño; el dueño se guarda en el mundo.
4. **Criar**: alimenta con la comida de cada especie (setas, bayas luminosas, etc.). Las especies ovíparas ponen un **Huevo Micótico** con diseño propio por especie; las demás paren.
5. **Jefe**: El Trono del Micelio aparece en el bioma Corazón Podrido. El Rey Micótico tiene 3 fases (raíces/esporas, invocaciones, aplastamiento), barra de jefe y no puede reproducirse.
6. Todo está en las pestañas creativas vanilla (Bloques, Naturaleza, Ingredientes, Combate, Huevos generadores…).

## Reproducción entre especies (regla general para todos los mods de criaturas)

Reglas 100 % por datos: `src/main/resources/data/reino_micotico/breeding.json` (copiado a `config/reino_micotico/breeding.json` en el primer arranque; **el archivo de config tiene prioridad**).

```json
"species": { "ciervo_micotico": { "partners": ["zorro_micelio", "jabali_micotico"], "cooldown": 6000 } },
"hybrids": [ { "parents": ["ciervo_micotico", "zorro_micelio"], "result": "cervizorro_micotico", "chance": 0.8 } ]
```
- Dos especies se aparean si cualquiera lista a la otra (o si son la misma especie y es reproducible). Sin “cruces absurdos”: lo que no esté listado no se cruza.
- Si hay regla de híbrido y sale la probabilidad → cría híbrida (**modelo, textura y nombre propios**, estadísticas = media de los padres ±10 %). Si no, la cría es de uno de los progenitores.
- Los híbridos pueden reproducirse (con sus padres, consigo mismos y con otros híbridos que compartan un progenitor).
- **Excluidos siempre**: el Rey Micótico (no es `Animal`) y las especies `breedable=false` (Gólem, Guardián, Planta Carnívora, Coloso, Reina).
- Límites: `maxPop` por especie (se cancela la cría si hay demasiadas en 48 bloques), ciclo de 5 min tras criar, y tope de aparición natural.
- Nuevos híbridos/especies: añade la entrada en `species.json` + `breeding.json`, su modelo en `assets/.../mico_models/<id>.json` y textura `textures/entity/<id>.png` (+ `_baby`).

### Híbridos incluidos (13)
Cervizorro Micótico · Ranortuga Luminosa · Escaraciempiés · Luciconejo · Osojabalí Fungoso · Luminariposa · Murcimariposa · Caracoltuga de Cristal · Ciervojabalí · Zorroso Fungoso · Gusaciempiés · Reptaraña · Devorabestia

## Biomas (8) y criaturas (25 + jefe)
Bosque Carmesí · Bosque Violeta · Praderas de Micelio · Pantano Esporífero · Montañas Fungales · Jardines Bioluminiscentes · Cavernas Micóticas · Corazón Podrido.
Terreno: usa el ruido del Overworld (`minecraft:overworld`) con biomas multi-ruido propios (montañas, valles, ríos, lagos, cuevas y cascadas vanilla con el color de agua de cada bioma).

Criaturas — pacíficas: Ciervo Micótico, Conejo de Esporas, Tortuga Fungosa, Luciérnaga Gigante, Caracol de Cristal, Zorro de Micelio, Rana Bioluminiscente, Mariposa Esporífera ·
neutrales: Gólem de Hongos, Jabalí Micótico, Escarabajo Colosal, Ciempiés Fungoso, Guardián de Micelio, Murciélago de Esporas, Oso Fungoso ·
hostiles: Devorador de Micelio, Araña Esporífera, Reptador Micótico, Planta Carnívora Gigante, Gusano de Esporas, Cazador de Hongos, Bestia Podrida, Coloso Fúngico, Reina de las Esporas · jefe: El Rey Micótico.

Cada especie tiene modelo 3D propio (cajas + UV, `mico_models/<id>.json`), textura adulta y de cría, IA y estadísticas en `species.json`, drops (`loot_table/entities`) y reglas de aparición (biomas).
Animaciones (modelo procedimental): caminar/correr (amplitud según velocidad), ataque, descanso, alimentación, aleteo en voladoras, mandíbula, segmentos ondulantes; daño y muerte usan las animaciones de Minecraft (parpadeo rojo y caída).

## Verificación (qué se hizo y qué NO)

| Nivel | Estado |
|---|---|
| Versiones (Minecraft 26.1.2, Loom 1.15.5, Loader 0.19.2, Fabric API 0.145.4+26.1.2, Gradle 9.4.1, Java 25) | Consultadas en docs.fabricmc.net / repos públicos de 26.1.2 |
| API de entidades/bloques/armaduras de 26.1.2 | Contrastada con la documentación oficial de Fabric (primera entidad, primer bloque, armaduras personalizadas); el resto de firmas se escribió de memoria |
| **Validación estática** | ✔ Todos los JSON parsean; ✔ referencias cruzadas (modelos↔texturas↔items↔blockstates↔loot↔recetas↔tags) comprobadas por script; ✔ NBT de estructuras se leen y re-escriben; ✔ sintaxis Java comprobada con `javac` (los errores de símbolos de Minecraft no son verificables sin los JAR) |
| **Compilación** | ✘ **No realizada** (sin acceso a Maven/Mojang) |
| **Prueba en el juego** | ✘ **No realizada**. Nada de lo anterior se afirma como funcionando en el juego |
| Sonidos | No se generó ningún archivo de audio ni referencia a sonidos propios (las armaduras usan el sonido vanilla de equipar) |

### Puntos de riesgo de API (si la compilación falla, empieza aquí)
1. `CreativeModeTabEvents` (paquete `net.fabricmc.fabric.api.creativetab.v1`) en `ModItems`.
2. `Item.Properties#spawnEgg`, `humanoidArmor`, `sword/axe/pickaxe`, `ToolMaterial(...)` y `ArmorMaterial(...)` (`ModItems`, `ModArmor`).
3. `ServerPlayer#teleportTo(ServerLevel, x, y, z, Set<Relative>, yRot, xRot, boolean)` en `Portal`.
4. `Entity#hurtServer`, `Item#postHurtEnemy`, `Item#use` (devuelve `InteractionResult`), `Block#useWithoutItem` y `Block#randomTick`.
5. `LivingEntityRenderer#scale(state, poseStack)`, `EntityModel#setupAnim(state)` y campos de `LivingEntityRenderState` (`walkAnimationPos`, `xRot`, `yRot`, `attackTime`, `isBaby`, `ageInTicks`).
6. `TemptGoal(..., Ingredient, ...)`, `BuiltInRegistries.ITEM.getValue(Identifier)` y `Identifier.parse/fromNamespaceAndPath`.
7. Datos: `DATA_VERSION` de las estructuras (`tools/gen/util.py`, asumido 4671); formatos JSON de bioma/dimensión (`effects`, `carvers`) y de `huge_*_mushroom`/`disk`; si Minecraft rechaza algún JSON, el log indica la ruta exacta.
8. Dimensión: usa el `dimension_type` vanilla `minecraft:overworld` a propósito (el formato de los tipos de dimensión cambió en 1.21.11/26.x y no pude verificarlo); por eso el ciclo día/noche es el del Overworld.

## Compatibilidad con tus otros mods
Todo vive bajo el espacio de nombres `reino_micotico` (bloques, items, entidades, dimensión, biomas, estructuras, recetas, loot). No hay mixins, no se modifica contenido vanilla ni de otros mods
(solo se **añaden** valores a etiquetas vanilla: `minecraft:dirt`, `mineable/*`, `needs_*_tool`). Sin dependencias de otros mods.
Integración opcional por datos: las criaturas están en las etiquetas `reino_micotico:micotic_creatures`, `micotic_hybrids` y `micotic_bosses` (úsalas en Cápsulas/Acechador/Reptilia, etc.);
las criaturas son `Mob` estándar, así que la cápsula puede capturarlas. Otros mods pueden añadir parejas/híbridos solo editando `breeding.json`.

## Optimización
IA por objetivos vanilla; habilidades cada 10 ticks y solo con objetivo; renderizado con un único modelo genérico por especie; topes de población (`maxPop`), de aparición natural y de crías;
huevos con *random tick*; partículas pocas y de bajo coste; sin tareas de fondo.

## Limitaciones conocidas (sin adornos)
- Los “ríos/lagos de esporas” son agua vanilla teñida por bioma (no hay fluidos nuevos). Las islas flotantes y cascadas se generan con estructuras/`spring_water`.
- Reina de las Esporas y Rey Micótico comparten el modelo de araña con coronas/sombreros; los modelos son de cajas simples (estética Minecraft), no esculpidos a mano.
- “Esconderse entre hongos” no está implementado como mecánica; las pequeñas huyen (`flee`).
- La suavidad de las animaciones y el balance (vida, daño, frecuencia) requieren pruebas reales.
- `en_US` reutiliza los nombres en español.

## Regenerar el proyecto
`tools/gen/` contiene el generador en Python (Pillow) que produjo texturas, modelos, JSON y estructuras. `python3 tools/gen/build_all.py` (ajusta `OUT` en `util.py`).
