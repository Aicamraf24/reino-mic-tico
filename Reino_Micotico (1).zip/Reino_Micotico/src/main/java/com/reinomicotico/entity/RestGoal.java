package com.reinomicotico.entity;

import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;

/** Descanso ocasional de criaturas no hostiles (anima la postura de reposo). */
public class RestGoal extends Goal {
	private final MicoCreature mob;
	private int ticks;

	public RestGoal(MicoCreature mob) {
		this.mob = mob;
		this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
	}

	@Override
	public boolean canUse() {
		return mob.getTarget() == null && mob.onGround() && !mob.isInLove() && !mob.isBaby()
				&& !mob.isTame() && mob.getRandom().nextInt(900) == 0;
	}

	@Override
	public boolean canContinueToUse() {
		return ticks > 0 && mob.getTarget() == null && !mob.isInLove();
	}

	@Override
	public void start() {
		ticks = 100 + mob.getRandom().nextInt(160);
		mob.getNavigation().stop();
		mob.setResting(true);
	}

	@Override
	public void tick() {
		ticks--;
	}

	@Override
	public void stop() {
		mob.setResting(false);
	}
}
