package com.reinomicotico.entity;

import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;

/** Quieta a la criatura domesticada cuando su dueno le ordena sentarse. */
public class SitOrderGoal extends Goal {
	private final MicoCreature mob;

	public SitOrderGoal(MicoCreature mob) {
		this.mob = mob;
		this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
	}

	@Override
	public boolean canUse() {
		return mob.isTame() && mob.isOrderedToSit() && !mob.isInWater();
	}

	@Override
	public boolean canContinueToUse() {
		return mob.isTame() && mob.isOrderedToSit();
	}

	@Override
	public void start() {
		mob.getNavigation().stop();
		mob.setTarget(null);
	}
}
