package com.reinomicotico;

import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModArmor {
	private ModArmor() {}

	public static final TagKey<Item> REPAIRS_TOOLS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_tools"));
	public static final ToolMaterial MICOTICO = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1200, 8.0f, 3.0f, 22, REPAIRS_TOOLS);

	public static final ResourceKey<EquipmentAsset> CARMESI_KEY = ResourceKey.create(EquipmentAssets.ROOT_ID, ReinoMicotico.id("carmesi"));
	public static final TagKey<Item> CARMESI_REPAIRS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_carmesi"));
	public static final ArmorMaterial CARMESI = new ArmorMaterial(22, Map.of(ArmorType.BOOTS, 3, ArmorType.LEGGINGS, 6, ArmorType.CHESTPLATE, 8, ArmorType.HELMET, 3, ArmorType.BODY, 10), 12, SoundEvents.ARMOR_EQUIP_IRON, 1.0f, 0.0f, CARMESI_REPAIRS, CARMESI_KEY);
	public static final ResourceKey<EquipmentAsset> VIOLETA_KEY = ResourceKey.create(EquipmentAssets.ROOT_ID, ReinoMicotico.id("violeta"));
	public static final TagKey<Item> VIOLETA_REPAIRS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_violeta"));
	public static final ArmorMaterial VIOLETA = new ArmorMaterial(25, Map.of(ArmorType.BOOTS, 3, ArmorType.LEGGINGS, 6, ArmorType.CHESTPLATE, 8, ArmorType.HELMET, 3, ArmorType.BODY, 10), 18, SoundEvents.ARMOR_EQUIP_IRON, 1.0f, 0.0f, VIOLETA_REPAIRS, VIOLETA_KEY);
	public static final ResourceKey<EquipmentAsset> MICELIO_KEY = ResourceKey.create(EquipmentAssets.ROOT_ID, ReinoMicotico.id("micelio"));
	public static final TagKey<Item> MICELIO_REPAIRS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_micelio"));
	public static final ArmorMaterial MICELIO = new ArmorMaterial(30, Map.of(ArmorType.BOOTS, 4, ArmorType.LEGGINGS, 7, ArmorType.CHESTPLATE, 9, ArmorType.HELMET, 4, ArmorType.BODY, 11), 14, SoundEvents.ARMOR_EQUIP_IRON, 2.0f, 0.0f, MICELIO_REPAIRS, MICELIO_KEY);
	public static final ResourceKey<EquipmentAsset> GUARDIAN_FUNGOSO_KEY = ResourceKey.create(EquipmentAssets.ROOT_ID, ReinoMicotico.id("guardian_fungoso"));
	public static final TagKey<Item> GUARDIAN_FUNGOSO_REPAIRS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_guardian_fungoso"));
	public static final ArmorMaterial GUARDIAN_FUNGOSO = new ArmorMaterial(36, Map.of(ArmorType.BOOTS, 4, ArmorType.LEGGINGS, 7, ArmorType.CHESTPLATE, 9, ArmorType.HELMET, 4, ArmorType.BODY, 11), 16, SoundEvents.ARMOR_EQUIP_IRON, 2.0f, 0.05f, GUARDIAN_FUNGOSO_REPAIRS, GUARDIAN_FUNGOSO_KEY);
	public static final ResourceKey<EquipmentAsset> REY_MICOTICO_KEY = ResourceKey.create(EquipmentAssets.ROOT_ID, ReinoMicotico.id("rey_micotico"));
	public static final TagKey<Item> REY_MICOTICO_REPAIRS = TagKey.create(BuiltInRegistries.ITEM.key(), ReinoMicotico.id("repairs_rey_micotico"));
	public static final ArmorMaterial REY_MICOTICO = new ArmorMaterial(44, Map.of(ArmorType.BOOTS, 5, ArmorType.LEGGINGS, 8, ArmorType.CHESTPLATE, 10, ArmorType.HELMET, 5, ArmorType.BODY, 12), 22, SoundEvents.ARMOR_EQUIP_IRON, 3.5f, 0.1f, REY_MICOTICO_REPAIRS, REY_MICOTICO_KEY);
}
