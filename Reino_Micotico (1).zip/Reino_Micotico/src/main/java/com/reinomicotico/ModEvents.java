package com.reinomicotico;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.state.BlockState;

/** Vegetacion reactiva: los hongos venenosos intoxican y las plantas luminosas sueltan esporas al acercarse. */
public final class ModEvents {
	private ModEvents() {}

	public static void initialize() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTickCount() % 10 != 0) return;
			for (ServerPlayer p : server.getPlayerList().getPlayers()) {
				ServerLevel level = (ServerLevel) p.level();
				BlockPos pos = p.blockPosition();
				BlockState st = level.getBlockState(pos);
				if (st.is(ModBlocks.HONGO_VENENOSO)) {
					p.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
					level.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, p.getX(), p.getY() + 0.5, p.getZ(), 8, 0.4, 0.3, 0.4, 0.01);
				} else if (st.is(ModBlocks.HONGO_LUMINOSO) || st.is(ModBlocks.PLANTA_LUMINOSA) || st.is(ModBlocks.HIERBA_MICOTICA)) {
					level.sendParticles(ParticleTypes.GLOW, p.getX(), p.getY() + 0.6, p.getZ(), 6, 0.4, 0.3, 0.4, 0.02);
				}
			}
		});
	}
}
