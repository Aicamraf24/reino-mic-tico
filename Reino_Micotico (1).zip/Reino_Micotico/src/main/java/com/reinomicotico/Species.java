package com.reinomicotico;

import java.util.ArrayList;
import java.util.List;

/** Datos de una especie, cargados desde data/reino_micotico/species.json (editable sin tocar codigo). */
public final class Species {
	public String id;
	public String cat = "peaceful"; // peaceful | neutral | hostile | boss
	public double hp = 10, speed = 0.25, damage = 2, hbw = 0.6, hbh = 0.6, scale = 1.0, knockbackResist = 0.0;
	public boolean fly, climb, egg, tame, flee, ambush, stationary, breedable, boss, hybrid;
	public String ability = "";
	public int maxPop = 16;
	public List<String> food = new ArrayList<>();
	public List<String> parents = new ArrayList<>();

	public boolean hostile() { return cat.equals("hostile"); }
	public boolean neutral() { return cat.equals("neutral"); }
	public boolean peaceful() { return cat.equals("peaceful"); }
}
