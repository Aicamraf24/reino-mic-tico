package com.reinomicotico;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class SpeciesRegistry {
	public static final List<Species> ALL = new ArrayList<>();
	public static final Map<String, Species> BY_ID = new LinkedHashMap<>();
	private static boolean loaded;

	private SpeciesRegistry() {}

	public static synchronized void load() {
		if (loaded) return;
		loaded = true;
		try (InputStream in = SpeciesRegistry.class.getResourceAsStream("/data/reino_micotico/species.json")) {
			if (in == null) throw new IllegalStateException("species.json no encontrado");
			JsonArray arr = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonArray("species");
			Gson gson = new Gson();
			for (JsonElement e : arr) {
				Species s = gson.fromJson(e, Species.class);
				ALL.add(s);
				BY_ID.put(s.id, s);
			}
		} catch (Exception ex) {
			throw new RuntimeException("Error cargando species.json", ex);
		}
	}

	public static int indexOf(String id) {
		for (int i = 0; i < ALL.size(); i++) if (ALL.get(i).id.equals(id)) return i;
		return 0;
	}

	static {
		load();
	}
}
