package com.reinomicotico.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.reinomicotico.ReinoMicotico;
import com.reinomicotico.Species;
import com.reinomicotico.entity.MicoCreature;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

public class SpeciesRenderer<T extends Mob> extends MobRenderer<T, MicoRenderState, SpeciesModel> {
	private final Species species;
	private final Identifier adult, baby;

	public SpeciesRenderer(EntityRendererProvider.Context ctx, Species s) {
		super(ctx, new SpeciesModel(ctx.bakeLayer(ReinoMicoticoClient.LAYERS.get(s.id)), s.id, s.fly), (float) Math.max(0.2, s.hbw * 0.5));
		this.species = s;
		this.adult = ReinoMicotico.id("textures/entity/" + s.id + ".png");
		this.baby = ReinoMicotico.id("textures/entity/" + s.id + "_baby.png");
	}

	@Override
	public MicoRenderState createRenderState() {
		return new MicoRenderState();
	}

	@Override
	public void extractRenderState(T entity, MicoRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		if (entity instanceof MicoCreature c) {
			state.resting = c.isResting();
			state.eating = c.isEating();
			state.sitting = c.isOrderedToSit();
		}
		state.flying = species.fly && !entity.onGround();
		state.attack = entity.getAttackAnim(partialTick);
	}

	@Override
	public Identifier getTextureLocation(MicoRenderState state) {
		return state.isBaby ? baby : adult;
	}

	@Override
	protected void scale(MicoRenderState state, PoseStack poseStack) {
		float s = (float) species.scale;
		poseStack.scale(s, s, s);
	}
}
