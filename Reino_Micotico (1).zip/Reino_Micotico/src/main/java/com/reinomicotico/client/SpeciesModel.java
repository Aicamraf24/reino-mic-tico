package com.reinomicotico.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.reinomicotico.ReinoMicotico;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo generico: cada especie define su anatomia en assets/reino_micotico/mico_models/<id>.json
 * (cajas con UV, pivotes, rotaciones y un "rol" que decide como se anima: head, leg, sleg, arm, tail, wing, jaw, segN).
 */
public class SpeciesModel extends EntityModel<MicoRenderState> {
	private static class Anim {
		ModelPart part;
		String role;
		int index;
		float bx, by, bz, rx, ry, rz;
		boolean left;
	}

	private final List<Anim> anims = new ArrayList<>();
	private final boolean flyer;

	public SpeciesModel(ModelPart root, String id, boolean flyer) {
		super(root);
		this.flyer = flyer;
		JsonObject def = read(id);
		int legCount = 0;
		for (JsonElement e : def.getAsJsonArray("parts")) {
			JsonObject o = e.getAsJsonObject();
			ModelPart cur = root;
			for (JsonElement n : o.getAsJsonArray("path")) cur = cur.getChild(n.getAsString());
			Anim a = new Anim();
			a.part = cur;
			a.role = o.get("role").getAsString();
			JsonArray pv = o.getAsJsonArray("pivot"), rt = o.getAsJsonArray("rot");
			a.bx = pv.get(0).getAsFloat(); a.by = pv.get(1).getAsFloat(); a.bz = pv.get(2).getAsFloat();
			a.rx = rt.get(0).getAsFloat(); a.ry = rt.get(1).getAsFloat(); a.rz = rt.get(2).getAsFloat();
			a.left = o.get("name").getAsString().contains("-1") || o.get("name").getAsString().endsWith("_l") || o.get("tags").toString().contains("wing_l");
			if (a.role.equals("leg") || a.role.equals("sleg") || a.role.equals("arm")) a.index = legCount++;
			if (a.role.startsWith("seg")) a.index = Integer.parseInt(a.role.substring(3));
			anims.add(a);
		}
	}

	static JsonObject read(String id) {
		try (InputStream in = SpeciesModel.class.getResourceAsStream("/assets/reino_micotico/mico_models/" + id + ".json")) {
			return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
		} catch (Exception ex) {
			throw new RuntimeException("modelo no encontrado: " + id, ex);
		}
	}

	public static LayerDefinition createLayer(String id) {
		JsonObject def = read(id);
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		Map<String, PartDefinition> defs = new HashMap<>();
		for (JsonElement e : def.getAsJsonArray("parts")) {
			JsonObject o = e.getAsJsonObject();
			JsonArray b = o.getAsJsonArray("box"), pv = o.getAsJsonArray("pivot"), rt = o.getAsJsonArray("rot");
			String name = o.get("name").getAsString();
			PartDefinition parent = o.get("parent").isJsonNull() ? root : defs.get(o.get("parent").getAsString());
			CubeListBuilder cb = CubeListBuilder.create().texOffs(o.get("u").getAsInt(), o.get("v").getAsInt())
					.addBox(b.get(0).getAsFloat(), b.get(1).getAsFloat(), b.get(2).getAsFloat(), b.get(3).getAsFloat(), b.get(4).getAsFloat(), b.get(5).getAsFloat());
			PartPose pose = PartPose.offsetAndRotation(pv.get(0).getAsFloat(), pv.get(1).getAsFloat(), pv.get(2).getAsFloat(),
					rt.get(0).getAsFloat(), rt.get(1).getAsFloat(), rt.get(2).getAsFloat());
			defs.put(name, parent.addOrReplaceChild(name, cb, pose));
		}
		JsonArray tex = def.getAsJsonArray("tex");
		return LayerDefinition.create(mesh, tex.get(0).getAsInt(), tex.get(1).getAsInt());
	}

	@Override
	public void setupAnim(MicoRenderState s) {
		super.setupAnim(s);
		float pos = s.walkAnimationPos, amp = Math.min(1.0f, s.walkAnimationSpeed), age = s.ageInTicks;
		float pitch = (float) Math.toRadians(s.xRot), yaw = (float) Math.toRadians(s.yRot);
		float atk = s.attack > 0 ? (float) Math.sin(s.attack * Math.PI) : 0f;
		for (Anim a : anims) {
			ModelPart p = a.part;
			float ph = (a.index % 4 == 1 || a.index % 4 == 2) ? (float) Math.PI : 0f;
			switch (a.role) {
				case "head" -> {
					p.xRot = pitch - atk * 0.5f + (s.eating ? 0.7f + (float) Math.sin(age * 0.5f) * 0.15f : 0f) + (s.resting ? 0.5f : 0f);
					p.yRot = yaw;
				}
				case "leg" -> {
					p.xRot = (float) Math.cos(pos * 0.6662f + ph) * 1.4f * amp;
					if (s.sitting || s.resting) { p.xRot = (a.index >= 2 ? -1.3f : -0.4f); p.y = a.by + (a.index >= 2 ? 2.0f : 1.0f); }
				}
				case "sleg" -> {
					float w = pos * 1.3f + ph + a.index * 0.9f;
					p.yRot = a.ry + (float) Math.cos(w) * 0.45f * amp;
					p.zRot = a.rz + Math.max(0f, (float) Math.sin(w)) * 0.35f * amp;
				}
				case "arm" -> {
					p.xRot = (float) Math.cos(pos * 0.6662f + ph) * 1.0f * amp - atk * 1.8f;
				}
				case "tail" -> {
					p.yRot = (float) Math.sin(age * 0.12f + pos) * 0.35f;
					p.xRot = a.rx + (s.resting ? 0.3f : 0f);
				}
				case "wing" -> {
					float sp = s.flying || flyer ? 1.4f : 0.15f;
					float f = (float) Math.sin(age * sp) * (s.flying || flyer ? 0.9f : 0.1f);
					p.zRot = a.rz + (a.left ? -f : f);
				}
				case "jaw" -> p.xRot = Math.max(0f, atk) * 0.9f + (float) Math.sin(age * 0.1f) * 0.04f;
				default -> {
					if (a.role.startsWith("seg")) p.yRot = (float) Math.sin(age * 0.12f - a.index * 0.7f + pos * 0.8f) * (0.18f + 0.2f * amp);
				}
			}
		}
	}
}
