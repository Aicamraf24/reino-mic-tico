package com.reinomicotico.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class MicoRenderState extends LivingEntityRenderState {
	public boolean resting;
	public boolean eating;
	public boolean sitting;
	public boolean flying;
	public float attack;
}
