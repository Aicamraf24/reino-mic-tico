package com.reinomicotico.client;

import com.reinomicotico.ModEntities;
import com.reinomicotico.ReinoMicotico;
import com.reinomicotico.Species;
import com.reinomicotico.SpeciesRegistry;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

public class ReinoMicoticoClient implements ClientModInitializer {
	public static final Map<String, ModelLayerLocation> LAYERS = new HashMap<>();

	@Override
	@SuppressWarnings({"unchecked", "rawtypes"})
	public void onInitializeClient() {
		for (Species s : SpeciesRegistry.ALL) {
			ModelLayerLocation loc = new ModelLayerLocation(ReinoMicotico.id(s.id), "main");
			LAYERS.put(s.id, loc);
			final String id = s.id;
			ModelLayerRegistry.registerModelLayer(loc, () -> SpeciesModel.createLayer(id));
			EntityType<? extends Mob> type = ModEntities.TYPES.get(s.id);
			EntityRenderers.register((EntityType) type, ctx -> new SpeciesRenderer<Mob>((net.minecraft.client.renderer.entity.EntityRendererProvider.Context) ctx, s));
		}
	}
}
