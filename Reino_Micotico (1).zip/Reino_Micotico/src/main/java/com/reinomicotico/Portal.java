package com.reinomicotico;

import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Viaje entre el Overworld y el Reino Micotico con la misma X/Z (1:1). No hace falta guardar nada:
 * el altar de regreso se genera al llegar y el inventario/progreso del jugador se conservan.
 */
public final class Portal {
	public static final ResourceKey<Level> REINO = ResourceKey.create(Registries.DIMENSION, ReinoMicotico.id("reino_micotico"));

	private Portal() {}

	public static void travel(ServerPlayer player) {
		ServerLevel here = (ServerLevel) player.level();
		MinecraftServer server = here.getServer();
		ServerLevel dest = here.dimension().equals(REINO) ? server.getLevel(Level.OVERWORLD) : server.getLevel(REINO);
		if (dest == null) {
			player.sendSystemMessage(Component.translatable("message.reino_micotico.no_dimension"));
			return;
		}
		int bx = player.blockPosition().getX(), bz = player.blockPosition().getZ();
		dest.getChunk(bx >> 4, bz >> 4);
		int y = dest.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz);
		if (y <= dest.getMinY() + 2) y = 100;
		BlockPos altar = new BlockPos(bx, y, bz);
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				dest.setBlockAndUpdate(altar.offset(dx, -1, dz), ModBlocks.LADRILLOS_MICELIO.defaultBlockState());
				for (int dy = 0; dy <= 3; dy++) dest.setBlockAndUpdate(altar.offset(dx, dy, dz), Blocks.AIR.defaultBlockState());
			}
		}
		dest.setBlockAndUpdate(altar, ModBlocks.ALTAR_PORTAL.defaultBlockState());
		player.teleportTo(dest, bx + 0.5, y, bz + 2.5, Set.<Relative>of(), player.getYRot(), player.getXRot(), true);
	}
}
