package com.reinomicotico.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Baston de Esporas: nube de esporas en cono frontal (veneno + lentitud + dano). */
public class SporeStaffItem extends Item {
	public SporeStaffItem(Properties props) {
		super(props);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (!level.isClientSide()) {
			ServerLevel sl = (ServerLevel) level;
			Vec3 eye = player.getEyePosition();
			Vec3 look = player.getLookAngle();
			AABB box = new AABB(eye, eye.add(look.scale(8.0))).inflate(2.0);
			for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, x -> x != player && x.isAlive())) {
				e.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
				e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 1));
				e.hurtServer(sl, sl.damageSources().playerAttack(player), 4.0f);
			}
			for (int i = 1; i <= 8; i++) {
				Vec3 p = eye.add(look.scale(i));
				sl.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, p.x, p.y, p.z, 6, 0.4, 0.4, 0.4, 0.01);
			}
			player.getCooldowns().addCooldown(stack, 30);
			stack.hurtAndBreak(1, player, hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
		}
		return InteractionResult.SUCCESS;
	}
}
