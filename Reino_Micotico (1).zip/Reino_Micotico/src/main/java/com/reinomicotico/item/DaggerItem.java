package com.reinomicotico.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class DaggerItem extends Item {
	public DaggerItem(Properties props) {
		super(props);
	}

	@Override
	public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		target.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 1));
		super.postHurtEnemy(stack, target, attacker);
	}
}
