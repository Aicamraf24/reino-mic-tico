package com.reinomicotico;

import com.reinomicotico.entity.MicoBoss;
import com.reinomicotico.entity.MicoCreature;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
	public static final Map<String, EntityType<? extends Mob>> TYPES = new LinkedHashMap<>();
	private static final Map<EntityType<?>, Species> BY_TYPE = new HashMap<>();

	private ModEntities() {}

	public static Species speciesOf(EntityType<?> type) {
		return BY_TYPE.get(type);
	}

	private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, ReinoMicotico.id(name));
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
	}

	public static void initialize() {
		for (Species s : SpeciesRegistry.ALL) {
			MobCategory cat = (s.boss || s.hostile()) ? MobCategory.MONSTER : MobCategory.CREATURE;
			EntityType<? extends Mob> type;
			if (s.boss) {
				EntityType<MicoBoss> t = register(s.id, EntityType.Builder.<MicoBoss>of(MicoBoss::new, cat)
						.sized((float) s.hbw, (float) s.hbh).clientTrackingRange(10).fireImmune());
				BY_TYPE.put(t, s);
				FabricDefaultAttributeRegistry.register(t, MicoBoss.attributes(s));
				type = t;
			} else {
				EntityType<MicoCreature> t = register(s.id, EntityType.Builder.<MicoCreature>of(MicoCreature::new, cat)
						.sized((float) s.hbw, (float) s.hbh).clientTrackingRange(8));
				BY_TYPE.put(t, s);
				FabricDefaultAttributeRegistry.register(t, MicoCreature.attributes(s));
				type = t;
			}
			TYPES.put(s.id, type);
		}
	}
}
