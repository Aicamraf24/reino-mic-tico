package com.reinomicotico.block;

import com.reinomicotico.ModEntities;
import com.reinomicotico.Species;
import com.reinomicotico.SpeciesRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Huevo de cualquier especie ovipara: la propiedad SPECIES decide el diseno y la cria que nace. */
public class MicoEggBlock extends Block {
	public static final IntegerProperty SPECIES = IntegerProperty.create("species", 0, SpeciesRegistry.ALL.size() - 1);
	public static final IntegerProperty HATCH = IntegerProperty.create("hatch", 0, 2);
	private static final VoxelShape SHAPE = Block.box(4.0, 0.0, 4.0, 12.0, 9.0, 12.0);

	public MicoEggBlock(Properties props) {
		super(props);
		this.registerDefaultState(this.stateDefinition.any().setValue(SPECIES, 0).setValue(HATCH, 0));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(SPECIES, HATCH);
	}

	@Override
	protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
		return SHAPE;
	}

	@Override
	protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		if (random.nextInt(3) != 0) return;
		int h = state.getValue(HATCH);
		if (h < 2) {
			level.setBlockAndUpdate(pos, state.setValue(HATCH, h + 1));
			return;
		}
		level.removeBlock(pos, false);
		Species s = SpeciesRegistry.ALL.get(state.getValue(SPECIES));
		EntityType<? extends Mob> t = ModEntities.TYPES.get(s.id);
		Mob m = t.create(level, EntitySpawnReason.BREEDING);
		if (m != null) {
			if (m instanceof AgeableMob am) am.setBaby(true);
			m.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
			level.addFreshEntity(m);
		}
	}
}
