package com.reinomicotico.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Planta/hongo que necesita suelo: solo se mantiene sobre tierra (etiqueta minecraft:dirt: micelios,
 * tierra fungosa, pasto...). Los hongos y cristales ("sturdy") tambien aceptan cualquier suelo solido
 * (suelo de cuevas). Si el bloque de abajo se rompe, la planta se rompe tambien.
 */
public class MicoPlantBlock extends Block {
	private final boolean sturdy;

	public MicoPlantBlock(Properties props, boolean sturdy) {
		super(props);
		this.sturdy = sturdy;
	}

	@Override
	protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
		BlockPos below = pos.below();
		BlockState b = level.getBlockState(below);
		if (b.is(BlockTags.DIRT)) return true;
		return sturdy && b.isFaceSturdy(level, below, Direction.UP);
	}

	@Override
	protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos, Direction dir,
			BlockPos neighborPos, BlockState neighborState, RandomSource random) {
		if (!state.canSurvive(level, pos)) return Blocks.AIR.defaultBlockState();
		return super.updateShape(state, level, ticks, pos, dir, neighborPos, neighborState, random);
	}
}
