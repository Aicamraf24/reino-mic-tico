package com.reinomicotico;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReinoMicotico implements ModInitializer {
	public static final String MOD_ID = "reino_micotico";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		SpeciesRegistry.load();
		Breeding.load();
		ModEntities.initialize();
		ModBlocks.initialize();
		ModItems.initialize();
		ModEvents.initialize();
		LOGGER.info("Reino Micotico: {} especies registradas", SpeciesRegistry.ALL.size());
	}
}
