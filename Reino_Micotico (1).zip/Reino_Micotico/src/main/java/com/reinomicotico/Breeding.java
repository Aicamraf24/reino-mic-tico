package com.reinomicotico;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.RandomSource;

/**
 * Reglas de reproduccion entre especies, 100% basadas en datos:
 *  - config/reino_micotico/breeding.json (si existe) sobreescribe el archivo por defecto del mod.
 *  - "species": lista de parejas compatibles por especie.
 *  - "hybrids": cruces que producen una criatura hibrida (con modelo y textura propios).
 * Los jefes (cat == boss) y las especies marcadas breedable=false NUNCA se reproducen.
 */
public final class Breeding {
	private static final Map<String, Set<String>> PARTNERS = new HashMap<>();
	private static final Map<String, Object[]> HYBRIDS = new HashMap<>(); // "a|b" -> {resultId, chance}

	private Breeding() {}

	private static String key(String a, String b) {
		return a.compareTo(b) <= 0 ? a + "|" + b : b + "|" + a;
	}

	public static void load() {
		PARTNERS.clear();
		HYBRIDS.clear();
		JsonObject root = null;
		try {
			Path cfg = FabricLoader.getInstance().getConfigDir().resolve("reino_micotico").resolve("breeding.json");
			if (Files.exists(cfg)) {
				try (Reader r = Files.newBufferedReader(cfg, StandardCharsets.UTF_8)) {
					root = JsonParser.parseReader(r).getAsJsonObject();
				}
			}
		} catch (Exception e) {
			ReinoMicotico.LOGGER.warn("breeding.json de config invalido, se usa el valor por defecto: {}", e.toString());
		}
		if (root == null) {
			try (InputStream in = Breeding.class.getResourceAsStream("/data/reino_micotico/breeding.json")) {
				root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
				try {
					Path dir = FabricLoader.getInstance().getConfigDir().resolve("reino_micotico");
					Files.createDirectories(dir);
					Path out = dir.resolve("breeding.json");
					if (!Files.exists(out)) Files.writeString(out, root.toString(), StandardCharsets.UTF_8);
				} catch (Exception ignored) {
				}
			} catch (Exception e) {
				throw new RuntimeException("breeding.json no encontrado", e);
			}
		}
		JsonObject sp = root.getAsJsonObject("species");
		for (Map.Entry<String, JsonElement> en : sp.entrySet()) {
			Set<String> set = new HashSet<>();
			for (JsonElement p : en.getValue().getAsJsonObject().getAsJsonArray("partners")) set.add(p.getAsString());
			PARTNERS.put(en.getKey(), set);
		}
		for (JsonElement h : root.getAsJsonArray("hybrids")) {
			JsonObject o = h.getAsJsonObject();
			JsonArray par = o.getAsJsonArray("parents");
			HYBRIDS.put(key(par.get(0).getAsString(), par.get(1).getAsString()),
					new Object[] {o.get("result").getAsString(), o.get("chance").getAsDouble()});
		}
	}

	/** Dos especies pueden aparearse (cualquiera de las dos lista a la otra; misma especie siempre que sea reproducible). */
	public static boolean compatible(Species a, Species b) {
		if (a.boss || b.boss || !a.breedable || !b.breedable) return false;
		if (a.id.equals(b.id)) return true;
		return PARTNERS.getOrDefault(a.id, Set.of()).contains(b.id) || PARTNERS.getOrDefault(b.id, Set.of()).contains(a.id);
	}

	/** Especie de la cria: hibrido si hay regla y sale la probabilidad; si no, la de uno de los progenitores. */
	public static Species offspring(Species a, Species b, RandomSource rnd) {
		if (a.id.equals(b.id)) return a;
		Object[] h = HYBRIDS.get(key(a.id, b.id));
		if (h != null && rnd.nextDouble() < (Double) h[1]) {
			Species r = SpeciesRegistry.BY_ID.get((String) h[0]);
			if (r != null) return r;
		}
		return rnd.nextBoolean() ? a : b;
	}

	public static List<String> partnersOf(String id) {
		return List.copyOf(PARTNERS.getOrDefault(id, Set.of()));
	}
}
